var globals_defs =
[
    [ "b", "globals_defs.html", null ],
    [ "d", "globals_defs_d.html", null ],
    [ "e", "globals_defs_e.html", null ],
    [ "h", "globals_defs_h.html", null ],
    [ "i", "globals_defs_i.html", null ],
    [ "l", "globals_defs_l.html", null ],
    [ "m", "globals_defs_m.html", null ],
    [ "n", "globals_defs_n.html", null ],
    [ "o", "globals_defs_o.html", null ],
    [ "p", "globals_defs_p.html", null ],
    [ "r", "globals_defs_r.html", null ],
    [ "s", "globals_defs_s.html", null ],
    [ "u", "globals_defs_u.html", null ]
];