var lsc__endpoint_8c =
[
    [ "LSC_EP", "group__lscusb.html#ga0ff78db9c52271a24fc7ea3ad3441278", null ],
    [ "min_t", "group__lscusb.html#gac4f53d1b78bc3476b5cd2fdabb236615", null ],
    [ "lsc_usb_clear_stall_all_ep", "group__lscusb.html#ga819221783e805d1ee342ad9405a9fe4e", null ],
    [ "lsc_usb_ep_get_xfer_index", "group__lscusb.html#ga8c59e4c61eb50dc5c63f0d2040631627", null ],
    [ "lsc_usb_set_ep_cfg", "group__lscusb.html#gacef396243b5a8fedf54d1a1119531cfe", null ],
    [ "lsc_usb_set_xfer_resource", "group__lscusb.html#ga37aaa7bd4881b9bcc6facc4017ef2423", null ],
    [ "lsc_usb_start_ep_cfg", "group__lscusb.html#gaa0e213a974e5c6366e700c19ab7fd41e", null ],
    [ "lsc_usb_stop_active_transfers", "group__lscusb.html#ga3f816821d57bab2edbb5e4fabf3919d4", null ]
];