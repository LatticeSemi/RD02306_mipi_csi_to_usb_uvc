var lsc__fw__ep__buf__mgmt_8c =
[
    [ "LSC_FW_EP_BUF_MGMT", "group__lscusb.html#ga38f4877e112046115a5058dcbafd38b8", null ],
    [ "lsc_fw_ep_buf_mgmt_disable", "group__lscusb.html#ga8bcf902e031e365aafebe2e4e4f47356", null ],
    [ "lsc_fw_ep_buf_mgmt_enable", "group__lscusb.html#ga6f232ae7bfb29db83d8051b70c458db9", null ],
    [ "lsc_fw_ep_buf_mgmt_init", "group__lscusb.html#ga78ff143a8f0b6aa0dbad1f91edbb79a1", null ],
    [ "lsc_fw_ep_buf_mgmt_xfer_completion_cb", "group__lscusb.html#ga36f8cf159398f28e90b156c6ba21235f", null ],
    [ "in_user_ep_cnfg", "group__lscusb.html#ga0018ffb8743f41869df48e0eb84f7206", null ],
    [ "out_user_ep_cnfg", "group__lscusb.html#ga6f61c3d0ae6c8597b05848a17f441326", null ]
];