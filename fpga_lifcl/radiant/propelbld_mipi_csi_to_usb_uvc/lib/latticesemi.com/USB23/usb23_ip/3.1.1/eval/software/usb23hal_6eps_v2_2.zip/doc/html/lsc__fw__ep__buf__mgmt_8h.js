var lsc__fw__ep__buf__mgmt_8h =
[
    [ "LSC_IN_EP_SINGLE_BUFR_DEPTH", "group__lscusb.html#ga8b579e5014b240c903b2ab8900ffee98", null ],
    [ "LSC_IN_EP_TOTAL_BUFR_DEPTH", "group__lscusb.html#ga96c681c0e114b88d1e3e51af319dfeeb", null ],
    [ "LSC_IN_EP_TOTAL_BUFRS", "group__lscusb.html#ga9f1f6d17adba25ff4a64f8d0064a54f1", null ],
    [ "LSC_OUT_EP_SINGLE_BUFR_DEPTH", "group__lscusb.html#gad8f2361d7cbcd5b6c4d8d3a64e5f41a9", null ],
    [ "LSC_OUT_EP_TOTAL_BUFR_DEPTH", "group__lscusb.html#gaf8d5bc477b47a2a928eb79ebf976b7ab", null ],
    [ "LSC_OUT_EP_TOTAL_BUFRS", "group__lscusb.html#ga07b398b18e288ced0daea30f8432cfe7", null ]
];