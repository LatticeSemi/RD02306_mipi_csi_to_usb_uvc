var lsc__in__ep__buf__mgmt_8c =
[
    [ "LSC_IN_EP_BUF_MGMT", "group__lscusb.html#ga7e39c0029a7ac1a8ef2c1f7dd7a1ad86", null ],
    [ "lsc_iebm_buf_int_handler", "group__lscusb.html#gab5c867cf3645915d02e7d9a8dc8fdfe8", null ],
    [ "lsc_iebm_disable", "group__lscusb.html#gaa646f96e8fabbe63066f3f63c83ccb79", null ],
    [ "lsc_iebm_enable", "group__lscusb.html#ga10d3eb5db2df98d95435acba42fc946b", null ],
    [ "lsc_iebm_init", "group__lscusb.html#ga925b2cbe0d526d187c04905eb310899a", null ],
    [ "lsc_iebm_xfer_completion_cb", "group__lscusb.html#ga76320c4e3a9ca47a02e6499b6485d2ea", null ],
    [ "dev_iebm_eps", "group__lscusb.html#gaf07bf5bc3d755212a168839e73151f92", null ],
    [ "in_user_ep_cnfg", "group__lscusb.html#ga0018ffb8743f41869df48e0eb84f7206", null ]
];