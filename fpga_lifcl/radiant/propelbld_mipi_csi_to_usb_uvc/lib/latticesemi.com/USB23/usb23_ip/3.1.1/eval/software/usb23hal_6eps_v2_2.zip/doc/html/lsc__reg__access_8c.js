var lsc__reg__access_8c =
[
    [ "get_mtime", "group__lscusb.html#ga100e9d4590f9b16eecca5900f85fbd46", null ],
    [ "GetElapsedMs", "group__lscusb.html#gaf04da3f34d0a2aa8c53cbe272067b036", null ],
    [ "lsc_16_read", "group__lscusb.html#ga7475d29ba6dfbfbca1bfb1d9c321d115", null ],
    [ "lsc_16_write", "group__lscusb.html#gaa9003fd14bf7936ae6eb94f7083bd45e", null ],
    [ "lsc_32_read", "group__lscusb.html#gac97f574fe1e75e25fcb8987ba17432a8", null ],
    [ "lsc_32_write", "group__lscusb.html#ga5927c918ce8b69e831ffd9f274081b3b", null ],
    [ "lsc_8_read", "group__lscusb.html#ga6bc12548dbead527a5f443677ab1d930", null ],
    [ "lsc_8_write", "group__lscusb.html#ga2aad7b6e0f7218e64e4990c6b57cd394", null ],
    [ "lsc_uart_print", "group__lscusb.html#ga8df28d48751a3a36b5160773632f2bb1", null ],
    [ "lsc_uart_tx", "group__lscusb.html#ga697b11158657a4b6f61c4faf9f66766f", null ],
    [ "mtime_init", "group__lscusb.html#ga1c42f97d4e6c77561ee2d7c22b15f918", null ],
    [ "timestamp", "group__lscusb.html#gaba676b0b1a38a827b10060c223303ae8", null ],
    [ "uart_core_uart", "group__lscusb.html#gaf00db0f7321d4f68b9e1b423e0021c65", null ]
];