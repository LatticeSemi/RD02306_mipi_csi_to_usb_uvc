var lsc__usb__ch9_8c =
[
    [ "DEBUG_LSC_USB_CH9", "group__lscusb.html#gac36a368929a195c6ce685b96a442b0df", null ],
    [ "LSC_USB_CH9", "group__lscusb.html#ga143f7ba329865c842751c58549edc60f", null ],
    [ "lsc_usb_non_ctrl_ep_enable", "group__lscusb.html#ga4b8d0b2dc71ab217d1c0ed934f5d1374", null ],
    [ "lsc_usb_setup_pkt_process", "group__lscusb.html#gad38b94fa6f4575725321360a3de1d2f3", null ],
    [ "process_usb_std_req", "group__lscusb.html#ga41b15d948deac9914d5f4651fa1269a0", null ],
    [ "attribute", "group__lscusb.html#ga541d132a0616913907e5cb23c2439d54", null ],
    [ "bytes_interval", "group__lscusb.html#ga947b4e6b13f623e158f36189c0c468fe", null ],
    [ "ep_attribute", "group__lscusb.html#ga2d0c3ba043ee8551a71a090db85b22f3", null ],
    [ "interval", "group__lscusb.html#ga777dacd1be32d9d9d7122122a5710d9b", null ],
    [ "maxburst", "group__lscusb.html#gabe3c6013f0b913efb6df7fcf1c8ceb9f", null ],
    [ "maxpktsz", "group__lscusb.html#ga0db741c284b754d8e718216adb947e45", null ]
];