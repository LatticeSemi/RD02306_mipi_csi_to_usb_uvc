var lsc__usb__vendor_8c =
[
    [ "LSC_USB_VENDOR", "group__lscusb.html#ga994cfaa0ba7537d8f495dc26d7035551", null ],
    [ "lsc_usb_vendor_req", "group__lscusb.html#ga8856d8ad66eba11b27c4b03f61460b9f", null ]
];