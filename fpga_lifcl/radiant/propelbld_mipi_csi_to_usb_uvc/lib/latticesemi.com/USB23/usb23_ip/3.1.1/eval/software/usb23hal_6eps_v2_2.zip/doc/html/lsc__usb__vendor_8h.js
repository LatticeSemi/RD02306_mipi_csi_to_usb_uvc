var lsc__usb__vendor_8h =
[
    [ "ACK_FLAG_MSK", "group__lscusb.html#gac83fb0714d288a2c712346aede129802", null ],
    [ "COMPLETE_FLAG_MSK", "group__lscusb.html#gadec2a5de3b21ea745ddfc0cfffa33dd7", null ],
    [ "CONTROL_CMD_TYPE", "group__lscusb.html#ga2ac8de47894e24490052508f4b59e8c3", null ],
    [ "ERR_FLAG_MSK", "group__lscusb.html#ga8ea664f809b302dd21bb607ef998cee7", null ],
    [ "HEADER_LEN", "group__lscusb.html#gab8f5e10b9f780e53f9583724ac965a0c", null ],
    [ "I2C_PKT_HEADER_LEN", "group__lscusb.html#ga6ba4a08f527c10bb1ddacccba2c411ee", null ],
    [ "IO_REQ_CMD_TYPE", "group__lscusb.html#ga2092ba8c60d1d8977516f764e951b6ad", null ],
    [ "PARTIAL_PKT_MSK", "group__lscusb.html#ga8a5115a80af6a250d61d22ee36f878a0", null ],
    [ "RESP_FLAG_MSK", "group__lscusb.html#ga57574e44e04018e7f1dfacd2c28d50f9", null ],
    [ "VENDOR_REQ_MAX_SIZE", "group__lscusb.html#ga6ebc32c3822383a4fff647b958d7a774", null ]
];