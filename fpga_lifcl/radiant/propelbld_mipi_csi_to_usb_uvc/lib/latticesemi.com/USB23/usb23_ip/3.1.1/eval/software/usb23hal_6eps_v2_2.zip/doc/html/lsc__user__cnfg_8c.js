var lsc__user__cnfg_8c =
[
    [ "bulk_in_user_ep_cnfg", "group__lscusb.html#ga1a88af3b07130e8eca8b84c6e12b59ae", null ],
    [ "bulk_out_user_ep_cnfg", "group__lscusb.html#ga6955dac11348924f138e3cdc52948a40", null ],
    [ "fw_in_ep_bufr", "group__lscusb.html#ga30c5ccb0ffd2cc3198ff387133d09b51", null ],
    [ "fw_out_ep_bufr", "group__lscusb.html#ga9b7aba791bbddf8ee2c8a9b24e3fee81", null ],
    [ "in_user_ep_cnfg", "group__lscusb.html#ga0018ffb8743f41869df48e0eb84f7206", null ],
    [ "int_in_user_ep_cnfg", "group__lscusb.html#gaf46e238a9f949b42a9d92a22748fd02e", null ],
    [ "int_out_user_ep_cnfg", "group__lscusb.html#gaece0c722be7590f61e98407827ff4b8d", null ],
    [ "iso_in_user_ep_cnfg", "group__lscusb.html#ga2690c473fba58be1ffcd443a50bc7d77", null ],
    [ "iso_out_user_ep_cnfg", "group__lscusb.html#ga3af6876dd3e5cdf02908c6e6c5fd6899", null ],
    [ "out_user_ep_cnfg", "group__lscusb.html#ga6f61c3d0ae6c8597b05848a17f441326", null ],
    [ "unused_ep_cnfg", "group__lscusb.html#gac19d35fae7e6cf34d67e6fa1c873a04b", null ]
];