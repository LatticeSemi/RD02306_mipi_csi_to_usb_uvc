var lsc__winsub_8h =
[
    [ "MS_OS_2_0_DESC_SET_REQUEST", "group__lscusb.html#ga3f9d3d3ea701bcaf813ce82d4dee6251", null ],
    [ "WIN_USB_VERSION", "group__lscusb.html#gade5d31998633d4ba41d50a1b6211e40b", null ],
    [ "WINUSB_DEV", "group__lscusb.html#gad36df9f19d6671fe0ac794b16c15ac3e", null ],
    [ "WINUSB_REQ", "group__lscusb.html#gaf354049178021d21971ab795a7d9c138", null ],
    [ "descp_set", "group__lscusb.html#ga9f7e9fa76b3685b8a1415d28755951dc", null ]
];