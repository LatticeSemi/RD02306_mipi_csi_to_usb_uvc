var searchData=
[
  ['_5fusb_5fcommon_5fdescriptor',['_USB_COMMON_DESCRIPTOR',['../struct___u_s_b___c_o_m_m_o_n___d_e_s_c_r_i_p_t_o_r.html',1,'']]]
];
