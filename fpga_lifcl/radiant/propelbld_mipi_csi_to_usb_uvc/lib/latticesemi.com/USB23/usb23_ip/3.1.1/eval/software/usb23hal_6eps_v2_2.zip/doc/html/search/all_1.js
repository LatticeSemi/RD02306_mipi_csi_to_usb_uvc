var searchData=
[
  ['act_5flen',['act_len',['../structlsc__ep__req.html#a90d6f9d779787a2579d380148b8fe934',1,'lsc_ep_req']]],
  ['add_5fxfer_5fper_5fmf',['add_xfer_per_mf',['../structlsc__ep.html#aa939b95b30e44c7a69464feab6a96349',1,'lsc_ep']]],
  ['attribute',['attribute',['../group__lscusb.html#ga541d132a0616913907e5cb23c2439d54',1,'lsc_usb_ch9.c']]]
];
