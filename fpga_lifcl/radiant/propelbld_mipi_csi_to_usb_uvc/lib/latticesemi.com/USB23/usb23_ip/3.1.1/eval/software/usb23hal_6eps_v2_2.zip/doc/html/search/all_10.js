var searchData=
[
  ['setup_5fdata',['setup_data',['../structlsc__usb__dev__dm.html#ada91096e80f0ffa9a96b2156c7bcce36',1,'lsc_usb_dev_dm']]],
  ['setup_5fpkt',['setup_pkt',['../structsetup__pkt.html',1,'']]],
  ['size',['size',['../structlsc__trb.html#adc09fb61ae830e3118aa3c272cfc0910',1,'lsc_trb']]],
  ['ss_5fdev_5fcap_5fdesc',['SS_DEV_CAP_DESC',['../group__lscusb.html#ga3e9debc1d6c5704c4b4a105c81b59d77',1,'lsc_usb_ch9.h']]],
  ['ssp_5fdev_5fcap_5fdesc',['SSP_DEV_CAP_DESC',['../group__lscusb.html#gaa2d1b23fbe49c88e40b07bcf8ea1f967',1,'lsc_usb_ch9.h']]],
  ['status',['status',['../structlsc__event__epevt.html#a7d2148193c7662ecf768af909309a165',1,'lsc_event_epevt']]],
  ['sts',['sts',['../structlsc__ep__req.html#ac85b09d5c9ddf57d59f2c68b4498eb0e',1,'lsc_ep_req']]],
  ['syc_5fpictimer_5fstart_5faddr',['SYC_PICTIMER_START_ADDR',['../main_8c.html#a2850122cd802d3401c5674e006550179',1,'main.c']]]
];
