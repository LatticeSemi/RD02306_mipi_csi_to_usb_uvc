var searchData=
[
  ['test_5fmode',['test_mode',['../structlsc__usb__dev.html#ab37590ed90a5a1b9f473269a551ac856',1,'lsc_usb_dev']]],
  ['timer',['timer',['../main_8c.html#a9ff7859dc90560bfba08efb0a875220e',1,'main.c']]],
  ['timer_5fint',['timer_int',['../main_8c.html#afd25a4d5543af7971d500d640e24e3f0',1,'main.c']]],
  ['timestamp',['timestamp',['../group__lscusb.html#gaba676b0b1a38a827b10060c223303ae8',1,'lsc_reg_access.c']]],
  ['timing',['timing',['../structtiming.html',1,'']]],
  ['trb_5fdequeue',['trb_dequeue',['../structlsc__ep.html#ae41d7c49fb06e7f552c6b4beac0e0fa1',1,'lsc_ep']]],
  ['trb_5fenqueue',['trb_enqueue',['../structlsc__ep.html#a0fbd1633397c65d8c0c4e3b8b0a6227a',1,'lsc_ep']]],
  ['trb_5ffree_5fslot',['trb_free_slot',['../structlsc__ep.html#a02b032b181338247213ee2992574df29',1,'lsc_ep']]],
  ['trb_5fmax_5fslot',['trb_max_slot',['../structlsc__ep.html#ab7eb299b7aa4795bdaff5a9e13ce4b4f',1,'lsc_ep']]],
  ['trb_5fxfer_5freq_5fsize',['trb_xfer_req_size',['../structlsc__ep.html#a7784c8e7720f87f4a2e24acc588d19b1',1,'lsc_ep']]],
  ['tu_5fmin32',['tu_min32',['../group__lscusb.html#ga282c9d60813bc8572a62e2ab46d849fe',1,'lsc_usb_dev.h']]],
  ['type',['type',['../structlsc__event__type.html#a63b190b9ad1a6b491858e1cd3be57c20',1,'lsc_event_type']]]
];
