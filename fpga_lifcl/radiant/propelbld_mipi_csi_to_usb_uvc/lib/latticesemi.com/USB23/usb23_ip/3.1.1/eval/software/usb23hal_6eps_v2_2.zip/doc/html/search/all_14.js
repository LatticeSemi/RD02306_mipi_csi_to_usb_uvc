var searchData=
[
  ['wakeup_5fselfpowered',['wakeup_selfpowered',['../structlsc__usb__dev.html#aa2f0261416409edd9d937ab3583987dc',1,'lsc_usb_dev']]],
  ['wbytesperinterval',['wBytesPerInterval',['../struct_u_s_b___s_t_d___e_p___s_s___c_o_m_p___d_e_s_c.html#a82be41612429ac14e1d3a2b35aa78105',1,'USB_STD_EP_SS_COMP_DESC']]],
  ['windex',['wIndex',['../structsetup__pkt.html#aa558b0329a1fe378cb7502ddf5c0db65',1,'setup_pkt']]],
  ['wlangid',['wLANGID',['../struct_u_s_b___s_t_d___s_t_r_i_n_g___d_e_s_c.html#a117ba8d20bc7b81e32f130c590acac58',1,'USB_STD_STRING_DESC']]],
  ['wlength',['wLength',['../structsetup__pkt.html#aa8cb75f9118dafdf9644e86feee8f346',1,'setup_pkt']]],
  ['wspeedssupported',['wSpeedsSupported',['../struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html#a07fba4b09c9f0e2c6d753911b6f17d12',1,'USB_STD_SS_DEVICE_CAP_DESC']]],
  ['wtotallength',['wTotalLength',['../struct_u_s_b___s_t_d___c_f_g___d_e_s_c.html#a841a92ed8edcb0f9ce2db0456846c57c',1,'USB_STD_CFG_DESC::wTotalLength()'],['../struct_u_s_b___s_t_d___b_o_s___d_e_s_c.html#a74b44c4f8c6d92114a9e4eed2ed8be6e',1,'USB_STD_BOS_DESC::wTotalLength()']]],
  ['wu2devexitlat',['wU2DevExitLat',['../struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html#ad2e266e8757fe6a5162502ce2af16289',1,'USB_STD_SS_DEVICE_CAP_DESC']]],
  ['wvalue',['wValue',['../structsetup__pkt.html#adafdb7b0a59748753cfecbb73066d264',1,'setup_pkt']]]
];
