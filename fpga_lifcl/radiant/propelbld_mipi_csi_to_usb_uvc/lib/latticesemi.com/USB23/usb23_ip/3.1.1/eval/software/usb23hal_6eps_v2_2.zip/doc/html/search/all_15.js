var searchData=
[
  ['xfer_5fcompletion_5fcb',['xfer_completion_cb',['../structuser__ep__cnfg.html#a39869f0f1248ec00f1bd9d0a1af4c5a7',1,'user_ep_cnfg']]],
  ['xfer_5freq_5fcb',['xfer_req_cb',['../structuser__ep__cnfg.html#ad704b9bf90a8f9c89ead72a82cba46fb',1,'user_ep_cnfg']]]
];
