var searchData=
[
  ['capabilitydata',['CapabilityData',['../struct_u_s_b___s_t_d___p_l_a_t_f_o_r_m___c_a_p___d_e_s_c.html#a8651a47d6b188e68e30fdf18d1d0193d',1,'USB_STD_PLATFORM_CAP_DESC']]],
  ['config_5fdesc',['config_desc',['../structlsc__usb__dev.html#a85ef41b7372f01f358bdbe129e589ab2',1,'lsc_usb_dev']]],
  ['config_5fdesc_5fsize',['config_desc_size',['../structlsc__usb__dev.html#ada27d82d3854e759c1ead68eb03efda2',1,'lsc_usb_dev']]],
  ['control_5fdir',['control_dir',['../structlsc__usb__dev.html#a5bccbedb176c48cf8a71fc270c83c805',1,'lsc_usb_dev']]],
  ['count',['count',['../structlsc__evt__buffer.html#a0a186105f5f5c3a79ea536db513e5827',1,'lsc_evt_buffer']]],
  ['ctrl',['ctrl',['../structlsc__trb.html#ae612a0e2901bf0ad206dfbc925e13ec2',1,'lsc_trb']]],
  ['cur_5fmicro_5fframe',['cur_micro_frame',['../structlsc__ep.html#ad4b7df7fe7550bf6b6fa498950c4b4af',1,'lsc_ep']]]
];
