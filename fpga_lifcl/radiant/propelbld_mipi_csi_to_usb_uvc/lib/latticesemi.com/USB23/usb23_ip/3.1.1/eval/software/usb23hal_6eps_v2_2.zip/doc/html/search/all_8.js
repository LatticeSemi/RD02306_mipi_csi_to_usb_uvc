var searchData=
[
  ['handler',['handler',['../structlsc__ep.html#a3fb8401375084a59825edd8c1200c19e',1,'lsc_ep']]],
  ['hw_5falloc_5fbuf_5fdepth',['HW_ALLOC_BUF_DEPTH',['../group__lscusb.html#gae2baa9b38c7546d3478b1f115c26c164',1,'lsc_in_ep_buf_mgmt.h']]]
];
