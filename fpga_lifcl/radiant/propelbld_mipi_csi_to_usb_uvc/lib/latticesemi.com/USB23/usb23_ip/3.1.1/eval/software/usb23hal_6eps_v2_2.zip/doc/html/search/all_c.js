var searchData=
[
  ['no_5fof_5fbuf',['NO_OF_BUF',['../group__lscusb.html#ga68fbee443e9f170730c43b86b6b5d9f8',1,'lsc_usb_dev.h']]],
  ['no_5fof_5fevent',['no_of_event',['../structlsc__ep__buf__info.html#a82e0a4f3632969eda497b4001972970c',1,'lsc_ep_buf_info']]],
  ['no_5fof_5freq_5fpending',['no_of_req_pending',['../structlsc__ep.html#abc9dd1bc3ef4ae475f24857746573711',1,'lsc_ep']]],
  ['no_5fof_5ftrb_5fper_5fep',['NO_OF_TRB_PER_EP',['../group__lscusb.html#ga41223da2c73c6bb2fe462819b7518f55',1,'lsc_usb_dev.h']]],
  ['num_5fin_5feps',['num_in_eps',['../structlsc__usb__dev.html#a35117d816458106b04c89c8219c9e230',1,'lsc_usb_dev']]],
  ['num_5fout_5feps',['num_out_eps',['../structlsc__usb__dev.html#aa4b32848486a7eb1caef466e1cdb05b1',1,'lsc_usb_dev']]]
];
