var searchData=
[
  ['release_20history',['Release History',['../_h_a_l.html',1,'']]],
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['readme_5flifcl_5fnx33u_5fgeneric_5fhal_2etxt',['readme_lifcl_nx33u_generic_hal.txt',['../readme__lifcl__nx33u__generic__hal_8txt.html',1,'']]],
  ['remain_5fbytes',['remain_bytes',['../structlsc__ep.html#a38f6f20c22c709fb514eb74eee658f5d',1,'lsc_ep']]],
  ['req_5farr',['req_arr',['../structlsc__ep.html#ad43fdf3f43d76a6df90cda33dc5deeb6',1,'lsc_ep']]],
  ['req_5fcompletion_5ftracker',['req_completion_tracker',['../structlsc__ep.html#ad0dd92cb6f189bb6b34c253127b09bd4',1,'lsc_ep']]],
  ['req_5fdequeue_5fptr',['req_dequeue_ptr',['../structlsc__ep.html#aa501dbc140a2c5b4d47d0aadbb05e0de',1,'lsc_ep']]],
  ['req_5fenqueue_5fptr',['req_enqueue_ptr',['../structlsc__ep.html#ad5fbe8e39ceddbf306c32e8798b7f5b7',1,'lsc_ep']]],
  ['req_5flen',['req_len',['../structlsc__ep__req.html#a1868674c554638e317db9717811d59be',1,'lsc_ep_req']]],
  ['req_5fqueue_5fen',['req_queue_en',['../structlsc__ep.html#a3c2108e8c29c313c9e56ea392f281e97',1,'lsc_ep']]],
  ['requested_5fbytes',['requested_bytes',['../structlsc__ep.html#a6015c323289cb5db64c34863803ac3e2',1,'lsc_ep']]],
  ['res_5fbuf',['res_buf',['../group__lscusb.html#gaec0992675d833e76cab169e1d522c8a8',1,'res_buf():&#160;main.c'],['../group__lscusb.html#gaec0992675d833e76cab169e1d522c8a8',1,'res_buf():&#160;main.c']]],
  ['reserved11_5f10',['reserved11_10',['../structlsc__event__epevt.html#a018066eebbd353d2cd8d44324384c05d',1,'lsc_event_epevt']]],
  ['reserved15_5f12',['reserved15_12',['../structlsc__event__devt.html#ae418c12360b1afa7e682828d8f4c002d',1,'lsc_event_devt']]],
  ['reserved31_5f12',['reserved31_12',['../structlsc__event__gevt.html#a10325b2cecd893fcdf0091ef96e1f379',1,'lsc_event_gevt']]],
  ['reserved31_5f25',['reserved31_25',['../structlsc__event__devt.html#afe71a1150491fedb5987871d427f2f1a',1,'lsc_event_devt']]],
  ['reserved8_5f31',['reserved8_31',['../structlsc__event__type.html#a4792cc35e2f53c4275253344aeb1d290',1,'lsc_event_type']]],
  ['resource_5findex',['resource_index',['../structlsc__ep.html#a86d40397b94cd15e1326174f6d240f53',1,'lsc_ep']]],
  ['roundup',['roundup',['../group__lscusb.html#gaeb47018f732c79a339c5617ef0cbab65',1,'lsc_usb_dev.h']]],
  ['rw_5fgpio_5f0',['rw_gpio_0',['../main_8c.html#a804c150a6738b31cb6336ed179d0c679',1,'main.c']]]
];
