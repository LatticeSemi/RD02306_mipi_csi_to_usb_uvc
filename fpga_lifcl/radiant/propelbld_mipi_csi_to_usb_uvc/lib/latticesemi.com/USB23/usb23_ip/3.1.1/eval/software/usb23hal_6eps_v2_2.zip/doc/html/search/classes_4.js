var searchData=
[
  ['usb_5fstd_5fbos_5fdesc',['USB_STD_BOS_DESC',['../struct_u_s_b___s_t_d___b_o_s___d_e_s_c.html',1,'']]],
  ['usb_5fstd_5fcfg_5fdesc',['USB_STD_CFG_DESC',['../struct_u_s_b___s_t_d___c_f_g___d_e_s_c.html',1,'']]],
  ['usb_5fstd_5fdev_5fdesc',['USB_STD_DEV_DESC',['../struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html',1,'']]],
  ['usb_5fstd_5fdev_5fqualifier_5fdesc',['USB_STD_DEV_QUALIFIER_DESC',['../struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c.html',1,'']]],
  ['usb_5fstd_5fep_5fdesc',['USB_STD_EP_DESC',['../struct_u_s_b___s_t_d___e_p___d_e_s_c.html',1,'']]],
  ['usb_5fstd_5fep_5fss_5fcomp_5fdesc',['USB_STD_EP_SS_COMP_DESC',['../struct_u_s_b___s_t_d___e_p___s_s___c_o_m_p___d_e_s_c.html',1,'']]],
  ['usb_5fstd_5fiad',['USB_STD_IAD',['../struct_u_s_b___s_t_d___i_a_d.html',1,'']]],
  ['usb_5fstd_5fif_5fdesc',['USB_STD_IF_DESC',['../struct_u_s_b___s_t_d___i_f___d_e_s_c.html',1,'']]],
  ['usb_5fstd_5fplatform_5fcap_5fdesc',['USB_STD_PLATFORM_CAP_DESC',['../struct_u_s_b___s_t_d___p_l_a_t_f_o_r_m___c_a_p___d_e_s_c.html',1,'']]],
  ['usb_5fstd_5fss_5fdevice_5fcap_5fdesc',['USB_STD_SS_DEVICE_CAP_DESC',['../struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html',1,'']]],
  ['usb_5fstd_5fstring_5fdesc',['USB_STD_STRING_DESC',['../struct_u_s_b___s_t_d___s_t_r_i_n_g___d_e_s_c.html',1,'']]],
  ['usb_5fstd_5fu20_5fdevice_5fext_5fdesc',['USB_STD_U20_DEVICE_EXT_DESC',['../struct_u_s_b___s_t_d___u20___d_e_v_i_c_e___e_x_t___d_e_s_c.html',1,'']]],
  ['user_5fep_5fcnfg',['user_ep_cnfg',['../structuser__ep__cnfg.html',1,'']]]
];
