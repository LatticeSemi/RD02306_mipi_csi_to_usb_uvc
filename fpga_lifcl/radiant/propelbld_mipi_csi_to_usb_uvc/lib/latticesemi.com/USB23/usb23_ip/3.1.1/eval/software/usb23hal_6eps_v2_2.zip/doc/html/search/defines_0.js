var searchData=
[
  ['lsc_5fusb_5fdev_5fbase_5fadd',['LSC_USB_DEV_BASE_ADD',['../main_8c.html#a42d28d57231e378a91ff455655021f54',1,'main.c']]],
  ['lsc_5fusb_5fdev_5firq',['LSC_USB_DEV_IRQ',['../main_8c.html#a0fbbffe5206aa389601a56d7dfb7c164',1,'main.c']]]
];
