var searchData=
[
  ['get_5fmtime',['get_mtime',['../group__lscusb.html#ga100e9d4590f9b16eecca5900f85fbd46',1,'lsc_reg_access.c']]],
  ['getelapsedms',['GetElapsedMs',['../group__lscusb.html#gaf04da3f34d0a2aa8c53cbe272067b036',1,'lsc_reg_access.c']]]
];
