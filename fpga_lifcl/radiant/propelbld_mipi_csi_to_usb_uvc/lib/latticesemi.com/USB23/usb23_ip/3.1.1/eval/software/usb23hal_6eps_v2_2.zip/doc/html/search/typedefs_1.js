var searchData=
[
  ['usb_5fcommon_5fdescriptor',['USB_COMMON_DESCRIPTOR',['../group__lscusb.html#gaa84b781f281a507102c50cec34a27a2f',1,'lsc_usb_ch9.h']]]
];
