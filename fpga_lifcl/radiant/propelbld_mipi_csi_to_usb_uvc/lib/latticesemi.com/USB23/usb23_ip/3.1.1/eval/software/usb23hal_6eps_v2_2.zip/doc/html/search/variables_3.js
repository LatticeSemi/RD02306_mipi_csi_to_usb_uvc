var searchData=
[
  ['dev_5fdesc',['dev_desc',['../structlsc__usb__dev.html#a1099e70de3e02f4e3b56c6ab9b35fa4f',1,'lsc_usb_dev']]],
  ['dev_5fdesc_5fsize',['dev_desc_size',['../structlsc__usb__dev.html#a9ef62c121165599d9c1d8bc450c8cb43',1,'lsc_usb_dev']]],
  ['dev_5fevent',['dev_event',['../structlsc__event__devt.html#ac235fa3b97cb304ddeb7fd071aed2500',1,'lsc_event_devt::dev_event()'],['../structlsc__event__gevt.html#a8ee61081b86297e5d58b1b47b2121576',1,'lsc_event_gevt::dev_event()']]],
  ['dev_5fevt',['dev_evt',['../unionlsc__event.html#a8e27287161c5e88817fa2250f8b18a64',1,'lsc_event']]],
  ['dev_5fevt_5ftype',['dev_evt_type',['../structlsc__event__devt.html#a668d8de799492a30f86719b7c8ce8770',1,'lsc_event_devt']]],
  ['dev_5fiebm_5feps',['dev_iebm_eps',['../group__lscusb.html#gaf07bf5bc3d755212a168839e73151f92',1,'lsc_in_ep_buf_mgmt.c']]],
  ['dev_5foebm_5feps',['dev_oebm_eps',['../group__lscusb.html#ga4d887d7b0a7422ec0186b8608b1485c4',1,'lsc_out_ep_buf_mgmt.c']]],
  ['dev_5fspeed',['dev_speed',['../structlsc__usb__dev.html#a6e863a37ea83b56468ad7e39bc5187ac',1,'lsc_usb_dev']]],
  ['dev_5fstate',['dev_state',['../structlsc__usb__dev.html#a98804dbf431ff5bb702e6bc46514f1cc',1,'lsc_usb_dev']]],
  ['dis_5fcb',['dis_cb',['../structuser__ep__cnfg.html#acf054b139925f93a2e66d3eacb7c78d2',1,'user_ep_cnfg']]],
  ['disp_5fxfer_5flen',['disp_xfer_len',['../structuser__ep__cnfg.html#aa5703c7dc6e573e708fa63ad5d2eec00',1,'user_ep_cnfg']]],
  ['disp_5fxferred_5fdata',['disp_xferred_data',['../structuser__ep__cnfg.html#ad0900ca37990b5d69d11785f0ad933e8',1,'user_ep_cnfg']]]
];
