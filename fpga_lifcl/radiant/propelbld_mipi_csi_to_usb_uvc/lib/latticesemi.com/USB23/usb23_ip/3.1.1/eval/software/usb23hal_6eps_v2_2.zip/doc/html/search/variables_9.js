var searchData=
[
  ['l2_5fsuspend',['l2_suspend',['../structlsc__usb__dev.html#aa75db0f381c46f90dbd2a38b4469c1dd',1,'lsc_usb_dev']]],
  ['last_5fiso_5fframe',['last_iso_frame',['../structlsc__ep.html#a05906be203eb8b64838fb2489c68f987',1,'lsc_ep']]],
  ['last_5fiso_5fframe_5fvalid',['last_iso_frame_valid',['../structlsc__ep.html#a39018b991b45c32b60bd93d5398acf97',1,'lsc_ep']]],
  ['link_5fstate',['link_state',['../structlsc__usb__dev.html#acdfc09487977473a00ee5d6daf0112a6',1,'lsc_usb_dev']]],
  ['lsc_5fusr_5fapp_5fhandler',['lsc_usr_app_handler',['../structlsc__usb__dev.html#a04cc0807b2a29340a022da227954e8ff',1,'lsc_usb_dev']]]
];
