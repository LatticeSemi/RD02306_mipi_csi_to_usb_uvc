var searchData=
[
  ['max_5fep_5fsize',['max_ep_size',['../structlsc__ep.html#a978040047fc293f00c74db6b35cf8a1c',1,'lsc_ep']]],
  ['max_5fno_5fof_5fep_5fxfer_5freq',['max_no_of_ep_xfer_req',['../structlsc__ep.html#ac2ce0858855b6b5b648b16f855400871',1,'lsc_ep']]],
  ['max_5fpkt_5fsize',['max_pkt_size',['../structlsc__ep.html#a189e8b1aa594fb09336df9ea9521c5d6',1,'lsc_ep']]],
  ['max_5ftrb_5fsz',['max_trb_sz',['../structlsc__ep.html#adb6cc857ef8639827143c3ef6dbea26a',1,'lsc_ep']]],
  ['maxburst',['maxburst',['../structlsc__ep.html#a04801d594292ba2f6dbba9d23b1b2d5e',1,'lsc_ep::maxburst()'],['../group__lscusb.html#gabe3c6013f0b913efb6df7fcf1c8ceb9f',1,'maxburst():&#160;lsc_usb_ch9.c']]],
  ['maxpktsz',['maxpktsz',['../group__lscusb.html#ga0db741c284b754d8e718216adb947e45',1,'lsc_usb_ch9.c']]],
  ['min_5fbufr_5fspan',['min_bufr_span',['../structlsc__ep.html#a756b680772dd4ee11e4746049ea686d9',1,'lsc_ep']]],
  ['mult',['mult',['../structlsc__ep.html#a675ff345d9fae5be3eb26c6889c412fe',1,'lsc_ep']]]
];
