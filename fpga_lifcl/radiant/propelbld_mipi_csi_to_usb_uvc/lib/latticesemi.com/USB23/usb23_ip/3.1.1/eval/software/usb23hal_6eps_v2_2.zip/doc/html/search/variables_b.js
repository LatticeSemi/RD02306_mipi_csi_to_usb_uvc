var searchData=
[
  ['no_5fof_5fevent',['no_of_event',['../structlsc__ep__buf__info.html#a82e0a4f3632969eda497b4001972970c',1,'lsc_ep_buf_info']]],
  ['no_5fof_5freq_5fpending',['no_of_req_pending',['../structlsc__ep.html#abc9dd1bc3ef4ae475f24857746573711',1,'lsc_ep']]],
  ['num_5fin_5feps',['num_in_eps',['../structlsc__usb__dev.html#a35117d816458106b04c89c8219c9e230',1,'lsc_usb_dev']]],
  ['num_5fout_5feps',['num_out_eps',['../structlsc__usb__dev.html#aa4b32848486a7eb1caef466e1cdb05b1',1,'lsc_usb_dev']]]
];
