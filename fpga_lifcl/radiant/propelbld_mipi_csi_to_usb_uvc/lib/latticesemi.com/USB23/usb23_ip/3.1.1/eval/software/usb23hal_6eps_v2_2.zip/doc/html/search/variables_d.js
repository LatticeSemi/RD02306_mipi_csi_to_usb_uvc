var searchData=
[
  ['param0',['param0',['../structlsc__ep__params.html#a367db14ec746b5c42747f55e47f0d85b',1,'lsc_ep_params']]],
  ['param1',['param1',['../structlsc__ep__params.html#a1be4a994a90600608f529f399fb4ff52',1,'lsc_ep_params']]],
  ['param2',['param2',['../structlsc__ep__params.html#a1f54c8a03fe0f4a440b280b827209743',1,'lsc_ep_params']]],
  ['parameters',['parameters',['../structlsc__event__epevt.html#a1e052771ea83b31a87bc7fb938c2918c',1,'lsc_event_epevt']]],
  ['phy_5fep_5fnum',['phy_ep_num',['../structlsc__ep.html#a8a42040a6b2e02e809d3cdf1c92cafc7',1,'lsc_ep']]],
  ['phy_5fport_5fnumber',['phy_port_number',['../structlsc__event__gevt.html#a04d4a99aa83da5dfe9a9d9b6d254f2fb',1,'lsc_event_gevt']]],
  ['platformcapabilityuuid',['PlatformCapabilityUUID',['../struct_u_s_b___s_t_d___p_l_a_t_f_o_r_m___c_a_p___d_e_s_c.html#a378057b83fb98c97966e1de51ef2aa5f',1,'USB_STD_PLATFORM_CAP_DESC']]],
  ['pre_5ffetch_5fxfer',['pre_fetch_xfer',['../structuser__ep__cnfg.html#ab5f6a74b475fcc08dc0ba0c07df37c72',1,'user_ep_cnfg']]],
  ['print_5fbuf',['print_buf',['../group__lscusb.html#gab8037627a8ea028766f86ba91abd29c5',1,'print_buf():&#160;main.c'],['../group__lscusb.html#gab8037627a8ea028766f86ba91abd29c5',1,'print_buf():&#160;main.c']]]
];
