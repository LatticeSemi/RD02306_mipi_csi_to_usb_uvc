var searchData=
[
  ['setup_5fdata',['setup_data',['../structlsc__usb__dev__dm.html#ada91096e80f0ffa9a96b2156c7bcce36',1,'lsc_usb_dev_dm']]],
  ['size',['size',['../structlsc__trb.html#adc09fb61ae830e3118aa3c272cfc0910',1,'lsc_trb']]],
  ['status',['status',['../structlsc__event__epevt.html#a7d2148193c7662ecf768af909309a165',1,'lsc_event_epevt']]],
  ['sts',['sts',['../structlsc__ep__req.html#ac85b09d5c9ddf57d59f2c68b4498eb0e',1,'lsc_ep_req']]]
];
