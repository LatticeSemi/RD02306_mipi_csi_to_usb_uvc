var struct___u_s_b___c_o_m_m_o_n___d_e_s_c_r_i_p_t_o_r =
[
    [ "bDescriptorType", "struct___u_s_b___c_o_m_m_o_n___d_e_s_c_r_i_p_t_o_r.html#aec78c801c0e4011a4e72782249ad40a6", null ],
    [ "bLength", "struct___u_s_b___c_o_m_m_o_n___d_e_s_c_r_i_p_t_o_r.html#a49e8d2f750a734ab4e46cdba8c5b4360", null ]
];