var struct_l_s_c___u_s_b20___c_f_g___d_e_s_c =
[
    [ "cfg", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#ab921039a57d1a3483e5482123ebc8cb5", null ],
    [ "ep_in1", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#ab963f5cd33bcdd1a9dad9459c1ed8b75", null ],
    [ "ep_in2", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#a9475d950f1d1b559bfda1daffaaa3e47", null ],
    [ "ep_in3", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#a853b1893fa54dbe511fb8514cc247c33", null ],
    [ "ep_out1", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#ab9ffbdbc39a7843151cac8020f0ef4c8", null ],
    [ "ep_out2", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#af004e2310426c5b27d8a50fc59cbd41f", null ],
    [ "ep_out3", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#a3340eba3c50412df0f30b7bde3471a10", null ],
    [ "intf_alt0", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#ac352618b43a2de6f9fe227a6c7d312d7", null ],
    [ "intf_alt1", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#ada487863977b9fe39b472ed1a14a7337", null ],
    [ "intf_alt2", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#a2ff84dd95dbe19a2276597476dc7f5e8", null ],
    [ "intf_alt3", "struct_l_s_c___u_s_b20___c_f_g___d_e_s_c.html#aa1f226ef7a0a1d32ab0f2ebf004f470f", null ]
];