var struct_l_s_c___u_s_b30___c_f_g___d_e_s_c =
[
    [ "cfg", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#a3d6004fb18a583dd2eefbeaaca426209", null ],
    [ "ep_cmp_in1", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#af255b2d8e839d5647c1baf1a2998307a", null ],
    [ "ep_cmp_in2", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#af02da1a857ea0e9d4e0009c21f6c872f", null ],
    [ "ep_cmp_in3", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#af9443b119b33d450dc33acf6848a88e6", null ],
    [ "ep_cmp_out1", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#a0f05ab12d6dfc29afe45dc0af2ee77c7", null ],
    [ "ep_cmp_out2", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#acb32720574425efe519fe086d4d58858", null ],
    [ "ep_cmp_out3", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#aca2dbef836a7c79372eade6b4f78d0d6", null ],
    [ "ep_in1", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#a2ad801869a3ac0c61018f500b0ef6223", null ],
    [ "ep_in2", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#a1341899b06bdb335749bd06faefc3821", null ],
    [ "ep_in3", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#ae80452f8072e8a5b262dc6225bc8ac76", null ],
    [ "ep_out1", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#aa58899342372d67624096d209aa19146", null ],
    [ "ep_out2", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#af84e6f3e3622c86be15b74edd93ca72e", null ],
    [ "ep_out3", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#af1e98b24328f020d0d3898af345f240a", null ],
    [ "intf_alt0", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#afe054a53abc80abda64398adc4675a77", null ],
    [ "intf_alt1", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#a947ff36bc0eef6d39b6ddac331595781", null ],
    [ "intf_alt2", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#aec520b60bef30fafa1190f5377d4b295", null ],
    [ "intf_alt3", "struct_l_s_c___u_s_b30___c_f_g___d_e_s_c.html#a49e7d69dbc430fc96a3b1441499b4bfd", null ]
];