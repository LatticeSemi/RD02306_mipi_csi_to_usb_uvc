var struct_l_s_c___u_s_b___b_o_s___d_e_s_c =
[
    [ "bos_desc", "struct_l_s_c___u_s_b___b_o_s___d_e_s_c.html#a077ed0e71fc01261ba1e38dfbc25fb8f", null ],
    [ "plat_cap_desc", "struct_l_s_c___u_s_b___b_o_s___d_e_s_c.html#aa1aa808b0d1112cea5e8a7e424fd2178", null ],
    [ "ss_dev_cap", "struct_l_s_c___u_s_b___b_o_s___d_e_s_c.html#a07ef2bfd58c179c9f616582d798bb095", null ],
    [ "u20_ext_desc", "struct_l_s_c___u_s_b___b_o_s___d_e_s_c.html#a35c57a66f1c0f27f2f5f8d9ea28d2427", null ]
];