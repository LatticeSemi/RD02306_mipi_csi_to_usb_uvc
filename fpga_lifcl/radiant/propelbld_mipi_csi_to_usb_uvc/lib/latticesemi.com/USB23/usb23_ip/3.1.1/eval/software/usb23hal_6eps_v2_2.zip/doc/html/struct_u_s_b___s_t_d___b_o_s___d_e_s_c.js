var struct_u_s_b___s_t_d___b_o_s___d_e_s_c =
[
    [ "bDescriptorType", "struct_u_s_b___s_t_d___b_o_s___d_e_s_c.html#a6e735e3959b0da613ba747802f11f486", null ],
    [ "bLength", "struct_u_s_b___s_t_d___b_o_s___d_e_s_c.html#a628a07fe7b5167a5e51e646b3ff29056", null ],
    [ "bNumDeviceCaps", "struct_u_s_b___s_t_d___b_o_s___d_e_s_c.html#aec9e71cac5e0ae58e69db3086490e1b3", null ],
    [ "wTotalLength", "struct_u_s_b___s_t_d___b_o_s___d_e_s_c.html#a74b44c4f8c6d92114a9e4eed2ed8be6e", null ]
];