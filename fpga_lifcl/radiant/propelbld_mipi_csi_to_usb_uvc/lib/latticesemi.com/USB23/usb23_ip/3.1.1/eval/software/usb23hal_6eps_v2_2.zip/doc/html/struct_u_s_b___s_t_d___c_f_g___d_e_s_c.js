var struct_u_s_b___s_t_d___c_f_g___d_e_s_c =
[
    [ "bAttributes", "struct_u_s_b___s_t_d___c_f_g___d_e_s_c.html#a1a0b7fda6b016bf202377168dcc35a98", null ],
    [ "bConfigValue", "struct_u_s_b___s_t_d___c_f_g___d_e_s_c.html#a126dc4604d890e6f9f6652db00c917b5", null ],
    [ "bIConfigString", "struct_u_s_b___s_t_d___c_f_g___d_e_s_c.html#a58401ec0445955f18a587a7405d9e6a4", null ],
    [ "bLength", "struct_u_s_b___s_t_d___c_f_g___d_e_s_c.html#ada617fdc3bf48d753bf717e6cd4f9b50", null ],
    [ "bMaxPower", "struct_u_s_b___s_t_d___c_f_g___d_e_s_c.html#a6f87d43e7765558578688fe90164f618", null ],
    [ "bNumberInterfaces", "struct_u_s_b___s_t_d___c_f_g___d_e_s_c.html#ada06c4c327af9a43c7dca7f9e532d0a9", null ],
    [ "bType", "struct_u_s_b___s_t_d___c_f_g___d_e_s_c.html#aa4cc02d41925f19d15307dd512c749d4", null ],
    [ "wTotalLength", "struct_u_s_b___s_t_d___c_f_g___d_e_s_c.html#a841a92ed8edcb0f9ce2db0456846c57c", null ]
];