var struct_u_s_b___s_t_d___d_e_v___d_e_s_c =
[
    [ "bcdDevice", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#a4cfa8996f8c436347640270eddb70dcf", null ],
    [ "bcdUSB", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#a43570121e7cb86a203a286efd7a5c5c6", null ],
    [ "bDescriptorType", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#ab3a75116732c7d60311e4cb1f9d41cc6", null ],
    [ "bDeviceClass", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#a682b26359e3e27f60c54c0a6bc129eb1", null ],
    [ "bDeviceProtocol", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#aef57a76ea70f0bd7b44da1b18ae56889", null ],
    [ "bDeviceSubClass", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#a676990c16af8da18fff4c2559bb99e3b", null ],
    [ "bLength", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#a3298c2b9c242e3ededab4ca3ead69892", null ],
    [ "bMaxPacketSize0", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#a5c859b73b480778fcce21edbeb14dbe8", null ],
    [ "bNumConfigurations", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#a2c84591e185deffd331e1d32b5f85252", null ],
    [ "idProduct", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#aa487853339209d7c7ae1cd78eaf8b9fa", null ],
    [ "idVendor", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#af7e2587a06760c2a05132102a0b6b577", null ],
    [ "iManufacturer", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#ad742ce5cf05657c7abffd8afc526317d", null ],
    [ "iProduct", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#a7ff68aec2ab5cf9ee04562d0c244e1e5", null ],
    [ "iSerialNumber", "struct_u_s_b___s_t_d___d_e_v___d_e_s_c.html#a7f276425d99b8e6f27fb5fcc61bc06a4", null ]
];