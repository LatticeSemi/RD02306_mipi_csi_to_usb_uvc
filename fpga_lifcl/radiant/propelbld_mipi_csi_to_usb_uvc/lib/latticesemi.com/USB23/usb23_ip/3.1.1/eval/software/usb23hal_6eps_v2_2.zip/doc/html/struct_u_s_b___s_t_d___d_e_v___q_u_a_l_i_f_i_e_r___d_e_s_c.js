var struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c =
[
    [ "bcdUSB", "struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c.html#abd46b46113c3641e2f8a5ae421c2b653", null ],
    [ "bDescriptorType", "struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c.html#af7a599c8db9d0d3bbb72a64965673141", null ],
    [ "bDeviceClass", "struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c.html#abb28743a23ee7e2bb7b635379eb3747a", null ],
    [ "bDeviceProtocol", "struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c.html#a3c6ca19c7b23fa0105c48cc1f29b41be", null ],
    [ "bDeviceSubClass", "struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c.html#a0a604bf0cdb24f35e5dd9373a09dd337", null ],
    [ "bLength", "struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c.html#a9563360e9035e891de1c91241d5afad6", null ],
    [ "bMaxPacketSize0", "struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c.html#a6f7cba4debe8d8429d8ec9090514c05a", null ],
    [ "bNumConfiguration", "struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c.html#a75879b9d64c5bfed3e9529edbf5b525c", null ],
    [ "bReserved", "struct_u_s_b___s_t_d___d_e_v___q_u_a_l_i_f_i_e_r___d_e_s_c.html#a34e3eb70dab74ffeefaa745863b53907", null ]
];