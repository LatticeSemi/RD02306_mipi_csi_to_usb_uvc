var struct_u_s_b___s_t_d___e_p___d_e_s_c =
[
    [ "bDescriptorType", "struct_u_s_b___s_t_d___e_p___d_e_s_c.html#af820ec3d9055d11fcbc335c89597d184", null ],
    [ "bEndpointAddress", "struct_u_s_b___s_t_d___e_p___d_e_s_c.html#a0605bed1bd76e8ac955bc279a2034805", null ],
    [ "bInterval", "struct_u_s_b___s_t_d___e_p___d_e_s_c.html#a06aaef0d77d1a459112eaed7ab940d6b", null ],
    [ "bLength", "struct_u_s_b___s_t_d___e_p___d_e_s_c.html#a56a689ab9cea8fb04b22e5352dedd8de", null ],
    [ "bmAttributes", "struct_u_s_b___s_t_d___e_p___d_e_s_c.html#a8c377455281a9906b780a3d5bc3ef983", null ],
    [ "bMaxPacketSize", "struct_u_s_b___s_t_d___e_p___d_e_s_c.html#abefd5272a4db60c9c49aa887fbd4d0e7", null ]
];