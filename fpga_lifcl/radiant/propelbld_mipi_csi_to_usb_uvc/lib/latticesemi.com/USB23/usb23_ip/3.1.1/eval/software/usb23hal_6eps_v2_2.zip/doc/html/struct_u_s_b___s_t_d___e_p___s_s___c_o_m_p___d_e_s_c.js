var struct_u_s_b___s_t_d___e_p___s_s___c_o_m_p___d_e_s_c =
[
    [ "bDescriptorType", "struct_u_s_b___s_t_d___e_p___s_s___c_o_m_p___d_e_s_c.html#a0893416c06e93292aebb7c5aa8b5deff", null ],
    [ "bLength", "struct_u_s_b___s_t_d___e_p___s_s___c_o_m_p___d_e_s_c.html#a05cdfa8e472e39a170a56b7649a21073", null ],
    [ "bmAttributes", "struct_u_s_b___s_t_d___e_p___s_s___c_o_m_p___d_e_s_c.html#a3052e690eb53ef0c6d4ddb9cb90c5f46", null ],
    [ "bMaxBurst", "struct_u_s_b___s_t_d___e_p___s_s___c_o_m_p___d_e_s_c.html#a46f34cb5e11f880a75427f84cf7d3389", null ],
    [ "wBytesPerInterval", "struct_u_s_b___s_t_d___e_p___s_s___c_o_m_p___d_e_s_c.html#a82be41612429ac14e1d3a2b35aa78105", null ]
];