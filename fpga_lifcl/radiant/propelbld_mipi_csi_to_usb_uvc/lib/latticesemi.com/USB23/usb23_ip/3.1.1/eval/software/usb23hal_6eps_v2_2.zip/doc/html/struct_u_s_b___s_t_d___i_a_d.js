var struct_u_s_b___s_t_d___i_a_d =
[
    [ "bDescriptorType", "struct_u_s_b___s_t_d___i_a_d.html#a64c37f969b07eae5e22eb76c0385d907", null ],
    [ "bFirstInterface", "struct_u_s_b___s_t_d___i_a_d.html#a8220b600ec8b7ec03ea32b623c43448e", null ],
    [ "bFunctionClass", "struct_u_s_b___s_t_d___i_a_d.html#af0318f13f2c9275b6d91cc3495f7e901", null ],
    [ "bFunctionProtocol", "struct_u_s_b___s_t_d___i_a_d.html#adbab83093d18220fa229f5084b4b7f0e", null ],
    [ "bFunctionSubClass", "struct_u_s_b___s_t_d___i_a_d.html#aeade790ca3934a9321f6a7b0f90ad01c", null ],
    [ "bInterfaceCount", "struct_u_s_b___s_t_d___i_a_d.html#a56fe64fb48a9401b409a42a507dba529", null ],
    [ "bLength", "struct_u_s_b___s_t_d___i_a_d.html#ac3a0f14237ed383f6984fbd418ceeaa1", null ],
    [ "iFunction", "struct_u_s_b___s_t_d___i_a_d.html#a7811ead7065437e1b6341765e286342e", null ]
];