var struct_u_s_b___s_t_d___i_f___d_e_s_c =
[
    [ "bAlternateSetting", "struct_u_s_b___s_t_d___i_f___d_e_s_c.html#a9815da11618e105cf82134f6f9ebf80b", null ],
    [ "bDescriptorType", "struct_u_s_b___s_t_d___i_f___d_e_s_c.html#abaeb88dfd3a13a3d5c5b3510306c1c87", null ],
    [ "bInterfaceClass", "struct_u_s_b___s_t_d___i_f___d_e_s_c.html#a1bd7ef7bac546d25172169abf53aaff0", null ],
    [ "bInterfaceNumber", "struct_u_s_b___s_t_d___i_f___d_e_s_c.html#a9b92932e24bb8097da9f87bf77cb5d50", null ],
    [ "bInterfaceProtocol", "struct_u_s_b___s_t_d___i_f___d_e_s_c.html#a5f955c7385638edd516fd5ae1b950d19", null ],
    [ "bInterfaceSubClass", "struct_u_s_b___s_t_d___i_f___d_e_s_c.html#a685c3379c36bd8fe2ec5a69a0e23611c", null ],
    [ "bLength", "struct_u_s_b___s_t_d___i_f___d_e_s_c.html#a5fe500f8f6a784e45fb0eed93e946067", null ],
    [ "bNumEndPoints", "struct_u_s_b___s_t_d___i_f___d_e_s_c.html#a90a91643bfda1773e38b460264cfb7ef", null ],
    [ "iInterface", "struct_u_s_b___s_t_d___i_f___d_e_s_c.html#ac5f1ad7dc33889d9e340791bc7791986", null ]
];