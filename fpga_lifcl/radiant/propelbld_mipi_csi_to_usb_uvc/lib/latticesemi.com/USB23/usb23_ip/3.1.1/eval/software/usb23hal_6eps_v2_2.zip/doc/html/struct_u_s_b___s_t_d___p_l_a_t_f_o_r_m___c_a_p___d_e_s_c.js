var struct_u_s_b___s_t_d___p_l_a_t_f_o_r_m___c_a_p___d_e_s_c =
[
    [ "bDescriptorType", "struct_u_s_b___s_t_d___p_l_a_t_f_o_r_m___c_a_p___d_e_s_c.html#ae99b61591a664b7c8a5f4d278cf4ced5", null ],
    [ "bDevCapabiltyType", "struct_u_s_b___s_t_d___p_l_a_t_f_o_r_m___c_a_p___d_e_s_c.html#aaa98551c2b1da9ce1fb93131f9f24dd2", null ],
    [ "bLength", "struct_u_s_b___s_t_d___p_l_a_t_f_o_r_m___c_a_p___d_e_s_c.html#aec6173a76108bfe48bb80e2d898c179a", null ],
    [ "bReserved", "struct_u_s_b___s_t_d___p_l_a_t_f_o_r_m___c_a_p___d_e_s_c.html#af0af2be699fd825ee63efd0e4c3121e6", null ],
    [ "CapabilityData", "struct_u_s_b___s_t_d___p_l_a_t_f_o_r_m___c_a_p___d_e_s_c.html#a8651a47d6b188e68e30fdf18d1d0193d", null ],
    [ "PlatformCapabilityUUID", "struct_u_s_b___s_t_d___p_l_a_t_f_o_r_m___c_a_p___d_e_s_c.html#a378057b83fb98c97966e1de51ef2aa5f", null ]
];