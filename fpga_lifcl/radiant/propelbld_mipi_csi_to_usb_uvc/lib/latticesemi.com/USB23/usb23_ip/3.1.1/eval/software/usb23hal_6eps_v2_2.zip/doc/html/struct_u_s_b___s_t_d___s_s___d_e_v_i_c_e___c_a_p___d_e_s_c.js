var struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c =
[
    [ "bDescriptorType", "struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html#ad60e83a6f53be792a398629463044812", null ],
    [ "bDevCapabiltyType", "struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html#a22ec320e2885a8792034aae4e3eecd84", null ],
    [ "bFunctionalitySupport", "struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html#a7a126e77c6b579b235354f351a90d03a", null ],
    [ "bLength", "struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html#a6c332ed99d34f9041c08819d7cd680c6", null ],
    [ "bmAttributes", "struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html#a385f4ee31d5070b66ed3bc46df2121a5", null ],
    [ "bU1DevExitLat", "struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html#aa1326609f69762bd51165a92f803caf9", null ],
    [ "wSpeedsSupported", "struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html#a07fba4b09c9f0e2c6d753911b6f17d12", null ],
    [ "wU2DevExitLat", "struct_u_s_b___s_t_d___s_s___d_e_v_i_c_e___c_a_p___d_e_s_c.html#ad2e266e8757fe6a5162502ce2af16289", null ]
];