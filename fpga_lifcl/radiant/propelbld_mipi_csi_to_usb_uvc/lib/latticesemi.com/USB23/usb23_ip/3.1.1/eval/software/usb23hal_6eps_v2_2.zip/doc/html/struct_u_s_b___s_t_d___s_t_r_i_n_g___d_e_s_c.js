var struct_u_s_b___s_t_d___s_t_r_i_n_g___d_e_s_c =
[
    [ "bDescriptorType", "struct_u_s_b___s_t_d___s_t_r_i_n_g___d_e_s_c.html#a2de342fa9d75d2979f4fd37b3de9cb82", null ],
    [ "bLength", "struct_u_s_b___s_t_d___s_t_r_i_n_g___d_e_s_c.html#a1cf87029254b7e59f368e72772a5af57", null ],
    [ "wLANGID", "struct_u_s_b___s_t_d___s_t_r_i_n_g___d_e_s_c.html#a117ba8d20bc7b81e32f130c590acac58", null ]
];