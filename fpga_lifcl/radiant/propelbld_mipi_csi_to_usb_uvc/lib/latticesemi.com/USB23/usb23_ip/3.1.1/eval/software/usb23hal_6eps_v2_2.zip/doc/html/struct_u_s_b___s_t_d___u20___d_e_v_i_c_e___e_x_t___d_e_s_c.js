var struct_u_s_b___s_t_d___u20___d_e_v_i_c_e___e_x_t___d_e_s_c =
[
    [ "bDescriptorType", "struct_u_s_b___s_t_d___u20___d_e_v_i_c_e___e_x_t___d_e_s_c.html#a202c7904811cb05d3929990f3037e849", null ],
    [ "bDevCapabiltyType", "struct_u_s_b___s_t_d___u20___d_e_v_i_c_e___e_x_t___d_e_s_c.html#a8f0d57be60c7452287be84906852450b", null ],
    [ "bLength", "struct_u_s_b___s_t_d___u20___d_e_v_i_c_e___e_x_t___d_e_s_c.html#a4d13c93ee434002d9ecac8de31451593", null ],
    [ "bmAttributes", "struct_u_s_b___s_t_d___u20___d_e_v_i_c_e___e_x_t___d_e_s_c.html#ad9b735fd45959c6ae6adeaaa11fc07f7", null ]
];