var structlsc__dev__iebm__eps =
[
    [ "usb_dev", "structlsc__dev__iebm__eps.html#a32464888b8fbf767a7ced226817143be", null ],
    [ "usb_ep_no", "structlsc__dev__iebm__eps.html#af825c1b68ee9aa34fa5982d676c40e6d", null ]
];