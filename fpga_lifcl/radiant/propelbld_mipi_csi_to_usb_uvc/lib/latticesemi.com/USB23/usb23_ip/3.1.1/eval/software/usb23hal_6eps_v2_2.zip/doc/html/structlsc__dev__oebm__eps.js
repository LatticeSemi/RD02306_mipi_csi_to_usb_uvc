var structlsc__dev__oebm__eps =
[
    [ "usb_dev", "structlsc__dev__oebm__eps.html#a8170c7e93d557898c2637e220f1484fd", null ],
    [ "usb_ep_no", "structlsc__dev__oebm__eps.html#ae88ee0f672a3d142382da3cbc17ad91e", null ]
];