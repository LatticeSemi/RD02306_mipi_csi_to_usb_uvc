var structlsc__ep__buf__info =
[
    [ "buf_ptr", "structlsc__ep__buf__info.html#a9118028d9aa734e067470996acaf1578", null ],
    [ "buf_size", "structlsc__ep__buf__info.html#a3bffd5c94183f41b5b00f6b12ea1cb4b", null ],
    [ "no_of_event", "structlsc__ep__buf__info.html#a82e0a4f3632969eda497b4001972970c", null ]
];