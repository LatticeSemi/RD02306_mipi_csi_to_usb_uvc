var structlsc__ep__params =
[
    [ "param0", "structlsc__ep__params.html#a367db14ec746b5c42747f55e47f0d85b", null ],
    [ "param1", "structlsc__ep__params.html#a1be4a994a90600608f529f399fb4ff52", null ],
    [ "param2", "structlsc__ep__params.html#a1f54c8a03fe0f4a440b280b827209743", null ]
];