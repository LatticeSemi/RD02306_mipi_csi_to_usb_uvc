var structlsc__ep__req =
[
    [ "act_len", "structlsc__ep__req.html#a90d6f9d779787a2579d380148b8fe934", null ],
    [ "bufr_ptr", "structlsc__ep__req.html#a41917cb9bd4bc21431fc944372602996", null ],
    [ "req_len", "structlsc__ep__req.html#a1868674c554638e317db9717811d59be", null ],
    [ "sts", "structlsc__ep__req.html#ac85b09d5c9ddf57d59f2c68b4498eb0e", null ]
];