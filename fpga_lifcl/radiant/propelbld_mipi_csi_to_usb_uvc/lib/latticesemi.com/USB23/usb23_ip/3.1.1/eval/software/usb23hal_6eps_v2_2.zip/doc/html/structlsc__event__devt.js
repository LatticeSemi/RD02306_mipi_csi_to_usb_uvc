var structlsc__event__devt =
[
    [ "dev_event", "structlsc__event__devt.html#ac235fa3b97cb304ddeb7fd071aed2500", null ],
    [ "dev_evt_type", "structlsc__event__devt.html#a668d8de799492a30f86719b7c8ce8770", null ],
    [ "evt_info", "structlsc__event__devt.html#a220af582887f2464662598acaaeef574", null ],
    [ "is_dev_evt", "structlsc__event__devt.html#af8ac7517e6472d6edd74e0eb2f7adb1c", null ],
    [ "reserved15_12", "structlsc__event__devt.html#ae418c12360b1afa7e682828d8f4c002d", null ],
    [ "reserved31_25", "structlsc__event__devt.html#afe71a1150491fedb5987871d427f2f1a", null ]
];