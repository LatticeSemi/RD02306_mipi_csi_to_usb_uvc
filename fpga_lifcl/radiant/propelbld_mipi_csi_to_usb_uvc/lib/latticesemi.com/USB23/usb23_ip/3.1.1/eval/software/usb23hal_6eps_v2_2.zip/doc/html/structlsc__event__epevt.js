var structlsc__event__epevt =
[
    [ "ep_event", "structlsc__event__epevt.html#abd7d385090e06d6edc66675b9c0bfd36", null ],
    [ "ep_number", "structlsc__event__epevt.html#a990163c2f16dce2fa714da215b92a966", null ],
    [ "is_ep_evt", "structlsc__event__epevt.html#a332e886d27ccc57f72efc41d9cafbd1e", null ],
    [ "parameters", "structlsc__event__epevt.html#a1e052771ea83b31a87bc7fb938c2918c", null ],
    [ "reserved11_10", "structlsc__event__epevt.html#a018066eebbd353d2cd8d44324384c05d", null ],
    [ "status", "structlsc__event__epevt.html#a7d2148193c7662ecf768af909309a165", null ]
];