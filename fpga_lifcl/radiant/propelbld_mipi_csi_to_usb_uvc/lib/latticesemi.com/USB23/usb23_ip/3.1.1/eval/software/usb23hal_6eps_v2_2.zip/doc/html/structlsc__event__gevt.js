var structlsc__event__gevt =
[
    [ "dev_event", "structlsc__event__gevt.html#a8ee61081b86297e5d58b1b47b2121576", null ],
    [ "is_global_evt", "structlsc__event__gevt.html#aa435d56b75b6a4781ca8b4ea85562c93", null ],
    [ "phy_port_number", "structlsc__event__gevt.html#a04d4a99aa83da5dfe9a9d9b6d254f2fb", null ],
    [ "reserved31_12", "structlsc__event__gevt.html#a10325b2cecd893fcdf0091ef96e1f379", null ]
];