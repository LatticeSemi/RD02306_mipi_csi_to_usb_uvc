var structlsc__event__type =
[
    [ "is_dev_evt", "structlsc__event__type.html#a5292a67b5a5bad6d204e0174448806bc", null ],
    [ "reserved8_31", "structlsc__event__type.html#a4792cc35e2f53c4275253344aeb1d290", null ],
    [ "type", "structlsc__event__type.html#a63b190b9ad1a6b491858e1cd3be57c20", null ]
];