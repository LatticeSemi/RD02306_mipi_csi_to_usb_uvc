var structlsc__evt__buffer =
[
    [ "buf_add", "structlsc__evt__buffer.html#a92da120389942d8e4bf7ada9c00323b4", null ],
    [ "count", "structlsc__evt__buffer.html#a0a186105f5f5c3a79ea536db513e5827", null ],
    [ "flags", "structlsc__evt__buffer.html#a0c6d28d61a831c7fd9483daca275843d", null ],
    [ "offset", "structlsc__evt__buffer.html#ae15afff2d4a45fe3cae77f40e971814a", null ]
];