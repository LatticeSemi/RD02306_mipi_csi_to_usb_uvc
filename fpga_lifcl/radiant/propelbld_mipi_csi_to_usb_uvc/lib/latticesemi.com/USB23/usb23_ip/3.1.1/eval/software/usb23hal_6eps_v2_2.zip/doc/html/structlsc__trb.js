var structlsc__trb =
[
    [ "buf_ptr_hi", "structlsc__trb.html#a33605f3beaf72c263a9b7d44533d891e", null ],
    [ "buf_ptr_lo", "structlsc__trb.html#a42bc49c62685d274f3615e664f441db7", null ],
    [ "ctrl", "structlsc__trb.html#ae612a0e2901bf0ad206dfbc925e13ec2", null ],
    [ "size", "structlsc__trb.html#adc09fb61ae830e3118aa3c272cfc0910", null ]
];