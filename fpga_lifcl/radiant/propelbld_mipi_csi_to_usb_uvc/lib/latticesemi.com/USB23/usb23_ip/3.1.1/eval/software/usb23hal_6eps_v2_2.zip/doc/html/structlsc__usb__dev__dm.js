var structlsc__usb__dev__dm =
[
    [ "ep0_trb", "structlsc__usb__dev__dm.html#a6fbd514fb3caf7e17bb074008189bad0", null ],
    [ "ep_trb", "structlsc__usb__dev__dm.html#aaa43619ba570f3b19f887d7ac713f8c9", null ],
    [ "event_buf", "structlsc__usb__dev__dm.html#a347531ea6a1b7db0ddca573684841caf", null ],
    [ "setup_data", "structlsc__usb__dev__dm.html#ada91096e80f0ffa9a96b2156c7bcce36", null ]
];