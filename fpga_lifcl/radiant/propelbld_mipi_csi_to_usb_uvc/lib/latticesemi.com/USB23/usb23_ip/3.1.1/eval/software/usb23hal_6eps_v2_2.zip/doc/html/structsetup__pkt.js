var structsetup__pkt =
[
    [ "bRequest", "structsetup__pkt.html#a9f8c190916a9d477fa762abe5e0ecf75", null ],
    [ "bRequestType", "structsetup__pkt.html#a34daca51150ba65ec7742a29436f4415", null ],
    [ "wIndex", "structsetup__pkt.html#aa558b0329a1fe378cb7502ddf5c0db65", null ],
    [ "wLength", "structsetup__pkt.html#aa8cb75f9118dafdf9644e86feee8f346", null ],
    [ "wValue", "structsetup__pkt.html#adafdb7b0a59748753cfecbb73066d264", null ]
];