var structtiming =
[
    [ "u1pel", "structtiming.html#a73df3ffeb157a5051fc6cc59e6e9aa12", null ],
    [ "u1sel", "structtiming.html#a94dfed8aeb77f3440beb6b55d348fb78", null ],
    [ "u2pel", "structtiming.html#a13a9854b6cfe7da5475fe1358e159bfe", null ],
    [ "u2sel", "structtiming.html#ae3304319522ad718ed70bcd59edaf4f4", null ]
];