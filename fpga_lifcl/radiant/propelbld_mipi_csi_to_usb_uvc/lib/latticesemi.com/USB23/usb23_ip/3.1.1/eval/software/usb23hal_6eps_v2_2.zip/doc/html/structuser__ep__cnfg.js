var structuser__ep__cnfg =
[
    [ "dis_cb", "structuser__ep__cnfg.html#acf054b139925f93a2e66d3eacb7c78d2", null ],
    [ "disp_xfer_len", "structuser__ep__cnfg.html#aa5703c7dc6e573e708fa63ad5d2eec00", null ],
    [ "disp_xferred_data", "structuser__ep__cnfg.html#ad0900ca37990b5d69d11785f0ad933e8", null ],
    [ "ebm_fw_single_bufr_depth", "structuser__ep__cnfg.html#ab33648aba03ac1efe0b20dae21ac8f26", null ],
    [ "ebm_fw_total_bufrs", "structuser__ep__cnfg.html#a327bbcaba483154ccad1347163cb8af5", null ],
    [ "ebm_irq", "structuser__ep__cnfg.html#a5c44e39723fdbac5515dca9020099cbd", null ],
    [ "ebm_mem_base_8", "structuser__ep__cnfg.html#a4a22f6f454bc40982425ba46341bfa7b", null ],
    [ "ebm_reg_base_8", "structuser__ep__cnfg.html#a535b202d7072068fce037e3b249f5c57", null ],
    [ "ebm_total_bufr_span", "structuser__ep__cnfg.html#ac5cd3812397ac95dada42d28423aaead", null ],
    [ "en_cb", "structuser__ep__cnfg.html#a8f31ff7c71d4f71d37b744211ce7d79a", null ],
    [ "ep_req_queue_size", "structuser__ep__cnfg.html#a420214bbf86a0786df984cd14c9e0985", null ],
    [ "ep_trb_slots", "structuser__ep__cnfg.html#aa616553c127d6d9e34fa66f337f1edb8", null ],
    [ "fifo_based_ebm_avail", "structuser__ep__cnfg.html#a32e5a8ff50de6f1226b8d070267317f9", null ],
    [ "init_cb", "structuser__ep__cnfg.html#a55c40c9842cddbba36e28d0831abc29e", null ],
    [ "pre_fetch_xfer", "structuser__ep__cnfg.html#ab5f6a74b475fcc08dc0ba0c07df37c72", null ],
    [ "xfer_completion_cb", "structuser__ep__cnfg.html#a39869f0f1248ec00f1bd9d0a1af4c5a7", null ],
    [ "xfer_req_cb", "structuser__ep__cnfg.html#ad704b9bf90a8f9c89ead72a82cba46fb", null ]
];