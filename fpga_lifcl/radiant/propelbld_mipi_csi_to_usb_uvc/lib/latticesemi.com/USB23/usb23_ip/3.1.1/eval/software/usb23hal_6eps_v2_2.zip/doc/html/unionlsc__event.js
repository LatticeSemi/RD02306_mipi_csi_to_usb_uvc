var unionlsc__event =
[
    [ "dev_evt", "unionlsc__event.html#a8e27287161c5e88817fa2250f8b18a64", null ],
    [ "ep_evt", "unionlsc__event.html#a49ea2f21a1db4fd2802c8d548d2a548a", null ],
    [ "evt_type", "unionlsc__event.html#aa7ff91848d41487b8124370e4b9b200b", null ],
    [ "gl_evt", "unionlsc__event.html#a574c8d846926c054d214e887546d6d21", null ],
    [ "val", "unionlsc__event.html#a98fb3eba3a4020980f1019ab92f6d57c", null ]
];