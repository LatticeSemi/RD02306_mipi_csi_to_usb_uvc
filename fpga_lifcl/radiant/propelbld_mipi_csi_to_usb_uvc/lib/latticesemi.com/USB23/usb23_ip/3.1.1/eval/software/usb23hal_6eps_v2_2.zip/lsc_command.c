/****************************************************************************/
/**
 *
 * @file lsc_command.c
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/

#include <stdio.h>
#include "lsc_usb_dev.h"
#include "lsc_usb_ch9.h"

//#define DEBUG_LSC_CMD

#ifdef DEBUG_LSC_CMD
#define LSC_CMD(msg, ...) sprintf(print_buf, msg, ##__VA_ARGS__); lsc_uart_tx(print_buf)
#else
#define LSC_CMD(msg, ...)
#endif

extern const struct user_ep_cnfg out_user_ep_cnfg[16];
extern const struct user_ep_cnfg in_user_ep_cnfg[16];
extern struct lsc_usb_dev_dm usb_dev_dm;

/****************************************************************************/
/**
 * Returns zeroed parameters to be used by Endpoint commands
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 *
 * @return   Zeroed Params structure pointer.
 *
 * @note     None.
 *****************************************************************************/
struct lsc_ep_params* lsc_usb_get_ep_params (struct lsc_usb_dev *usb_dev)
{
    LSC_CMD("lsc_usb_get_ep_params\r\n");

// Setting ep_params to zero.
    usb_dev->ep_params.param0 = 0x00;
    usb_dev->ep_params.param1 = 0x00;
    usb_dev->ep_params.param2 = 0x00;

    return &usb_dev->ep_params;

}

/****************************************************************************/
/**
 * This function sends physical endpoint-specific commands.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction of endpoint
 *           - LSC_EP_DIR_IN/ LSC_EP_DIR_OUT.
 * @param    cmd is Endpoint command.
 * @param    params is Endpoint command parameters.
 *
 * @return   LSC_SUCCESS if the command was sent successfully, else LSC_FAIL.
 *
 * @note     Refer sec 3.2.2 of Synopsis Programming Guide Version 3.30b
 *           for detailed information about various physical endpoint-specific
 *           commands.
 * @note     Refer https://elixir.bootlin.com/linux/v6.12.5/source/drivers/usb/dwc3/gadget.c#L308
 *****************************************************************************/
uint32_t lsc_usb_send_ep_cmd (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num,
        uint8_t dir, uint32_t cmd, struct lsc_ep_params *params)
{
    LSC_CMD("lsc_usb_send_ep_cmd\r\n");

    uint32_t phy_ep_num, saved_config = 0, reg = 0;
    uint32_t ret = LSC_FAIL, cmd_status;
    uint32_t timeout = 5000;
    struct lsc_ep *ep = NULL;

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);
    ep = &usb_dev->eps[phy_ep_num];

    // When operating at USB 2.0 speeds (HS/FS), if either GUSB2PHYCFG.ENBLSLPM or
    // GUSB2PHYCFG.SUSPHY is set, it must be cleared before issuing an endpoint command.
    //
    // Save and clear both GUSB2PHYCFG.ENBLSLPM and GUSB2PHYCFG.SUSPHY settings.
    // Restore them after the command is completed.
    // Refer https://elixir.bootlin.com/linux/v6.12.5/source/drivers/usb/dwc3/gadget.c#L308

    if ((usb_dev->dev_speed < LSC_DCFG_SUPERSPEED)
            || (LSC_DEPCMD_CMD(cmd) == LSC_DEPCMD_ENDTRANSFER)) {

        // Read the USB2PHYCFG register
        reg = lsc_32_read(usb_dev->base_add + LSC_GUSB2PHYCFG(0));

        // Check for SUSPHY bit
        if ((reg & LSC_GUSB2PHYCFG_SUSPHY)) {
            saved_config |= LSC_GUSB2PHYCFG_SUSPHY;
            reg &= ~LSC_GUSB2PHYCFG_SUSPHY;
        }

        // Check for ENBLSLPM bit
        if (reg & LSC_GUSB2PHYCFG_ENBLSLPM) {
            saved_config |= LSC_GUSB2PHYCFG_ENBLSLPM;
            reg &= ~LSC_GUSB2PHYCFG_ENBLSLPM;
        }

        // Write back the register if any bit was cleared
        if (saved_config)
            lsc_32_write((usb_dev->base_add + LSC_GUSB2PHYCFG(0)), reg);
    }

    /*
     * For some commands such as Update Transfer command, DEPCMDPARn
     * registers are reserved. Since the driver often sends Update Transfer
     * command, don't write to DEPCMDPARn to avoid register write delays and
     * improve performance.
     */
    if (LSC_DEPCMD_CMD(cmd) != LSC_DEPCMD_UPDATETRANSFER) {

        lsc_32_write((usb_dev->base_add + LSC_DEPCMDPAR0(phy_ep_num)),
                params->param0);
        lsc_32_write((usb_dev->base_add + LSC_DEPCMDPAR1(phy_ep_num)),
                params->param1);
        lsc_32_write((usb_dev->base_add + LSC_DEPCMDPAR2(phy_ep_num)),
                params->param2);

    }

    /*
     * if we're not relying on XferNotReady, we can make use of a special "No
     * Response Update Transfer" command where we should clear both CmdAct
     * and CmdIOC bits.
     *
     * With this, we don't need to wait for command completion and can
     * straight away issue further commands to the endpoint.
     *
     * NOTICE: We're making an assumption that control endpoints will never
     * make use of Update Transfer command. This is a safe assumption
     * because we can never have more than one request at a time with
     * Control Endpoints. If anybody changes that assumption, this chunk
     * needs to be updated accordingly.
     */
    if ((LSC_DEPCMD_CMD(cmd) == LSC_DEPCMD_UPDATETRANSFER)
            && (ep->ep_type != LSC_ENDPOINT_XFER_ISOC)) {
        cmd &= ~(LSC_DEPCMD_CMDIOC | LSC_DEPCMD_CMDACT);
    } else {
        cmd |= LSC_DEPCMD_CMDACT;
    }

    lsc_32_write((usb_dev->base_add + LSC_DEPCMD(phy_ep_num)), cmd);

    if (!(cmd & LSC_DEPCMD_CMDACT)
            || (LSC_DEPCMD_CMD(cmd) == LSC_DEPCMD_ENDTRANSFER
                    && !(cmd & LSC_DEPCMD_CMDIOC))) {
        ret = LSC_SUCCESS;
        goto skip_status;
    }

    do {
        reg = lsc_32_read(usb_dev->base_add + LSC_DEPCMD(phy_ep_num));

        if (!(reg & LSC_DEPCMD_CMDACT)) {
            cmd_status = LSC_DEPCMD_STATUS(reg);
            switch (cmd_status) {
                case 0:
                    ret = LSC_SUCCESS;
                    break;

                case DEPEVT_TRANSFER_NO_RESOURCE:
                    printf("No_Transfer_resource_index\r\n");
                    break;

                case DEPEVT_TRANSFER_BUS_EXPIRY:
                    /*
                     * SW issues START TRANSFER command to
                     * isochronous ep with future frame interval. If
                     * future interval time has already passed when
                     * core receives the command, it will respond
                     * with an error status of 'Bus Expiry'.
                     */
                    printf("Bus Expiry\r\n");
                    break;

                default:
                    printf("unknown status %x\r\n",cmd_status);
            }

            break;
        }

    } while (--timeout);

    if (timeout == 0) {
        printf("Timeout\r\n");
    }

skip_status:

    if (LSC_DEPCMD_CMD(cmd) == LSC_DEPCMD_ENDTRANSFER
            && !(cmd & LSC_DEPCMD_CMDIOC)) {
        lsc_usb_usleep(1000);
    }

    // Restore the saved configuration
    if (saved_config) {
        reg = lsc_32_read(usb_dev->base_add + LSC_GUSB2PHYCFG(0));
        reg |= saved_config;
        lsc_32_write((usb_dev->base_add + LSC_GUSB2PHYCFG(0)), reg);
    }

    return ret;
}

/**
 * This function sends generic commands.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    cmd is the command to be sent.
 * @param    param is the parameter for the command.
 *
 * @return   LSC_SUCCESS if the command was sent successfully, else LSC_FAIL.
 */
uint32_t lsc_usb_send_generic_cmd (struct lsc_usb_dev *usb_dev, uint32_t cmd,
        uint32_t param)
{
    LSC_CMD("lsc_usb_send_generic_cmd\r\n");

    uint32_t reg_val = 0;

    lsc_32_write((usb_dev->base_add + LSC_DGCMDPAR), param);

    lsc_32_write((usb_dev->base_add + LSC_DGCMD), (cmd | LSC_DGCMD_CMDACT));

    // Poll CMDACT
    while (lsc_32_read(usb_dev->base_add + LSC_DGCMD) & LSC_DGCMD_CMDACT)
        ;

    reg_val = lsc_32_read(usb_dev->base_add + LSC_DGCMD);

    //Extracts the command status
    reg_val = LSC_DGCMD_STATUS(reg_val);

    // Check the status of the command
    if (reg_val != 0) {
        LSC_CMD("DGCMD_status_failed 0x%x\r\n",reg_val);
        return LSC_FAIL;
    }

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * @brief
 * Enables Endpoint for sending/receiving data. Endpoints are
 * enabled using Start New Configuration (DEPSTARTCFG) and
 * Set Endpoint Configuration (DEPCFG)
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction of endpoint
 *               - LSC_EP_DIR_IN/ LSC_EP_DIR_OUT.
 * @param    max_size is size of Endpoint size.
 * @param    ep_type is Endpoint type Control/Bulk/Interrupt/Isoc.
 * @param    restore should be true if saved state should be restored;
 *           typically this would be false
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note     Refer sec 3.2.2 of Synopsis Programming Guide Version 3.30b
 *           for Physical Endpoint-Specific Command Structure.
 ****************************************************************************/
uint32_t lsc_usb_ctrl_ep_enable (struct lsc_usb_dev *usb_dev,
        uint8_t usb_ep_num, uint8_t dir, uint16_t max_size, uint8_t ep_type,
        uint8_t restore)
{
    LSC_CMD("lsc_usb_ctrl_ep_enable\r\n");

    LSC_CMD("usb_ep_num: %x\tdir: %x\tmax_size: %x\tep_type: %x\r\n", usb_ep_num, dir, max_size, ep_type);

    struct lsc_ep *ep;
    uint32_t reg_val;
    uint32_t phy_ep_num;
    bool modify_ep_state;

    struct user_ep_cnfg sel_ep_user_cnfg;

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);
    ep = &usb_dev->eps[phy_ep_num];

    LSC_CMD("phy_ep_num: %x\tep->ep_status: %x\r\n", phy_ep_num, ep->ep_status);

    ep->usb_ep_num = usb_ep_num;
    ep->ep_direction = dir;
    ep->ep_type = ep_type;
    ep->max_ep_size = max_size;
    ep->phy_ep_num = phy_ep_num;
    ep->cur_micro_frame = 0;

    ep->no_of_req_pending = 0;
    ep->req_enqueue_ptr = 0;
    ep->req_dequeue_ptr = 0;
    ep->req_completion_tracker = 0;

    ep->ebm_usb_bufr_tracker = 0;
    ep->ebm_ip_bufr_tracker = 0;
    ep->ebm_init_done = false;
    ep->ebm_bufr_span = 0;
    ep->maxburst = 0;
    ep->bInterval = 0;

    // Get user configuration for selected endpoint
    if (ep->ep_direction == LSC_EP_DIR_OUT) {
        sel_ep_user_cnfg = out_user_ep_cnfg[ep->usb_ep_num];
    } else {
        sel_ep_user_cnfg = in_user_ep_cnfg[ep->usb_ep_num];
    }

    if ((ep->ep_status & LSC_EP_ENABLED) == 0) {

        if (lsc_usb_start_ep_cfg(usb_dev, usb_ep_num, dir) == LSC_FAIL) {

            return LSC_FAIL;
        }
    }

    // If endpoint has not been enabled, we will set 'false' for modify_ep_state
    // argument for lsc_usb_set_ep_cfg function.
    // Means, this is the first time we are calling this function.
    // Otherwise, we will set 'true' for that to indicate we just need to modify endpoint
    // state.
    if ((ep->ep_status & LSC_EP_ENABLED) == 0) {
        modify_ep_state = false;
    } else {
        modify_ep_state = true;
    }


    if (lsc_usb_set_ep_cfg(usb_dev, usb_ep_num, dir, max_size, ep_type, modify_ep_state,
            (bool)restore) == LSC_FAIL) {

        return LSC_FAIL;
    }

    if ((ep->ep_status & LSC_EP_ENABLED) == 0) {

        if (lsc_usb_set_xfer_resource(usb_dev, usb_ep_num, dir) == LSC_FAIL) {

            return LSC_FAIL;
        }

        ep->ep_status |= LSC_EP_ENABLED;

        reg_val = lsc_32_read(usb_dev->base_add + LSC_DALEPENA);
        reg_val |= (LSC_DALEPENA_EP(ep->phy_ep_num));

        lsc_32_write((usb_dev->base_add + LSC_DALEPENA), reg_val);
        LSC_CMD("Active EP: %x\r\n",
                lsc_32_read(usb_dev->base_add + LSC_DALEPENA));
    }

    // Perform initialization
    if (ep->ebm_init_done == false) {
        if (sel_ep_user_cnfg.init_cb != NULL) {
            sel_ep_user_cnfg.init_cb(usb_dev, usb_ep_num, dir);
        }
    }

    // Enable OEBM/IEBM
    if (sel_ep_user_cnfg.pre_fetch_xfer == true) {
        if (sel_ep_user_cnfg.en_cb != NULL) {
            sel_ep_user_cnfg.en_cb(usb_dev, usb_ep_num, dir);
        }
    }

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * @brief
 * Enables Endpoint for sending/receiving data. Endpoints are
 * enabled using Start New Configuration (DEPSTARTCFG) and
 * Set Endpoint Configuration (DEPCFG)
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    ep_desc is a pointer to the endpoint descriptor.
 * @param    ep_ss_comp_desc is a pointer to the super speed
 *                   endpoint companion descriptor.
 * @param    modify_ep_state set this to true if need to modify
 *                   endpoint configuration otherwise, set it to false.
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note     Refer sec 3.2.2 of Synopsis Programming Guide Version 3.30b
 *           for Physical Endpoint-Specific Command Structure.
 *
 *           Unlike Linux driver, we have not used restore field here. This
 *           is because our intended USB controller does not support hibernation.
 *           Bit[25:24] GHWPARAMS1 is having value 1. Means, it supports clock
 *           gating but not hibernation.
 ****************************************************************************/
uint32_t lsc_usb_non_ctrl_ep_enable (struct lsc_usb_dev *usb_dev,
        const USB_STD_EP_DESC *ep_desc,
        const USB_STD_EP_SS_COMP_DESC *ep_ss_comp_desc,
        bool modify_ep_state)
{
    LSC_CMD("lsc_usb_non_ctrl_ep_enable\r\n");

    uint8_t usb_ep_num;
    uint8_t ep_dir;

    uint32_t reg_val;
    uint32_t phy_ep_num;
    uint32_t ret;

    struct lsc_ep *ep;
    struct lsc_trb *first_trb_ptr;
    struct lsc_trb *link_trb;

    struct user_ep_cnfg sel_ep_user_cnfg;

    // Let's check whether input parameter for endpoint descriptor is
    // valid or not.
    if (ep_desc == NULL) {
        LSC_DISP_ERROR("Invalid parameter. ep_desc is null.\r\n");
        return LSC_FAIL;
    }

    if (ep_desc->bDescriptorType != USB_TYPE_ENDPOINT_CFG_DESC) {
        LSC_DISP_ERROR(
                "Invalid parameter. Desrciptor type is not valid for ep_desc.\r\n");
        return LSC_FAIL;
    }

    if (ep_desc->bMaxPacketSize == 0x0) {
        LSC_DISP_ERROR(
                "Invalid parameter. Endpoint maximum packet size shall not be zero.\r\n");
        return LSC_FAIL;
    }

    // Get USB Endpoint Number
    usb_ep_num = (ep_desc->bEndpointAddress & USB_ENDPOINT_NUMBER_MASK);
    LSC_CMD("usb_ep_num = %d\r\n",usb_ep_num);

    // Get endpoint direction
    ep_dir = ((ep_desc->bEndpointAddress & USB_ENDPOINT_DIR_MASK) >> 7);
    LSC_CMD("ep_dir = %d\r\n",ep_dir);

    phy_ep_num = lsc_physicalep(usb_ep_num, ep_dir);
    LSC_CMD("phy_ep_num = %d\r\n",phy_ep_num);

    // Get endpoint structure pointer for corresponding physical endpoint number
    ep = &usb_dev->eps[phy_ep_num];

    // Let's assign endpoint number and direction to endpoint structure
    ep->usb_ep_num = usb_ep_num;
    ep->ep_direction = ep_dir;

    // Future scope: Do we need to store physical endpoint number?
    ep->phy_ep_num = phy_ep_num;

    // Let's find endpoint type
    ep->ep_type = (ep_desc->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK);

    switch (ep->ep_type) {

        case USB_EP_CONTROL:
            LSC_CMD("Control Endpoint\r\n");
            break;

        case USB_EP_ISOCHRONOUS:
            LSC_CMD("Isochronous Endpoint\r\n");
            break;

        case USB_EP_BULK:
            LSC_CMD("Bulk Endpoint\r\n");
            break;

        case USB_EP_INTERRUPT:
            LSC_CMD("Interrupt Endpoint\r\n");
            break;
    }

    // Let's get endpoint maximum packet size
    // Bits 10:0 specifiy maximum packet size in bytes.
    ep->max_ep_size = (ep_desc->bMaxPacketSize & 0x7FF);
    LSC_CMD("EP Max Pkt size = %d\r\n",ep->max_ep_size);

    // Additional transaction opportunities per micro-frame
    // Bits 12:11
    ep->add_xfer_per_mf = (((ep_desc->bMaxPacketSize) >> 11) & 0x3);
    LSC_CMD("Additional transaction opportunities per micro-frame = %d\r\n",ep->add_xfer_per_mf);

    // Get bInterval
    ep->bInterval = ep_desc->bInterval;
    LSC_CMD("bInterval = %d\r\n",ep->bInterval);

    if (usb_dev->dev_speed == LSC_SPEED_SUPER) {

        ep->maxburst = ep_ss_comp_desc->bMaxBurst;
        LSC_CMD("bMaxBurst = %d\r\n",ep->maxburst);

        if (ep->maxburst > 15) {
            LSC_DISP_ERROR(
                    "Max burst value is out of range. Valid range: 0 to 15\r\n");
        }

        if (ep->ep_type == USB_EP_ISOCHRONOUS) {
            // Mult: A zero based value that determines the maximum number of packets
            // within a service interval that this endpoint supports
            ep->mult = (ep_ss_comp_desc->bmAttributes & 0x3);
            LSC_CMD("Mult = %d\r\n",ep->mult);
        } else {
            // Mult only applies to Isochronous endpoint.
            ep->mult = 0;
        }

        // Future scope: Check whether stream is supported for Bulk endpoint or not.

    } else {
        // Assign 0 when device is not operating in super speed mode.
        ep->maxburst = 0;
        ep->mult = 0;

    }

    // Find bytes per service interval
    if ((ep->ep_type == LSC_ENDPOINT_XFER_ISOC)
            || (ep->ep_type == LSC_ENDPOINT_XFER_INT)) {
        if (usb_dev->dev_speed == LSC_SPEED_SUPER) {
            // For Super speed mode, it is calculated based on maxburst and mult value.
            ep->bytes_per_service_interval = (ep->max_pkt_size
                    * (ep->maxburst + 1) * (ep->mult + 1));

        } else {
            // For non-super speed mode, it is calcualted based on additional service opporunties per
            // micro-frame.
            ep->bytes_per_service_interval = (ep->max_pkt_size
                    * (ep->add_xfer_per_mf + 1));

        } LSC_CMD("Bytes per service interval = %d\r\n",ep->bytes_per_service_interval);

    } else {
        // Assign 0 to bytes per service interval for non-periodic endpoint
        ep->bytes_per_service_interval = 0;

    }

    // Find minimum buffer
    // For periodic endpoint, minimum buffer span should be equal to bytes per service interval.
    // This is to allow single TRB for periodic endpoint to serve single service interval.
    // Future scope: In future, we may think to allow multiple TRBs to serve single service
    // interval. That shall require usage of chain bit in TRB.
    // For non-periodic endpoint, it shall be equal to endpoint's maximum packet size.
    if ((ep->ep_type == LSC_ENDPOINT_XFER_ISOC)
            || (ep->ep_type == LSC_ENDPOINT_XFER_INT)) {
        ep->min_bufr_span = ep->bytes_per_service_interval;
    } else {
        ep->min_bufr_span = ep->max_pkt_size;
    } LSC_CMD("Minimum buffer span = %d\r\n",ep->min_bufr_span);

    // Get user configuration for selected endpoint
    if (ep->ep_direction == LSC_EP_DIR_OUT) {
        sel_ep_user_cnfg = out_user_ep_cnfg[ep->usb_ep_num];
    } else {
        sel_ep_user_cnfg = in_user_ep_cnfg[ep->usb_ep_num];
    }

    // Initialize some variables
    // Reset number of requests pending field.
    ep->no_of_req_pending = 0;

    // Reset Request enqueue and dequeue pointers
    ep->req_enqueue_ptr = 0;
    ep->req_dequeue_ptr = 0;

    // Reset request completion tracker
    ep->req_completion_tracker = 0;

    // Reset USB buffer tracker and IP buffer tracker
    ep->ebm_usb_bufr_tracker = 0;
    ep->ebm_ip_bufr_tracker = 0;

    // Please do not reset endpoint status here.
    // Endpoint status is changed before this function is invoked if required.

    // Current micro-frame which is used for Isochronus endpoint
    ep->cur_micro_frame = 0;

    // Maximum number of requests which can be queued for this endpoint.
    if (sel_ep_user_cnfg.ep_req_queue_size > LSC_EP_REQ_QUEUE_MAX_SIZE) {
        LSC_DISP_ERROR(
                "Request queue size is %d which exceeds maximum value (%d).\r\n",
                sel_ep_user_cnfg.ep_req_queue_size > LSC_EP_REQ_QUEUE_MAX_SIZE);
        LSC_DISP_ERROR(
                "Please check endpoint user configuration for ep %d with direction %d. \r\n",
                usb_ep_num, ep_dir);
        return LSC_FAIL;
    } else {
        ep->max_no_of_ep_xfer_req = sel_ep_user_cnfg.ep_req_queue_size;
        LSC_CMD("User selected request queue size = %d\r\n",ep->max_no_of_ep_xfer_req);

        // Future scope: We may add display to inform user if request queue size selected by
        // user is less than maximum request size allocated.
        // User may select less for debugging purpose.
        // For normal use case, it is preferred to use maximum value.
    }

    // TRB free slots
    // Maximum number of TRB slots which shall be used for this endpoint.
    if (sel_ep_user_cnfg.ep_trb_slots > NO_OF_TRB_PER_EP) {
        LSC_DISP_ERROR(
                "Number of TRB slots is %d which exceeds maximum value (%d).\r\n",
                sel_ep_user_cnfg.ep_trb_slots, NO_OF_TRB_PER_EP);
        LSC_DISP_ERROR(
                "Please check endpoint user configuration for ep %d with direction %d. \r\n",
                usb_ep_num, ep_dir);
        return LSC_FAIL;
    } else if (sel_ep_user_cnfg.ep_trb_slots == 0) {
        LSC_DISP_ERROR("Number of TRB slots must not be 0.\r\n");
        LSC_DISP_ERROR(
                "Please check endpoint user configuration for ep %d with direction %d. \r\n",
                usb_ep_num, ep_dir);
        return LSC_FAIL;
    } else {
        ep->trb_free_slot = sel_ep_user_cnfg.ep_trb_slots;
        ep->trb_max_slot = sel_ep_user_cnfg.ep_trb_slots;
        LSC_CMD("User selected TRB slots = %d\r\n",ep->trb_free_slot);

        // Future scope: We may add display to inform user if number of TRB slots selected by
        // user is less than maximum slots allocated.
        // User may select less for debugging purpose.
        // For normal use case, it is preferred to use maximum value.
    }

    // Initialization for endpoint buffer management related variables
    ep->ebm_init_done = false;
    // Reset buffer span to 0.
    // It will be updated when corresponding initialization function is called.
    ep->ebm_bufr_span = 0;

    // If endpoint is not enabled, we will send start endpoint configuration command.
    if ((ep->ep_status & LSC_EP_ENABLED) == 0) {
        ret = lsc_usb_start_ep_cfg(usb_dev, ep->usb_ep_num, ep->ep_direction);

        if (ret != LSC_SUCCESS) {
            LSC_DISP_ERROR(
                    "Start endpoint configuration command failed for ep %d with direction %d. \r\n",
                    ep->usb_ep_num, ep->ep_direction);
            return LSC_FAIL;
        } else {
            LSC_CMD("Start endpoint configuration command passed.\r\n");
        }
    }

    // SET endpoint configuration can also be invoked when endpoint is already enabled.
    // For example, upon completion of USB reset, based on speed, this can be
    // called to update endpoint maximum size based on speed. In that case,
    // modify_ep_state argument would be set.
    // Hence, we shall not check whether endpoint is enabled or not here.

    // Hibernation is not supported for current version of controller.
    // Hence, restore field is set to 0 in following.
    ret = lsc_usb_set_ep_cfg(usb_dev, ep->usb_ep_num, ep->ep_direction,
            ep->max_pkt_size, ep->ep_type, modify_ep_state,
            false            // restore
            );
    if (ret != LSC_SUCCESS) {
        LSC_DISP_ERROR(
                "Set endpoint configuration command failed for ep %d with direction %d. \r\n",
                ep->usb_ep_num, ep->ep_direction);
        return LSC_FAIL;
    } else {
        LSC_CMD("Set endpoint configuration command passed.\r\n");
    }

    // If endpoint is not enabled, we will send set transfer resource command.
    if ((ep->ep_status & LSC_EP_ENABLED) == 0) {
        ret = lsc_usb_set_xfer_resource(usb_dev, ep->usb_ep_num,
                ep->ep_direction);
        if (ret != LSC_SUCCESS) {
            LSC_DISP_ERROR(
                    "Set transfer resource command failed for ep %d with direction %d. \r\n",
                    ep->usb_ep_num, ep->ep_direction);
            return LSC_FAIL;
        } else {
            LSC_CMD("Set transfer resource command passed.\r\n");
        }

        // We will now set flag to indicate endpoint is enabled.
        ep->ep_status |= LSC_EP_ENABLED;

        // We will enable bit in corresponding register.
        reg_val = lsc_32_read(usb_dev->base_add + LSC_DALEPENA);
        reg_val |= (LSC_DALEPENA_EP(ep->phy_ep_num));

        lsc_32_write((usb_dev->base_add + LSC_DALEPENA), reg_val);

        // Let's read to ensure targeted endpoint is enabled.
        LSC_CMD("Active EP: 0x%x\r\n",
                lsc_32_read(usb_dev->base_add + LSC_DALEPENA));
    }

    // First TRB location pointer
    first_trb_ptr = &usb_dev_dm.ep_trb[phy_ep_num][0];

    // Link TRB will be the last in Queue
    link_trb = &usb_dev_dm.ep_trb[phy_ep_num][ep->trb_free_slot];

    link_trb->buf_ptr_lo = (uintptr_t)first_trb_ptr;
    link_trb->buf_ptr_hi = ((uintptr_t)first_trb_ptr >> 16) >> 16;

    // Size for link TRB shall always be set to 0.
    link_trb->size = 0;

    // Set Hardware owner bit to 1.
    link_trb->ctrl = LSC_TRB_CTRL_HWO | LSC_TRBCTL_LINK_TRB;

    LSC_CMD("Last TRB has been set as Link TRB.\r\n");

    // Perform initialization
    if (ep->ebm_init_done == false) {
        if (sel_ep_user_cnfg.init_cb != NULL) {
            sel_ep_user_cnfg.init_cb(usb_dev, usb_ep_num, ep->ep_direction);
        }
    }

    // Enable OEBM/IEBM
    if (sel_ep_user_cnfg.pre_fetch_xfer == true) {
        if (sel_ep_user_cnfg.en_cb != NULL) {
            sel_ep_user_cnfg.en_cb(usb_dev, usb_ep_num, ep->ep_direction);
        }
    }

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * @brief
 * Disables Endpoint. It clears corresponding bit for a physical
 * endpoint from Device Active USB Endpoint Enable Register (DALEPENA).
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction of endpoint
 *           - LSC_EP_DIR_IN/ LSC_EP_DIR_OUT.
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note     Refer sec 1.3.7 of Synopsis Programming Guide Version 3.30b
 *           for Device Active USB Endpoint Enable Register (DALEPENA).
 ****************************************************************************/
uint32_t lsc_usb_ep_disable (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num,
        uint8_t dir)
{
    LSC_CMD("lsc_usb_ep_disable: %x - %x\r\n", usb_ep_num, dir);

    uint32_t reg_val;
    uint8_t phy_ep_num;
    struct lsc_ep *ep;

    struct user_ep_cnfg sel_ep_user_cnfg;

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);
    ep = &usb_dev->eps[phy_ep_num];

    // Get user configuration for selected endpoint
    if (ep->ep_direction == LSC_EP_DIR_OUT) {
        sel_ep_user_cnfg = out_user_ep_cnfg[ep->usb_ep_num];
    } else {
        sel_ep_user_cnfg = in_user_ep_cnfg[ep->usb_ep_num];
    }

    // First let's see whether endpoint is enabled or not.
    // If not, we do not need to do anything furhter.
    if ((ep->ep_status & LSC_EP_ENABLED) != 0) {
        LSC_CMD("Endpoint is already disabled.\r\n");
        return LSC_SUCCESS;
    }

    // We will see if hardware endpoint is stalled or not.
    // If it is, we will clear stall.
    if ((ep->ep_status & LSC_EP_STALL) != 0) {
        lsc_usb_ep_clear_stall(usb_dev, ep->usb_ep_num, ep->ep_direction);
    }

    // Write register to disabled endpoint
    reg_val = lsc_32_read(usb_dev->base_add + LSC_DALEPENA);

    reg_val &= ~LSC_DALEPENA_EP(ep->phy_ep_num);

    lsc_32_write((usb_dev->base_add + LSC_DALEPENA), reg_val);

    // Reset various endpoint structure members
    ep->ep_type = 0;
    ep->ep_status = 0;
    ep->max_ep_size = 0;
    ep->trb_enqueue = 0;
    ep->trb_dequeue = 0;
    ep->maxburst = 0;
    ep->requested_bytes = 0;
    ep->remain_bytes = 0;
    ep->bytes_txfered = 0;
    ep->buffer_ptr = NULL;

    ep->ep_buf_i_rd = 0;

    ep->no_of_req_pending = 0;
    ep->max_no_of_ep_xfer_req = 0;
    ep->req_enqueue_ptr = 0;
    ep->req_dequeue_ptr = 0;
    ep->req_completion_tracker = 0;
    ep->trb_free_slot = 0;

    ep->ebm_usb_bufr_tracker = 0;
    ep->ebm_ip_bufr_tracker = 0;
    ep->ebm_init_done = false;
    ep->ebm_bufr_span = 0;

    // Clearing endpoint TRB data.
    /* struct lsc_trb ep_trb[NO_OF_TRB_PER_EP + 1] clearing */
//    memset(&(ep->ep_trb[0]), 0, sizeof(struct lsc_trb) * (NO_OF_TRB_PER_EP + 1));
    memset(&usb_dev_dm.ep_trb[phy_ep_num], 0,
            sizeof(struct lsc_trb) * (NO_OF_TRB_PER_EP + 1));

    // If user has requested to call corresponding call back function when endpoint is disabled,
    // we will call it.
    if (sel_ep_user_cnfg.dis_cb != NULL) {
        sel_ep_user_cnfg.dis_cb(usb_dev, usb_ep_num, dir);
    }

    return LSC_SUCCESS;
}

/** @} */
