/****************************************************************************/
/**
 *
 * @file lsc_endpoint.c
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/

#include <stdio.h>
#include "lsc_usb_dev.h"
#include <math.h>

#define min_t(type, a, b) fmin(((type) a), ((type) b))
//#define DEBUG_LSC_EP

#ifdef DEBUG_LSC_EP
#define LSC_EP(msg, ...) sprintf(print_buf, msg, ##__VA_ARGS__); lsc_uart_tx(print_buf)
#else
#define LSC_EP(msg, ...)
#endif

/****************************************************************************/
/**
 * Returns Transfer Index assigned by Core for an Endpoint transfer.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 *
 * @return   Transfer Resource Index.
 *
 * @note     Refer Bit[31:16] (COMMANDPARAM) of Device Physical Endpoint-n Command
 *           Register (DEPCMD) of sec 1.3.12 of Synopsis Programming
 *           Guide Version 3.30b
 *****************************************************************************/
uint32_t lsc_usb_ep_get_xfer_index (struct lsc_usb_dev *usb_dev,
        uint8_t usb_ep_num, uint8_t dir)
{
    LSC_EP("lsc_usb_ep_get_xfer_index\r\n");

    uint8_t phy_ep_num;
    uint32_t res_index;

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);
    res_index = lsc_32_read(usb_dev->base_add + LSC_DEPCMD(phy_ep_num));
    LSC_EP("usb_ep_num: %x\tres_index: %x\r\n", usb_ep_num, res_index);

    return LSC_DEPCMD_GET_RSC_IDX(res_index);
}

/****************************************************************************/
/**
 * Sends Start New Configuration command to Endpoint.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction of endpoint
 *           - LSC_EP_DIR_IN/ LSC_EP_DIR_OUT.
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note
 *           This command should be issued by software
 *           under these conditions:
 *           1. After power-on-reset with xfer_rsc_idx=0 before starting
 *              to configure Physical Endpoints 0 and 1.
 *           2. With xfer_rsc_idx=2 before starting to configure
 *              Physical Endpoints > 1
 *           3. This command should always be issued to
 *              Endpoint 0 (DEPCMD0).
 *
 *           Refer sec 3.2.2.8 of Synopsis Programming Guide Version 3.30b
 *           for detailed information about Start New Configuration
 *           (DEPSTARTCFG).
 *****************************************************************************/
uint32_t lsc_usb_start_ep_cfg (struct lsc_usb_dev *usb_dev, uint32_t usb_ep_num,
        uint8_t dir)
{
    LSC_EP("lsc_usb_start_ep_cfg\r\n");

    struct lsc_ep_params *params;
    uint32_t cmd;
    uint8_t phy_ep_num;

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);
    params = lsc_usb_get_ep_params(usb_dev);

    // Physical endpoint 0 represents control endpoint OUT direction and
    // 1 represents control endpoint IN direction.
    // For control endpoint, this shall be called only once.
    // Hence, we will execute this command for physical endpoint 0 but
    // not for physical endpoint 1.
    // For rest endpoints, this shall be executed only once. We are managing
    // this using is_config_done flag.
    // For rest endpoints, transfer resource index shall be set to 2.

    if (phy_ep_num != 1) {
        cmd = LSC_DEPCMD_DEPSTARTCFG;
        /* XferRscIdx == 0 for EP0 and 2 for the remaining */
        if (phy_ep_num > 1) {
            if (usb_dev->is_config_done != 0) {
                return LSC_SUCCESS;
            }
            usb_dev->is_config_done = 1;
            cmd |= LSC_DEPCMD_PARAM(2); //2 - xfer_res_index for ep other than control ep
        }
        // Start configuration command needs to be sent for endpoint 0 only.
        // For control endpoint, resource index shall be 0 while for others
        // it shall be 2.
        return lsc_usb_send_ep_cmd(usb_dev, 0, LSC_EP_DIR_OUT, cmd, params);
    }

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * Sends Set Endpoint Configuration command to Endpoint.
 * This command sets the physical endpoint configuration information.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction of endpoint
 *               -LSC_EP_DIR_IN/ LSC_EP_DIR_OUT.
 * @param    size is size of Endpoint size.
 * @param    ep_type is Endpoint type Control/Bulk/Interrupt/Isoc.
 * @param    modify_ep_state set this to true if need to modify
 *                   endpoint configuration otherwise, set it to false.
 * @param    restore should be true if saved state should be restored;
 *           typically this would be false.
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note     Refer sec 3.2.2.1 of Synopsis Programming Guide Version 3.30b
 *           for detailed information about Set Endpoint Configuration
 *           (DEPCFG).
 *****************************************************************************/
uint32_t lsc_usb_set_ep_cfg (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num,
        uint8_t dir, uint16_t size, uint8_t ep_type, bool modify_ep_state, bool restore)
{
    LSC_EP("lsc_usb_set_ep_cfg\r\n");

    struct lsc_ep *ep;
    struct lsc_ep_params *params;
    uint8_t phy_ep_num;

    params = lsc_usb_get_ep_params(usb_dev);

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);
    ep = &usb_dev->eps[phy_ep_num];

    params->param0 = LSC_DEPCFG_EP_TYPE(
            ep_type) | LSC_DEPCFG_MAX_PACKET_SIZE(size);

    /* Burst size is only needed in SuperSpeed mode */
    if (usb_dev->dev_speed == LSC_SPEED_SUPER) {

        params->param0 |= LSC_DEPCFG_BURST_SIZE(ep->maxburst/* - 1*/);

    }

    if (ep->ep_type == LSC_ENDPOINT_XFER_CONTROL) {
        params->param1 = LSC_DEPCFG_XFER_COMPLETE_EN
                | LSC_DEPCFG_XFER_NOT_READY_EN;
    } else {
        params->param1 = LSC_DEPCFG_XFER_COMPLETE_EN
                | LSC_DEPCFG_XFER_NOT_READY_EN | LSC_DEPCFG_XFER_IN_PROGRESS_EN;
    }


    if (modify_ep_state) {
        params->param0 |= LSC_DEPCFG_ACTION_MODIFY;
    }

    if (restore == true) {
        params->param0 |= LSC_DEPCFG_ACTION_RESTORE;
        params->param2 = ep->ep_saved_state;
    }

    /*
     * We are doing 1:1 mapping for endpoints, meaning
     * Physical Endpoints 2 maps to Logical Endpoint 2 and
     * so on. We consider the direction bit as part of the physical
     * endpoint number. So USB endpoint 0x81 is 0x03.
     */
    params->param1 |= LSC_DEPCFG_EP_NUMBER(phy_ep_num);

    if (dir != LSC_EP_DIR_OUT) {
        params->param0 |= LSC_DEPCFG_FIFO_NUMBER((phy_ep_num >> 1));
    }

    // Refer to Synopsis Programming Guide Version 3.30b Table 3-3 bInterval_m1 field bits 23:16
    if (ep->bInterval) {


        uint8_t bInterval_m1;

        /*
         * Valid range for DEPCFG.bInterval_m1 is from 0 to 13.
         *
         * NOTE: The programming guide incorrectly stated bInterval_m1
         * must be set to 0 when operating in fullspeed. Internally the
         * controller does not have this limitation. See DWC_usb3x
         * programming guide section 3.2.2.1.
         */
        bInterval_m1 = min_t(uint8_t, ep->bInterval - 1, 13);

        params->param1 |= LSC_DEPCFG_BINTERVAL_M1(bInterval_m1);

        // Following is as per USB specification. Kindly refer description for
        // endpoint descriptor. We do not support low speed. Hence, it has not been considered.
        if ( (ep->ep_type == LSC_ENDPOINT_XFER_INT) && (usb_dev->dev_speed == LSC_SPEED_FULL) )
            ep->f_interval = ep->bInterval;
        else
            ep->f_interval = ( 1 << (ep->bInterval - 1) );
    }
#if 0
    printf("parm0: %x\r\n", params->param0);
    printf("parm1: %x\r\n", params->param1);
    printf("parm2: %x\r\n", params->param2);
#endif
    return lsc_usb_send_ep_cmd(usb_dev, usb_ep_num, dir, LSC_DEPCMD_SETEPCONFIG,
            params);
}

/****************************************************************************/
/**
 * Sends Set Transfer Resource command to Endpoint.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction of endpoint - LSC_EP_DIR_IN/ LSC_EP_DIR_OUT
 *
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note     There must be only one transfer resource allocated per endpoint.
 *           <br>Refer sec 3.2.2.2 of Synopsis Programming Guide Version 3.30b
 *           for detailed information about Set Endpoint Transfer Resource
 *           Configuration (DEPXFERCFG).
 *****************************************************************************/
uint32_t lsc_usb_set_xfer_resource (struct lsc_usb_dev *usb_dev,
        uint8_t usb_ep_num, uint8_t dir)
{
    LSC_EP("lsc_usb_set_xfer_resource\r\n");

    struct lsc_ep_params *params;

    params = lsc_usb_get_ep_params(usb_dev);

    params->param0 = LSC_DEPXFERCFG_NUM_XFER_RES(1);

    return lsc_usb_send_ep_cmd(usb_dev, usb_ep_num, dir,
    LSC_DEPCMD_SETTRANSFRESOURCE, params);

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * Clears stall on all stalled Eps.
 * This function clears stall for all endpoints except EP0 OUT
 * (Physical EP - 0) as controller clears stall of EP0_OUT automatially.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 *
 * @return   None.
 *
 * @note     This function is called from USB reset interrupt.<br>
 *           Refer sec 4.1.2 of Synopsis Programming Guide Version 3.30b
 *           for detailed information about Initialization on USB Reset.
 *****************************************************************************/
void lsc_usb_clear_stall_all_ep (struct lsc_usb_dev *usb_dev)
{
    LSC_EP("lsc_usb_clear_stall_all_ep\r\n");

    for (uint32_t ep_num = 1; ep_num < LSC_ENDPOINTS_NUM; ep_num++) {
        struct lsc_ep *ep;

        ep = &usb_dev->eps[ep_num];

        if ((ep->ep_status & LSC_EP_ENABLED) == 0) {
            continue;
        }

        if ((ep->ep_status & LSC_EP_STALL) == 0) {
            continue;
        }

        lsc_usb_ep_clear_stall(usb_dev, ep->usb_ep_num, ep->ep_direction);
    }
}

/****************************************************************************/
/**
 * Stops any active transfer.
 * This function stops active transfer of any non control endpoints.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 *
 * @return   None.
 *
 * @note     This function is called from USB reset interrupt.<br>
 *           Refer sec 4.1.2 of Synopsis Programming Guide Version 3.30b
 *           for detailed information about Initialization on USB Reset.
 *****************************************************************************/
void lsc_usb_stop_active_transfers (struct lsc_usb_dev *usb_dev)
{
    LSC_EP("lsc_usb_stop_active_transfers\r\n");

    for (uint32_t ep_num = 2; ep_num < LSC_ENDPOINTS_NUM; ep_num++) {
        struct lsc_ep *ep;

        ep = &usb_dev->eps[ep_num];

        if ((ep->ep_status & LSC_EP_ENABLED) == 0)
            continue;

        lsc_usb_stop_xfer(usb_dev, ep->usb_ep_num, ep->ep_direction, true);
    }
}

/** @} */
