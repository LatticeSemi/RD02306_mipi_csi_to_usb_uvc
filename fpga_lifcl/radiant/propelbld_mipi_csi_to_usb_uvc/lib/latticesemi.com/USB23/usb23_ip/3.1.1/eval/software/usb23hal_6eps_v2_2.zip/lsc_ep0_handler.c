/****************************************************************************/
/**
 *
 * @file lsc_ep0_handler.c
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/

#include <stdio.h>
#include "lsc_usb_dev.h"

//#define DEBUG_LSC_EP0_HANDLER

#ifdef DEBUG_LSC_EP0_HANDLER
#define LSC_EP0_HANDLER(msg, ...) sprintf(print_buf, msg, ##__VA_ARGS__); lsc_uart_tx(print_buf)
#else
#define LSC_EP0_HANDLER(msg, ...)
#endif

extern struct lsc_usb_dev_dm usb_dev_dm;

/****************************************************************************/
/**
 * This function prepares TRB to receive setup packet from HOST.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note     Setup packet is always on EP0 OUT.<br>
 *           Refer sec 3.1.2 of Synopsis Programming Guide Version 3.30b
 *           for more information about Transfer Request Block (TRB) structure.
 ****************************************************************************/
uint8_t lsc_usb_rcv_setup (struct lsc_usb_dev *usb_dev)
{
    LSC_EP0_HANDLER("lsc_usb_rcv_setup\r\n");

    struct lsc_ep_params *params;
    struct lsc_trb *trb;
    struct lsc_ep *ep;
    uint8_t ret;

    params = lsc_usb_get_ep_params(usb_dev);

    /* Setup packet always on EP0 */
    ep = &usb_dev->eps[0];
    if ((ep->ep_status & LSC_EP_BUSY) != 0) {
        return LSC_FAIL;
    }

    trb = &usb_dev_dm.ep0_trb;
//    printf("setup_data: %x\r\n", &usb_dev_dm.setup_data);

    trb->buf_ptr_lo = (uintptr_t) &usb_dev_dm.setup_data;
    trb->buf_ptr_hi = ((uintptr_t) &usb_dev_dm.setup_data >> 16) >> 16;

    trb->buf_ptr_lo = (  trb->buf_ptr_lo & U23_MEM_MASK);
//    printf("setup_data: %x\r\n", trb->buf_ptr_lo);

    trb->buf_ptr_hi = (  trb->buf_ptr_hi & U23_MEM_MASK);

    trb->size = 8;
    trb->ctrl = LSC_TRBCTL_CONTROL_SETUP;

    // As we have set LST and IOC flags, no need to set IS_IMI flag here. IS_IMI is useful if LST is not set for this TRB.
    // Refer sec 3.1.2 Structures, Table 3-1 Device Descriptor Structure Field Definitions,
    // Bit:10 - Interrupt on Short Packet / Interrupt on Missed ISOC (ISP/IMI) of Synopsis Programming Guide Version 3.30b
    trb->ctrl |= (LSC_TRB_CTRL_HWO | LSC_TRB_CTRL_LST | LSC_TRB_CTRL_IOC
    /* | LSC_TRB_CTRL_ISP_IMI*/);

//  LSC_EP0_HANDLER("trb->size: %x\ttrb->ctrl: %x\r\n", trb->size, trb->ctrl);

    params->param0 = 0;
    params->param1 = (uintptr_t)trb;
    params->param1 =( params->param1 & U23_MEM_MASK);
//    printf("param1: %x\r\n", params->param1);

    usb_dev->ep0_state = LSC_EP0_SETUP_PHASE;

    ret = lsc_usb_send_ep_cmd(usb_dev, 0, LSC_EP_DIR_OUT,
    LSC_DEPCMD_STARTTRANSFER, params);
    if (ret != LSC_SUCCESS) {
        return LSC_FAIL;
    }

    ep->ep_status |= LSC_EP_BUSY;
    ep->resource_index = lsc_usb_ep_get_xfer_index(usb_dev, ep->usb_ep_num,
            ep->ep_direction);

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * Handles Transfer complete event of Control Endpoints EP0 OUT and EP0 IN.
 * This function is called when controller generates transfer complete event
 * on control endpoint.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    ep_evt is a pointer to the Endpoint event occurred in core.
 *
 * @return   None.
 *
 * @note     Refer Figure 4-2 of sec 4.4 of Synopsis Programming Guide
 *           Version 3.30b for Control Transfer Programming Model.
 *****************************************************************************/
void lsc_usb_ep0_xfer_cmplt (struct lsc_usb_dev *usb_dev,
        const struct lsc_event_epevt *ep_evt)
{
    LSC_EP0_HANDLER("lsc_usb_ep0_xfer_cmpt\r\n");

    struct lsc_ep *ep;

    setup_pkt *sp;
    uint16_t length;

    ep = &usb_dev->eps[ep_evt->ep_number];
    sp = &usb_dev_dm.setup_data;

    ep->ep_status &= ~LSC_EP_BUSY;
    ep->resource_index = 0;

    LSC_EP0_HANDLER("ep0_xfer_cmpt: ep0_state: %x\r\n", usb_dev->ep0_state);

    switch (usb_dev->ep0_state) {
        case LSC_EP0_SETUP_PHASE:
            LSC_EP0_HANDLER("EP0_SETUP_PHASE\r\n");
            usb_dev->ep0_stall = 0;
            length = sp->wLength;

            if (length == 0) {
                LSC_EP0_HANDLER("2-stage control req\r\n");

                usb_dev->is_three_stage = 0;
                usb_dev->control_dir = LSC_EP_DIR_OUT;
            } else {
                LSC_EP0_HANDLER("3-stage control req\r\n");

                usb_dev->is_three_stage = 1;
                usb_dev->control_dir = !!(sp->bRequestType & LSC_USB_DIR_IN);
            }

            lsc_usb_setup_pkt_process(usb_dev, &usb_dev_dm.setup_data);
            break;

        case LSC_EP0_DATA_PHASE:
            LSC_EP0_HANDLER("EP0_DATA_PHASE\r\n");

            lsc_usb_ep0_data_xfer_cmplt(usb_dev, ep_evt);
            break;

        case LSC_EP0_STATUS_PHASE:
            LSC_EP0_HANDLER("EP0_STATUS_PHASE\r\n");
            lsc_usb_ep0_status_cmplt(usb_dev);
            break;

        default:
            LSC_EP0_HANDLER("Invalid Ep0(Setup Pkt) State.!!\r\n");
            break;
    }

}

/****************************************************************************/
/**
 * Handles Transfer Not Ready event of Control Endpoints EP0 OUT and EP0 IN.
 * This function is called when controller generates transfer not ready event
 * on control endpoint.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    ep_evt is a pointer to the Endpoint event occurred in core.
 *
 * @return   None.
 *
 * @note     Refer Figure 4-2 of sec 4.4 of Synopsis Programming Guide
 *           Version 3.30b for Control Transfer Programming Model.
 *****************************************************************************/
void lsc_usb_ep0_xfer_not_ready (struct lsc_usb_dev *usb_dev,
        const struct lsc_event_epevt *ep_evt)
{
    LSC_EP0_HANDLER("lsc_usb_ep0_xfer_not_ready\r\n");

    struct lsc_ep *ep;

    ep = &usb_dev->eps[ep_evt->ep_number];

    LSC_EP0_HANDLER("ep0_xfer_not_ready: ep_evt->status: %x\r\n", ep_evt->status);

    switch (ep_evt->status) {
        case DEPEVT_STATUS_CONTROL_DATA:
            LSC_EP0_HANDLER("STATUS_CONTROL_DATA\r\n");
            LSC_EP0_HANDLER("ep_evt->ep_number: %x \t usb_dev->control_dir: %x\r\n", ep_evt->ep_number, usb_dev->control_dir);
            /*
             * We already have initialted DATA transfer,
             * if we receive a XferNotReady(DATA) we will ignore it, unless
             * it's for the wrong direction.
             *
             * In that case, we must issue END_TRANSFER command to the Data
             * Phase we already have started and issue SetStall on the
             * control endpoint.
             */
            if (ep_evt->ep_number != usb_dev->control_dir) {
                lsc_usb_end_ep0_ctl_data_xfer(usb_dev, ep);
                lsc_usb_ep0_stall_restart(usb_dev);
            }
            break;

        case DEPEVT_STATUS_CONTROL_STATUS:
            LSC_EP0_HANDLER("STATUS_CONTROL_STATUS\r\n");

            if(usb_dev->ep0_stall)
                return;

            lsc_usb_start_ep0_stat(usb_dev, ep_evt);

            break;

        default:
            LSC_EP0_HANDLER("Invalid ep0_xfer_not_ready Status.!!\r\n");
            break;
    }
}

/****************************************************************************/
/**
 * This function prepares TRB to send data to Host.
 * This function is called when there is a data stage in control transfer
 * (i.e Three-Stage Control IN Transfer).
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    buf is pointer to data.
 * @param    buf_len is Length of data buffer.
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note     Data is always sent on Control IN - EP1 endpoint.<br>
 *           Refer sec 3.1.2 of Synopsis Programming Guide Version 3.30b
 *           for more information about Transfer Request Block (TRB) structure.
 *****************************************************************************/
uint8_t lsc_usb_ep0_send (struct lsc_usb_dev *usb_dev, uint8_t *buf,
        uint32_t buf_len)
{
    LSC_EP0_HANDLER("lsc_usb_ep0_send\r\n");

//    for(uint32_t i = 0; i < buf_len; i++)
//      printf("%x ", buf[i]);
//
//    printf("\r\n");

    /* Control IN - EP1 */
    struct lsc_ep_params *params;
    struct lsc_ep *ep;
    struct lsc_trb *trb;
    uint8_t ret;

    ep = &usb_dev->eps[1];
    params = lsc_usb_get_ep_params(usb_dev);

    if ((ep->ep_status & LSC_EP_BUSY) != 0) {
        return LSC_FAIL;
    }

    ep->requested_bytes = buf_len;
    ep->bytes_txfered = 0;
    ep->buffer_ptr = buf;

    // Copy to common buffer
    memcpy(res_buf,buf,buf_len);

    trb = &usb_dev_dm.ep0_trb;

    trb->buf_ptr_lo = (uintptr_t)res_buf;   //buf;
    trb->buf_ptr_hi = ((uintptr_t)res_buf/*buf*/ >> 16) >> 16;

    trb->buf_ptr_lo = (  trb->buf_ptr_lo & U23_MEM_MASK);
     trb->buf_ptr_hi = (  trb->buf_ptr_hi & U23_MEM_MASK);

    trb->size = buf_len;
    trb->ctrl = LSC_TRBCTL_CONTROL_DATA;

    trb->ctrl |= (LSC_TRB_CTRL_HWO | LSC_TRB_CTRL_LST | LSC_TRB_CTRL_IOC
    /*| LSC_TRB_CTRL_ISP_IMI*/);

//  LSC_EP0_HANDLER("trb->size: %x\ttrb->ctrl: %x\r\n", trb->size, trb->ctrl);

    params->param0 = 0;
    params->param1 = (uintptr_t)trb;

    usb_dev->ep0_state = LSC_EP0_DATA_PHASE;

    ret = lsc_usb_send_ep_cmd(usb_dev, 0, LSC_EP_DIR_IN,
    LSC_DEPCMD_STARTTRANSFER, params);
    if (ret != LSC_SUCCESS) {
        return LSC_FAIL;
    }

    ep->ep_status |= LSC_EP_BUSY;
    ep->resource_index = lsc_usb_ep_get_xfer_index(usb_dev, ep->usb_ep_num,
            ep->ep_direction);

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * This function prepares TRB to receive data from Host.
 * This function is called when there is a data stage in control transfer
 * (i.e Three-Stage Control OUT Transfer).
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    buf is pointer to data.
 * @param    buf_len is Length of data to be received.
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note     Data is always received on Control OUT - EP0 endpoint.<br>
 *           Refer sec 3.1.2 of Synopsis Programming Guide Version 3.30b
 *           for more information about Transfer Request Block (TRB) structure.
 *****************************************************************************/
uint8_t lsc_usb_ep0_rcv (struct lsc_usb_dev *usb_dev, uint8_t *buf,
        uint32_t buf_len)
{
    LSC_EP0_HANDLER("lsc_usb_ep0_rcv\r\n");

    struct lsc_ep_params *params;
    struct lsc_ep *ep;
    struct lsc_trb *trb;
    uint8_t ret;
    uint32_t size;

    /* Control OUT - EP0 */
    ep = &usb_dev->eps[0];
    params = lsc_usb_get_ep_params(usb_dev);

    if ((ep->ep_status & LSC_EP_BUSY) != 0) {
        return LSC_FAIL;
    }

    ep->requested_bytes = buf_len;

    //Control OUT TRB Size must be in a
    //multiple of endpoint max packet size.
    size =
            (buf_len % ep->max_ep_size) ?
                    (((buf_len / ep->max_ep_size) * ep->max_ep_size)
                            + ep->max_ep_size) :
                    ((buf_len / ep->max_ep_size) * ep->max_ep_size);

    ep->bytes_txfered = 0;
    ep->buffer_ptr = buf;

    trb = &usb_dev_dm.ep0_trb;

    trb->buf_ptr_lo = (uintptr_t)buf;
    trb->buf_ptr_hi = ((uintptr_t)buf >> 16) >> 16;

    trb->buf_ptr_lo = (  trb->buf_ptr_lo & U23_MEM_MASK);
    trb->buf_ptr_hi = (  trb->buf_ptr_hi & U23_MEM_MASK);

    trb->size = size;
//    printf("T_sz: %d\r\n", trb->size);
    trb->ctrl = LSC_TRBCTL_CONTROL_DATA;

    trb->ctrl |= (LSC_TRB_CTRL_HWO | LSC_TRB_CTRL_LST | LSC_TRB_CTRL_IOC
    /* | LSC_TRB_CTRL_ISP_IMI*/);

//  LSC_EP0_HANDLER("trb->size: %x\ttrb->ctrl: %x\r\n", trb->size, trb->ctrl);

    params->param0 = 0;
    params->param1 = (uintptr_t)trb;
    params->param1 =( params->param1 & U23_MEM_MASK);

    usb_dev->ep0_state = LSC_EP0_DATA_PHASE;

    ret = lsc_usb_send_ep_cmd(usb_dev, 0, LSC_EP_DIR_OUT,
    LSC_DEPCMD_STARTTRANSFER, params);
    if (ret != LSC_SUCCESS) {
        return LSC_FAIL;
    }

    ep->ep_status |= LSC_EP_BUSY;
    ep->resource_index = lsc_usb_ep_get_xfer_index(usb_dev, ep->usb_ep_num,
            ep->ep_direction);

    return LSC_SUCCESS;
}

/** @} */
