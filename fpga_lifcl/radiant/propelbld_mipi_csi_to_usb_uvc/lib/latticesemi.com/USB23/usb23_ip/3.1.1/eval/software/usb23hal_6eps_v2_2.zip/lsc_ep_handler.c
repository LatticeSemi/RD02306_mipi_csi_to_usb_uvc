/****************************************************************************/
/**
 *
 * @file lsc_ep_handler.c
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/

#include <stdio.h>
#include<math.h>
#include "lsc_usb_dev.h"

extern const struct user_ep_cnfg  out_user_ep_cnfg[16];
extern const struct user_ep_cnfg  in_user_ep_cnfg[16];

//#define DEBUG_LSC_EP_HANDLER

#ifdef DEBUG_LSC_EP_HANDLER
#define LSC_EP_HANDLER(msg, ...) sprintf(print_buf, msg, ##__VA_ARGS__); lsc_uart_tx(print_buf)
#else
#define LSC_EP_HANDLER(msg, ...)
#endif

extern struct lsc_usb_dev_dm usb_dev_dm;

/****************************************************************************/
/**
 * @brief
 * This function is used to queue and submit endpoint transfer requests.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is the USB endpoint number.
 * @param    dir is the direction of the endpoint.
 * @param    buf is a pointer to the buffer.
 * @param    buf_len is the length of the buffer.
 *
 * @return   Returns LSC_SUCCESS if the operation is successful, otherwise returns LSC_FAIL.
 *
 * @note     None.
 ****************************************************************************/
uint8_t lsc_usb_ep_xfer_req (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num,
        uint8_t dir, uint8_t *buf, uint32_t buf_len)
{
    LSC_EP_HANDLER("lsc_usb_ep_xfer_req\r\n");

    uint8_t phy_ep_num = 0;
    uint32_t tmp;
    struct lsc_ep *ep = NULL;
    struct lsc_ep_req *req;

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);

    LSC_EP_HANDLER("ep = %d and d = %d \r\n",usb_ep_num, dir);

    ep = &usb_dev->eps[phy_ep_num];

    // First we should check whether requested length can be accomodated
    // in single TRB or not.
    if ( buf_len > EP_TRB_MAX_SIZE ) {
        printf("Request length = %d and maximum TRB size = %d \r\n", buf_len, EP_TRB_MAX_SIZE);
        printf("Sorry. Request length is too big.\r\n");
        return LSC_FAIL;
    }

    // At the moment, this is not intended for endpoint 0 (default control endpoint).
    // So, let's check for that.
    // Future scope: In future, we may see whether this can be used for control endpoint
    // or not.
    if ( usb_ep_num == 0 ) {
        printf("Sorry. This function is not intended for default control endpoint.\r\n");
        return LSC_FAIL;
    }

    // Now, we shall check whether we have room to queue this
    // request or not.
    if ( ep->no_of_req_pending == ep->max_no_of_ep_xfer_req ) {
        printf("Number of requests pending = %d \r\n", ep->no_of_req_pending);
        printf("Sorry. Request queue is full.\r\n");
        return LSC_FAIL;
    }

    // We have room to queue this request.
    req = &(ep->req_arr[ep->req_enqueue_ptr]);

    // Buffer Pointer
    req->bufr_ptr = buf;

    // Requested length
    req->req_len = buf_len;

    // Actual length
    // This will indicate how many bytes have actually been transferred.
    req->act_len = 0;

    // Request Status (success, fail etc.)
    req->sts = 0;

    ep->req_enqueue_ptr++;

    // Rollover to zero if it has reached limit.
    if ( ep->req_enqueue_ptr == ep->max_no_of_ep_xfer_req ) {
        ep->req_enqueue_ptr = 0;
    }

    // Increase number of request pending.
    // This will be reduced when we submit TRB.
    ep->no_of_req_pending++;

    // Following loop will break in one of following conditions:
    // There is not free TRB slot available.
    // There is no pending request.
    do {

        // If we have free slot available, we will prepare and submit TRB.
        // Otherwise we will submit next time, slot becomes available based on TRB
        // completion.
        if (ep->trb_free_slot != 0 ) {

          LSC_EP_HANDLER("Free slot available! \r\n");

         // printf("eq: %d \r\n",ep->req_dequeue_ptr);

          req = &(ep->req_arr[ep->req_dequeue_ptr]);

          // In our case, we have set last as false here.
          // in future, we shall revisit it.
          if ( dir == LSC_EP_DIR_IN ) {
            tmp = lsc_usb_ep_buf_send(usb_dev, usb_ep_num, req->bufr_ptr, req->req_len, false);
          } else {
            tmp = lsc_usb_ep_buf_rcv(usb_dev, usb_ep_num, req->bufr_ptr, req->req_len, false);
          }

          if ( tmp != LSC_SUCCESS ) {
            printf("Unable to submit request.\r\n");
            return LSC_FAIL;
          } else {
            // Request has been submitted successfully.
            // So, let's reduce number of requests pending.
            ep->no_of_req_pending--;

            // Increment dequeue poiner
            ep->req_dequeue_ptr++;

            // Rollover to zero if it has reached limit.
            if ( ep->req_dequeue_ptr == ep->max_no_of_ep_xfer_req ) {
                    ep->req_dequeue_ptr = 0;
             }

          }
          } else {
            // Slot is not available. So, break loop.
            printf("Free slot not available. Normally this shall not happen. ep_num = %d\r\n",usb_ep_num);
            break;
          }
    } while ( ep->no_of_req_pending > 0  );

    // If we reach here, it indicates we have been able to do
    // requested work for this function. Hence, return success.
        return LSC_SUCCESS;
    }

/****************************************************************************/
/**
 * @brief
 * Stops transfer on Endpoint.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction of endpoint
 *               - LSC_EP_DIR_IN/ LSC_EP_DIR_OUT.
 * @param    force flag to stop/pause transfer.
 *
 * @return   None.
 *
 * @note     None.
 ****************************************************************************/
void lsc_usb_stop_xfer (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num,
        uint8_t dir, uint8_t force)
{
    LSC_EP_HANDLER("lsc_usb_stop_xfer: %x - %x\r\n", usb_ep_num, dir);

    uint8_t phy_ep_num;
    uint32_t cmd;
    struct lsc_ep *ep;
    struct lsc_ep_params *params;

    struct user_ep_cnfg sel_ep_user_cnfg;

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);
    ep = &usb_dev->eps[phy_ep_num];

    params = lsc_usb_get_ep_params(usb_dev);

    // If resource index is 0, it indicates there is no ongoing transfer.
    // So, we should return from here.
    if (ep->resource_index == 0) {
        return;
    }


    // Get user configuration for selected endpoint
    if ( ep->ep_direction == LSC_EP_DIR_OUT ) {
        sel_ep_user_cnfg = out_user_ep_cnfg[ep->usb_ep_num];
    } else {
        sel_ep_user_cnfg = in_user_ep_cnfg[ep->usb_ep_num];
    }

    /*
     * - Issue EndTransfer WITH CMDIOC bit set
     * - Wait 100us
     */
    cmd = LSC_DEPCMD_ENDTRANSFER;
    cmd |= (force == 1) ? LSC_DEPCMD_HIPRI_FORCERM : 0;
    cmd |= LSC_DEPCMD_CMDIOC;
    cmd |= LSC_DEPCMD_PARAM(ep->resource_index);

    lsc_usb_send_ep_cmd(usb_dev, ep->usb_ep_num, ep->ep_direction, cmd, params);
    if (force == 1) {
        ep->resource_index = 0;
    }

    ep->ep_status &= ~LSC_EP_BUSY;

    ep->trb_enqueue = 0;
    ep->trb_dequeue = 0;
    ep->requested_bytes = 0;
    ep->remain_bytes = 0;
    ep->bytes_txfered = 0;
    ep->buffer_ptr = NULL;

    ep->ep_buf_i_rd = 0;

    ep->last_iso_frame_valid = 0;

    ep->no_of_req_pending = 0;
    ep->req_enqueue_ptr = 0;
    ep->req_dequeue_ptr = 0;
    // Reset request completion tracker
    ep->req_completion_tracker = 0;

    ep->ebm_usb_bufr_tracker = 0;
    ep->ebm_ip_bufr_tracker = 0;
    ep->ebm_init_done = false;
    ep->ebm_bufr_span = 0;

    //Here only trb strucutre clear without link trb
//    memset(&ep->ep_trb[0], 0, sizeof(struct lsc_trb) * (NO_OF_TRB_PER_EP));
    memset(&usb_dev_dm.ep_trb[phy_ep_num], 0, sizeof(struct lsc_trb) * (NO_OF_TRB_PER_EP));

    // If disable call back is available for this endpoint, we shall call it
    // so that user can take appropriate action.
    if ( sel_ep_user_cnfg.dis_cb != NULL ) {
        sel_ep_user_cnfg.dis_cb(usb_dev, usb_ep_num, dir);
    }

    printf("***\r\n");
}

/****************************************************************************/
/**
 * @brief
 * Clears Stall on an Endpoint.
 * Clear Stall (DEPCSTALL) is issued on endpoint to clear stall.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction.
 *
 * @return   None.
 *
 * @note     The application must not issue the Clear Stall command
 *           on a control endpoint.<br>
 *           Refer sec 3.2.2.4 of Synopsis Programming Guide Version 3.30b
 *           for Clear Stall (DEPCSTALL).
 *****************************************************************************/
void lsc_usb_ep_clear_stall (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num,
        uint8_t dir)
{
    LSC_EP_HANDLER("lsc_usb_ep_clear_stall\r\n");

    uint8_t phy_ep_num;
    struct lsc_ep *ep;
    struct lsc_ep_params *params;

    struct user_ep_cnfg sel_ep_user_cnfg;

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);
    ep = &usb_dev->eps[phy_ep_num];

    // Get user configuration for selected endpoint
    if ( ep->ep_direction == LSC_EP_DIR_OUT ) {
        sel_ep_user_cnfg = out_user_ep_cnfg[ep->usb_ep_num];
    } else {
        sel_ep_user_cnfg = in_user_ep_cnfg[ep->usb_ep_num];
    }

    params = lsc_usb_get_ep_params(usb_dev);

    lsc_usb_send_ep_cmd(usb_dev, ep->usb_ep_num, ep->ep_direction,
    LSC_DEPCMD_CLEARSTALL, params);

    ep->ep_status &= ~LSC_EP_STALL;

    //Reset ep status of Non- control endpoint
    ep->ep_status &= ~LSC_EP_BUSY;

    // Perform initialization
    if (ep->ebm_init_done == false ) {
        if ( sel_ep_user_cnfg.init_cb != NULL ) {
              sel_ep_user_cnfg.init_cb(usb_dev, usb_ep_num, dir);
            }
    }

    // If pre-fetch transfer is enabled, we shall call function to enable
    // requests queuing for corresponding endpoint.
    if (sel_ep_user_cnfg.pre_fetch_xfer == true ) {
        if ( sel_ep_user_cnfg.en_cb != NULL ) {
              sel_ep_user_cnfg.en_cb(usb_dev, usb_ep_num, dir);
            }
    }

}

/****************************************************************************/
/**
 * @brief
 * Checks the Data Phase and calls user Endpoint handler.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    ep_evt is a pointer to the Endpoint event occurred in core.
 *
 * @return   None.
 *
 * @note     None.
 *****************************************************************************/
void lsc_usb_ep_xfer_cmplt (struct lsc_usb_dev *usb_dev,
        const struct lsc_event_epevt *ep_evt)
{
    //This function is invoked by two different events. XFER COMPLETE event and XFER IN PROGRESS.
    //The endpoint handling is identical for both, except for two additional operations required for the XFER COMPLETE event.
    // We use a conditional statement to determine which event received.
    if (ep_evt->ep_event == LSC_DEPEVT_XFERCOMPLETE) {
        LSC_EP_HANDLER("LSC_DEPEVT_XFERCOMPLETE\r\n");
    } else {
        LSC_EP_HANDLER("lsc_usb_ep_xfer_in_progress\r\n");
    }

    struct lsc_trb *trb;
    struct lsc_ep *ep;

    uint32_t len = 0, size;
    uint32_t trb_sts;
    uint8_t dir, phy_ep_num, ep_num;
    struct lsc_ep_req *req;

    struct user_ep_cnfg sel_ep_user_cnfg;

    phy_ep_num = ep_evt->ep_number;
    ep = &usb_dev->eps[phy_ep_num];
    dir = ep->ep_direction;
//    trb = &ep->ep_trb[ep->trb_dequeue];
    trb = &usb_dev_dm.ep_trb[phy_ep_num][ep->trb_dequeue];
    ep_num = phy_ep_num >> 1;

    // Future Scope: See whether we need any kind of processing before we return?
    if ( (ep->ep_status & LSC_EP_BUSY) == 0 ) {
        printf("EP is not busy. This event could be for canceled request. We will return from here.\r\n");
        return;
    }

   // printf("ep_no = %d and dir = %d \r\n",ep_num,dir);

    // Get user configuration for selected endpoint
    if ( ep->ep_direction == LSC_EP_DIR_OUT ) {
        sel_ep_user_cnfg = out_user_ep_cnfg[ep->usb_ep_num];
    } else {
        sel_ep_user_cnfg = in_user_ep_cnfg[ep->usb_ep_num];
    }

    // Let's get information about request which was submitted.
    req = &(ep->req_arr[ep->req_completion_tracker]);

    LSC_EP_HANDLER("ep->trb_dequeue: %d \r\n",ep->trb_dequeue);
    LSC_EP_HANDLER("ep->req_completion_tracker: %d \r\n",ep->req_completion_tracker);

    // Increase number of free slots.
    ep->trb_free_slot++;

    // TRB status
    trb_sts = LSC_TRB_SIZE_TRBSTS(trb->size);

    // Size field is updated by USB core.
    // This shall get reduced to 0 if all requested bytes are transferred.
    len = trb->size & LSC_TRB_SIZE_MASK;

    // We can get actual length by subtracting TRB updated length from requested length.
    // If all bytes have transferred, TRB size would get reduced to 0.
    req->act_len = req->req_len - len;

    LSC_EP_HANDLER("req->req_len = %d \r\n",req->req_len);
    LSC_EP_HANDLER("TRB size     = %d \r\n",len);
    LSC_EP_HANDLER("TRB status   = %d \r\n",trb_sts);
    LSC_EP_HANDLER("req->act_len = %d \r\n",req->act_len);

    //printf("%d\r\n",trb_sts);

    if ( trb_sts == LSC_TRBSTS_OK ) {

        LSC_EP_HANDLER("TRB status: Success \r\n");

        // Incase of Isochronous transfer, we will save frame(micro) frame number
        // in which last packet of the buffer is transmitted.
        // This is being used to cancel ISO OUT when host stops sending new
        // requests.
        if ( ep->ep_type == LSC_ENDPOINT_XFER_ISOC ) {

            ep->last_iso_frame = LSC_TRB_CTRL_SID_SOFN(trb->ctrl);
       //     printf("last_iso_frame: %d\r\ntrb->ctrl: 0x%x\r\nTRB_STS: 0x%x\r\n", ep->last_iso_frame, trb->ctrl, LSC_TRB_SIZE_TRBSTS(trb->size));
            ep->last_iso_frame_valid = 1;
        }
    } else if ( trb_sts == LSC_TRBSTS_MISSED_ISOC ) {
        LSC_EP_HANDLER("TRB status: Missed Isoc \r\n");
        // If we receive missed isochronous service interval, we will send
        // end transfer command.
        if ( ep->ep_type == LSC_ENDPOINT_XFER_ISOC ) {
             lsc_usb_stop_xfer(usb_dev, ep_num, dir, true);
             // We have stopped transfer. So, we shall now return from here.
             return;
        }

    } else if ( trb_sts == LSC_TRBSTS_SETUP_PENDING ) {
        LSC_EP_HANDLER("TRB status: SETUP pending \r\n");
    }

    // Increment TRB dequeue pointer
    ep->trb_dequeue++;
    if (ep->trb_dequeue == ep->trb_max_slot) {
        ep->trb_dequeue = 0;
    }

    // Increment request completion tracker
    ep->req_completion_tracker++;
    if (ep->req_completion_tracker == ep->max_no_of_ep_xfer_req) {
        ep->req_completion_tracker = 0;
    }

    // If a complete transfer event is received, the controller ends the streaming for that endpoint. Consequently, we clear these flags.
    if (ep_evt->ep_event == LSC_DEPEVT_XFERCOMPLETE) {
        ep->ep_status &= ~(LSC_EP_BUSY);
        ep->resource_index = 0;
    }

    // If endpoint pre-fetch transfer is not enabled, it means it
    // uses on-demand transfer flow. Hence, we should call corresponding
    // function to initiate transfer.
    if ( sel_ep_user_cnfg.xfer_completion_cb != NULL ) {
            sel_ep_user_cnfg.xfer_completion_cb(usb_dev, ep->usb_ep_num, ep->ep_direction ,req->act_len);
        }

}

/****************************************************************************/
/**
 * @brief
 * Handles Transfer Not Ready event of Non - Control Endpoints.
 * This function is called when controller generates transfer not ready event
 * on non-control endpoint.
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    ep_evt is a pointer to the Endpoint event occurred in core.
 *
 * @return   None.
 *
 * @note     None.
 *
 *****************************************************************************/
void lsc_usb_ep_xfer_not_ready (struct lsc_usb_dev *usb_dev,
        const struct lsc_event_epevt *ep_evt)
{
    LSC_EP_HANDLER("lsc_usb_ep_xfer_not_ready: %x\r\n", ep_evt->parameters);

    struct lsc_ep *ep;
    uint32_t ep_num;
    uint32_t cur_uf;
    uint32_t Mask;

    struct user_ep_cnfg sel_ep_user_cnfg;

    ep_num = ep_evt->ep_number;
    ep = &usb_dev->eps[ep_num];

    // Get user configuration for selected endpoint
    if ( ep->ep_direction == LSC_EP_DIR_OUT ) {
        sel_ep_user_cnfg = out_user_ep_cnfg[ep->usb_ep_num];
    } else {
        sel_ep_user_cnfg = in_user_ep_cnfg[ep->usb_ep_num];
    }

    // For Isochronous endpoint, we will get information about current bus
    // time (in terms of micro-frame number) from event data.
    // We will use this information while preparing TRB for this endpoint.
    if (ep->ep_type == LSC_ENDPOINT_XFER_ISOC) {

      ep->cur_micro_frame = ep_evt->parameters;
      LSC_EP_HANDLER("cur_micro_frame: %x\r\n", ep->cur_micro_frame);

    }

    // If endpoint pre-fetch transfer is not enabled, it means it
    // uses on-demand transfer flow. Hence, we should call corresponding
    // function to initiate transfer.
    if (sel_ep_user_cnfg.pre_fetch_xfer == false ) {
        if ( sel_ep_user_cnfg.en_cb != NULL )
                {
                    sel_ep_user_cnfg.en_cb(usb_dev, ep->usb_ep_num, ep->ep_direction);
                }
    }

}


/****************************************************************************/
/**
 * @brief
 * Returns status of endpoint - Stalled or not
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction of endpoint
 *               - LSC_EP_DIR_IN/ LSC_EP_DIR_OUT.
 *
 * @return
 *           1 - if stalled
 *           0 - if not stalled
 *
 * @note     None.
 *****************************************************************************/
uint8_t lsc_usb_is_ep_stalled (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num,
        uint8_t dir)
{
    LSC_EP_HANDLER("lsc_usb_is_ep_stalled\r\n");

    uint8_t phy_ep_num;
    struct lsc_ep *ep;

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);
    ep = &usb_dev->eps[phy_ep_num];

    return (uint32_t)(!!(ep->ep_status & LSC_EP_STALL));
}

/****************************************************************************/
/**
 * @brief
 * Stalls an Endpoint.
 * Set Stall (DEPSSTALL) is issued on endpoint to set stall.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    dir is direction.
 *
 * @return   None.
 *
 * @note     Refer sec 3.2.2.4 of Synopsis Programming Guide Version 3.30b
 *           for Set Stall (DEPSSTALL).
 *****************************************************************************/
void lsc_usb_ep_set_stall (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num,
        uint8_t dir)
{
    LSC_EP_HANDLER("lsc_usb_ep_set_stall\r\n");

    uint8_t phy_ep_num;
    struct lsc_ep *ep = NULL;
    struct lsc_ep_params *params;

    phy_ep_num = lsc_physicalep(usb_ep_num, dir);
    ep = &usb_dev->eps[phy_ep_num];

    params = lsc_usb_get_ep_params(usb_dev);

    lsc_usb_send_ep_cmd(usb_dev, ep->usb_ep_num, ep->ep_direction,
    LSC_DEPCMD_SETSTALL, params);

    ep->ep_status |= LSC_EP_STALL;
}

/****************************************************************************/
/**
 * @brief
 * Sets an user handler to be called after data is sent/received by an Endpoint
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    epnum is USB endpoint number.
 * @param    dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT.
 * @param    handler is user handler to be called.
 *
 * @return   None.
 *
 * @note     None.
 *
 *****************************************************************************/
void lsc_set_ep_handler (struct lsc_usb_dev *usb_dev, uint8_t epnum,
        uint8_t dir, void (*handler) (struct lsc_usb_dev*, uint8_t, uint32_t))
{
    LSC_EP_HANDLER("lsc_SetEpHandler\r\n");
    uint8_t phy_ep_num;
    struct lsc_ep *ep = NULL;

    phy_ep_num = lsc_physicalep(epnum, dir);
    ep = &usb_dev->eps[phy_ep_num];
    ep->handler = (void (*) (struct lsc_usb_dev*, uint8_t, uint32_t))handler;

}

/****************************************************************************/
/**
 * @brief
 * Initiates DMA to receive data on Endpoint from Host.
 *
 * @param    usb_dev is pointer to lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    buf is pointer to data. This data buffer is cache-aligned.
 * @param    len is length of data to be received.
 * @param    last represents last TRB.
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note     This function initiates DMA to receive data on
 *           the endpoint from the Host. The data buffer should be aligned.
 *
 *****************************************************************************/
uint8_t lsc_usb_ep_buf_rcv (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num,
        uint8_t *buf, uint32_t len, uint8_t last)
{
    LSC_EP_HANDLER("lsc_usb_ep_buf_rcv_1\r\n");
    uint8_t phy_ep_num = 0;
    uint32_t cmd = 0, trb_size = 0;
    uint32_t size = 0;
    uint8_t ret_val = 0;
    struct lsc_trb *trb = NULL;
    struct lsc_ep *ep = NULL;
    struct lsc_ep_params params;

    phy_ep_num = lsc_physicalep(usb_ep_num, LSC_EP_DIR_OUT);
    ep = &usb_dev->eps[phy_ep_num];

    // This function is intended to be used for OUT endpoint only.
    // Hence, let's check to ensure user has not mistakenly call this function
    if (ep->ep_direction != LSC_EP_DIR_OUT) {
        printf("Bug! This function is intended to be used for OUT endpoint only.\r\n");
        return (int)LSC_FAIL;
    }

   trb = &usb_dev_dm.ep_trb[phy_ep_num][ep->trb_enqueue];

    if (trb->ctrl & LSC_TRB_CTRL_HWO) {
        // Seems something wrong! Selected TRB is busy.
        printf("Seems something wrong. TRB is busy. TRB no:%d ctrl 0x%x\r\n", ep->trb_enqueue,
                trb->ctrl);
        printf("ep_num = usb_ep_num %d and ep_dir = %d \r\n",usb_ep_num, LSC_EP_DIR_IN);
        return (int)LSC_FAIL;
    }

    trb->buf_ptr_lo = (uintptr_t)buf;
    trb->buf_ptr_hi = ( ( ((uintptr_t) buf) >>16 ) >> 16);

    // While queuing requests, we already check whether requested length
    // can fit in single TRB or not. Hence, no need to check it again here.
    trb->size = len;

    trb->ctrl = 0;

    switch (ep->ep_type) {

        case LSC_ENDPOINT_XFER_ISOC:
        // In our case, we always plan to prepare single TRB for transferring bytes in single service
        // interval for Isochronous transfer. So, we are setting here ISOCHRONUOS FIRST flag.
        // LST bit must not be set for Isochronous transfer.
        // We would like to get an interrupt on missed isochronus service interval.
            trb->ctrl |= (LSC_TRBCTL_ISOCHRONOUS_FIRST | LSC_TRB_CTRL_ISP_IMI);
            break;

        case LSC_ENDPOINT_XFER_INT:
        case LSC_ENDPOINT_XFER_BULK:
            trb->ctrl |= LSC_TRBCTL_NORMAL;
            // Set last flag is user has requested it.
            if ( last ) {
            trb->ctrl |= LSC_TRB_CTRL_LST;
            }
            break;

        default:
            /* Do Nothing. Added for making MISRA-C complaint */
            break;
    }

    // In our case, we are not using CHN (chain) bit and are using single TRB
    // for single request. Hence, we would like controller to move to next TRB if
    // short packet is received for OUT endpoint. Hence, set CSP (continue on
    // short packet) flag.
    // We would like to get an interrupt on completion. Hence, set IOC.
    // Also, set hardware owner flag.

    trb->ctrl |= (LSC_TRB_CTRL_HWO | LSC_TRB_CTRL_IOC | LSC_TRB_CTRL_CSP ) ;

    LSC_EP_HANDLER("trb no 0x%x ctrl 0x%x len 0x%x\r\n", ep->trb_enqueue,
            trb->ctrl, trb->size);

    // Command parameters ------------------------------------------
    params.param0 = 0;
    params.param1 = (uintptr_t)trb;
    params.param2 = 0;

    // If endpoint is busy, we should send Update transfer command.
    // Otherwise start transfer.
    if ((ep->ep_status & LSC_EP_BUSY) != (uint32_t)0) {

        cmd = LSC_DEPCMD_UPDATETRANSFER;

        cmd |= LSC_DEPCMD_PARAM(ep->resource_index);

        params.param1 = 0; // Update transfer no need param value so reset it

        LSC_EP_HANDLER("UPDATE TRANSFER\r\n");

    } else {

        cmd = LSC_DEPCMD_STARTTRANSFER;
        // Means, this is first TRB. So, for Isochronous transfer, we need
        // to find out frame in which controller should start sending response
        // for Isochronous IN transfer.
        if(ep->ep_type == LSC_ENDPOINT_XFER_ISOC) {
            //For Isochronous Transfer, please do not add/enable any print
            //messages otherwise, it may cause command failure or
            //getting missed ISO interval during transfer in TRB Status.
            uint32_t reg, frame;

            reg = lsc_32_read(usb_dev->base_add + LSC_DSTS);
            frame =  LSC_DSTS_SOFFN(reg);
//          printf("frame(deci): %d\r\n", frame);

                bool rollover = frame < (ep->cur_micro_frame & 0x3FFF);

                /*
                 * frame_number is set from XferNotReady and may be already
                 * out of date. DSTS only provides the lower 14 bit of the
                 * current frame number. So add the upper two bits of
                 * frame_number and handle a possible rollover.
                 * This will provide the correct frame_number unless more than
                 * rollover has happened since XferNotReady.
                 */

                ep->cur_micro_frame = (ep->cur_micro_frame & ~0x3FFF) |
                             frame;
                if (rollover)
                    ep->cur_micro_frame += (1 << 14);   //BIT(14);

//              printf("frame(deci): %d\r\n", ep->cur_micro_frame);

                uint32_t future_interval = 2;

                if (ep->bInterval < 3)
                    future_interval += 3 - ep->bInterval;

//              printf("future_interval(deci): %d\r\n", future_interval);

                ep->cur_micro_frame = ((ep->cur_micro_frame + (ep->f_interval * future_interval)) & ~(ep->f_interval - 1));
//              printf("cur_micro_frame_(deci): %d\r\n", ep->cur_micro_frame);

                cmd |= LSC_DEPCMD_PARAM(ep->cur_micro_frame);
//              printf("ISO CMD: %x\r\n", cmd);
        }

        LSC_EP_HANDLER("START TRANSFER\r\n");
    }

   // Send Command
    ret_val = lsc_usb_send_ep_cmd(usb_dev, usb_ep_num, ep->ep_direction, cmd,
            &params);

    if (ret_val != LSC_SUCCESS) {
//      lsc_usb_stop_xfer(usb_dev, usb_ep_num, ep->ep_direction, true);
//      ep->ep_req_cancel = 1;
//      return;
        return LSC_FAIL;
    }

    if ((ep->ep_status & LSC_EP_BUSY) == (uint32_t)0) {

        ep->resource_index = (uint8_t)lsc_usb_ep_get_xfer_index(usb_dev,
                ep->usb_ep_num, ep->ep_direction);
        ep->ep_status |= LSC_EP_BUSY;

    }

    ep->trb_enqueue++;
    if (ep->trb_enqueue == ep->trb_max_slot) {
        ep->trb_enqueue = 0;
    }

    if (ep->trb_free_slot == 0 ) {
        printf("Bug!. TRB Free slot is zero. This shall not happen when we reach here.");
        return LSC_FAIL;
    } else {
        ep->trb_free_slot--;
    }

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * @brief
 * Initiates DMA to send data on endpoint to Host.
 *
 * @param    usb_dev is pointer to lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    buf is pointer to data. This data buffer is cache-aligned.
 * @param    buf_len is length of data buffer.
 * @param    last represents last TRB
 *
 * @return   LSC_SUCCESS else LSC_FAIL
 *
 * @note     This function initiates DMA to send data on
 *           the endpoint towards the Host. The data buffer should be aligned.
 *           DMA is configured using Transfer Request Blocks (TRB).
 *
 *****************************************************************************/
uint8_t lsc_usb_ep_buf_send (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num,
        uint8_t *buf, uint32_t buf_len, uint8_t last)
{
    LSC_EP_HANDLER("lsc_usb_ep_buf_send_1\r\n");

    uint8_t phy_ep_num = 0;
    uint32_t cmd = 0, trb_size = 0;
    uint8_t ret_val = 0;
    struct lsc_trb *trb = NULL;
    struct lsc_ep *ep = NULL;
    struct lsc_ep_params params;

    phy_ep_num = lsc_physicalep(usb_ep_num, LSC_EP_DIR_IN);
    ep = &usb_dev->eps[phy_ep_num];

    if (ep->ep_direction != LSC_EP_DIR_IN) {
        return (int)LSC_FAIL;
    }

   trb = &usb_dev_dm.ep_trb[phy_ep_num][ep->trb_enqueue];

    if (trb->ctrl & LSC_TRB_CTRL_HWO) {
        // Seems something wrong! Selected TRB is busy.
        printf("Seems something wrong. TRB is busy. TRB no:%d ctrl 0x%x\r\n", ep->trb_enqueue,
                trb->ctrl);
        printf("ep_num = usb_ep_num %d and ep_dir = %d \r\n",usb_ep_num, LSC_EP_DIR_IN);
        return (int)LSC_FAIL;
    }

    trb->buf_ptr_lo = (uintptr_t)buf;
    trb->buf_ptr_hi = ( ( ((uintptr_t) buf) >>16 ) >> 16);

    // While queuing requests, we already check whether requested length
    // can fit in single TRB or not. Hence, no need to check it again here.
    trb->size = buf_len;

    trb->ctrl = 0;

    switch (ep->ep_type) {

        case LSC_ENDPOINT_XFER_ISOC:
        // In our case, we always plan to prepare single TRB for transferring bytes in single service
        // interval for Isochronous transfer. So, we are setting here ISOCHRONUOS FIRST flag.
        // LST bit must not be set for Isochronous transfer.
        // We would like to get an interrupt on missed isochronus service interval.
            trb->ctrl |= (LSC_TRBCTL_ISOCHRONOUS_FIRST | LSC_TRB_CTRL_ISP_IMI);
            break;

        case LSC_ENDPOINT_XFER_INT:
        case LSC_ENDPOINT_XFER_BULK:
            trb->ctrl |= LSC_TRBCTL_NORMAL;
            // Set last flag is user has requested it.
            if ( last ) {
            trb->ctrl |= LSC_TRB_CTRL_LST;
            }
            break;

        default:
            /* Do Nothing. Added for making MISRA-C complaint */
            break;
    }

    // CSP (continue on short packet) is applicable for OUT endpoint. Hence, no need to set it.
    // We would like to get an interrupt on completion. Hence, set IOC.
    // Also, set hardware owner flag.

    trb->ctrl |= (LSC_TRB_CTRL_HWO | LSC_TRB_CTRL_IOC);

    LSC_EP_HANDLER("trb no 0x%x ctrl 0x%x len 0x%x\r\n", ep->trb_enqueue,
            trb->ctrl, trb->size);

    // Command parameters ------------------------------------------
    params.param0 = 0;
    params.param1 = (uintptr_t)trb;
    params.param2 = 0;

    // If endpoint is busy, we should send Update transfer command.
    // Otherwise start transfer.
    if ((ep->ep_status & LSC_EP_BUSY) != (uint32_t)0) {

        cmd = LSC_DEPCMD_UPDATETRANSFER;

        cmd |= LSC_DEPCMD_PARAM(ep->resource_index);

        params.param1 = 0; // Update transfer no need param value so reset it

        LSC_EP_HANDLER("UPDATE TRANSFER\r\n");

    } else {

        cmd = LSC_DEPCMD_STARTTRANSFER;
        // Means, this is first TRB. So, for Isochronous transfer, we need
        // to find out frame in which controller should start sending response
        // for Isochronous IN transfer.
        if(ep->ep_type == LSC_ENDPOINT_XFER_ISOC) {
            //For Isochronous Transfer, please do not add/enable any print
            //messages otherwise, it may cause command failure or
            //getting missed ISO interval during transfer in TRB Status.
            uint32_t reg, frame;

            reg = lsc_32_read(usb_dev->base_add + LSC_DSTS);
            frame =  LSC_DSTS_SOFFN(reg);
//          printf("frame(deci): %d\r\n", frame);

                bool rollover = frame < (ep->cur_micro_frame & 0x3FFF);

                /*
                 * frame_number is set from XferNotReady and may be already
                 * out of date. DSTS only provides the lower 14 bit of the
                 * current frame number. So add the upper two bits of
                 * frame_number and handle a possible rollover.
                 * This will provide the correct frame_number unless more than
                 * rollover has happened since XferNotReady.
                 */

                ep->cur_micro_frame = (ep->cur_micro_frame & ~0x3FFF) |
                             frame;
                if (rollover)
                    ep->cur_micro_frame += (1 << 14);   //BIT(14);

//              printf("frame(deci): %d\r\n", ep->cur_micro_frame);

                uint32_t future_interval = 2;

                if (ep->bInterval < 3)
                    future_interval += 3 - ep->bInterval;

//              printf("future_interval(deci): %d\r\n", future_interval);

                ep->cur_micro_frame = ((ep->cur_micro_frame + (ep->f_interval * future_interval)) & ~(ep->f_interval - 1));
//              printf("cur_micro_frame_(deci): %d\r\n", ep->cur_micro_frame);

                cmd |= LSC_DEPCMD_PARAM(ep->cur_micro_frame);
//              printf("ISO CMD: %x\r\n", cmd);
        }

        LSC_EP_HANDLER("START TRANSFER\r\n");
    }

   // Send Command
    ret_val = lsc_usb_send_ep_cmd(usb_dev, usb_ep_num, ep->ep_direction, cmd,
            &params);

    if (ret_val != LSC_SUCCESS) {
//      lsc_usb_stop_xfer(usb_dev, usb_ep_num, ep->ep_direction, true);
//      ep->ep_req_cancel = 1;
//      return;
        return LSC_FAIL;
    }

    if ((ep->ep_status & LSC_EP_BUSY) == (uint32_t)0) {

        ep->resource_index = (uint8_t)lsc_usb_ep_get_xfer_index(usb_dev,
                ep->usb_ep_num, ep->ep_direction);
        ep->ep_status |= LSC_EP_BUSY;

    }

    ep->trb_enqueue++;
    if (ep->trb_enqueue == ep->trb_max_slot) {
        ep->trb_enqueue = 0;
    }

    if (ep->trb_free_slot == 0 ) {
        printf("Bug!. TRB Free slot is zero. This shall not happen when we reach here.");
        return LSC_FAIL;
    } else {
    ep->trb_free_slot--;
    }

    return LSC_SUCCESS;
}

/** @} */
