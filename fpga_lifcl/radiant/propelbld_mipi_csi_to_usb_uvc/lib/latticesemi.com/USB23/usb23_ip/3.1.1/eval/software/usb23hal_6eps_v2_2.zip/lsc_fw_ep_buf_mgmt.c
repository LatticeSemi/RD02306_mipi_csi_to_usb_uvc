/****************************************************************************/
/**
 *
 * @file lsc_fw_ep_buf_mgmt.c
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/
#include "lsc_usb_dev.h"
#include "pic.h"

//#define DEBUG_LSC_FW_EP_BUF_MGMT

#ifdef DEBUG_LSC_FW_EP_BUF_MGMT
#define LSC_FW_EP_BUF_MGMT(msg, ...) sprintf(print_buf, msg, ##__VA_ARGS__); lsc_uart_tx(print_buf)
#else
#define LSC_FW_EP_BUF_MGMT(msg, ...)
#endif

extern const struct user_ep_cnfg  out_user_ep_cnfg[16];
extern const struct user_ep_cnfg  in_user_ep_cnfg[16];

/****************************************************************************/
/**
 * @brief
 * Configures firmware managed IN endpoint buffer.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 *
 * @return   LSC_SUCCESS else LSC_FAIL.
 *
 * @note     None.
 ****************************************************************************/
uint8_t lsc_fw_ep_buf_mgmt_init (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir)
{

    LSC_FW_EP_BUF_MGMT("lsc_fw_ep_buf_mgmt_init\r\n");
    LSC_FW_EP_BUF_MGMT("usb_ep_num = %d and ep_dir = %d \r\n",usb_ep_num, ep_dir);

    uint32_t reg_val;
    uint32_t ret;
    uint8_t no_of_buf_to_be_accept_fw;
    uint32_t ebm_reg_base_8;
    uint32_t ebm_mem_base_8;
    uint32_t tmp;
    struct user_ep_cnfg sel_ep_user_cnfg;

    struct lsc_ep *ep;

    uint8_t phy_ep_num;

    // Find physical endpoint number
    phy_ep_num = lsc_physicalep(usb_ep_num, ep_dir);

    // Get endpoint structure
    ep = &usb_dev->eps[phy_ep_num];

    // Get user configuration for selected endpoint
    if ( ep_dir == LSC_EP_DIR_OUT ) {
        sel_ep_user_cnfg = out_user_ep_cnfg[usb_ep_num];
    } else {
        sel_ep_user_cnfg = in_user_ep_cnfg[usb_ep_num];
    }

    // Let's check whether user has allocated enough single buffer depth or not.
    if ( ep->min_bufr_span > sel_ep_user_cnfg.ebm_fw_single_bufr_depth ) {
        LSC_DISP_ERROR("BUG! Allocated single buffer depth is less than minimum buffer size required.\r\n");
        LSC_DISP_ERROR("Minimum buffer required: %d while allocated single buffer depth = %d\r\n",ep->min_bufr_span,sel_ep_user_cnfg.ebm_fw_single_bufr_depth);
        return LSC_FAIL;
    }

    // Let's check whether user has allocated enough total buffer depth or not.
    if (
            ( ep->min_bufr_span * sel_ep_user_cnfg.ebm_fw_total_bufrs )
            > sel_ep_user_cnfg.ebm_total_bufr_span ) {
            LSC_DISP_ERROR("BUG! Allocated total buffer depth is less than required.\r\n");
            LSC_DISP_ERROR("Minimum single buffer space required: %d \r\n",ep->min_bufr_span,sel_ep_user_cnfg.ebm_fw_single_bufr_depth);
            LSC_DISP_ERROR("Total buffers: %d \r\n",sel_ep_user_cnfg.ebm_fw_total_bufrs);
            LSC_DISP_ERROR("Required total buffer depth: %d \r\n",ep->min_bufr_span * sel_ep_user_cnfg.ebm_fw_total_bufrs);
            LSC_DISP_ERROR("Allocated total buffer depth = %d\r\n",ep->min_bufr_span,sel_ep_user_cnfg.ebm_total_bufr_span);
            return LSC_FAIL;
        }

    // Let's find out size for which single TRB shall be configured.
    // For periodic endpoint, TRB will be configured for bytes which can be transferred
    // in single service interval.
    // For other endpoints, we will try to configure it to maximum number of packets which
    // can be accommodated in single buffer allocated by user.
    if (
        (ep->ep_type == LSC_ENDPOINT_XFER_ISOC) ||
        (ep->ep_type == LSC_ENDPOINT_XFER_INT)
    ) {
        ep->trb_xfer_req_size = ep->min_bufr_span;
    } else {

        LSC_FW_EP_BUF_MGMT("ebm_fw_single_bufr_depth =%d \r\n",sel_ep_user_cnfg.ebm_fw_single_bufr_depth);
        LSC_FW_EP_BUF_MGMT("ep->min_bufr_span =%d \r\n",ep->min_bufr_span);

        // Following logic finds maximum number of packets which can be
        // requested in single TRB. Each packet will be of maximum packet size.
        tmp = ep->min_bufr_span;
        while ( sel_ep_user_cnfg.ebm_fw_single_bufr_depth > tmp  ) {
            LSC_FW_EP_BUF_MGMT("tmp =%d \r\n",tmp);
            tmp = tmp + ep->min_bufr_span;
        }
        LSC_FW_EP_BUF_MGMT("tmp =%d \r\n",tmp);
        // At this time, tmp value will be greater than single buffer depth.
        // So, let's subtract
        if  ( sel_ep_user_cnfg.ebm_fw_single_bufr_depth > tmp  ) {
        ep->trb_xfer_req_size = tmp - ep->min_bufr_span;
        } else {
        ep->trb_xfer_req_size = tmp;
        }
    }

    LSC_FW_EP_BUF_MGMT("TRB transfer request size = %d \r\n",ep->trb_xfer_req_size);

    // Let's reset some trackers

    // USB Buffer tracker. This points to next buffer which shall be
    // handed over to USB.
    ep->ebm_usb_bufr_tracker = 0;

    // IP Buffer tracker. This points to next buffer which shall be
    // handed over to IP (user).
    ep->ebm_ip_bufr_tracker = 0;

    ep->ebm_init_success = true;

    return LSC_SUCCESS;

 }

/****************************************************************************/
/**
 * @brief
 * Initiates firmware managed IN tansfer.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 *
 * @return   LSC_SUCCESS else LSC_FAIL.
 *
 * @note     None.
 ****************************************************************************/
uint8_t lsc_fw_ep_buf_mgmt_enable (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num , uint8_t ep_dir)
{

    uint32_t reg_val;
    uint32_t ret;
    uint32_t ebm_reg_base_8;
    uint32_t ebm_mem_base_8;
    uint32_t buf_offset;
    uint32_t ebm_single_bufr_depth;

    uint8_t ebm_total_bufrs;
    uint8_t no_of_buf_to_be_accept_fw;

    struct user_ep_cnfg sel_ep_user_cnfg;

    struct lsc_ep *ep;

    uint8_t phy_ep_num;

    // Find physical endpoint number
    phy_ep_num = lsc_physicalep(usb_ep_num, ep_dir);

    // Get endpoint structure
    ep = &usb_dev->eps[phy_ep_num];

    // Get user configuration for selected endpoint
    if ( ep_dir == LSC_EP_DIR_OUT ) {
        sel_ep_user_cnfg = out_user_ep_cnfg[usb_ep_num];
    } else {
        sel_ep_user_cnfg = in_user_ep_cnfg[usb_ep_num];
    }

    // Check whether initialization was successful or not.
    if (ep->ebm_init_success == false ) {
        LSC_DISP_ERROR("Initialization is not successful. So, can not enable transfers.!\r\n");
        return LSC_FAIL;
    }

    // To improve code readability, we are using some local variables to use
    // short names.
    ebm_single_bufr_depth = sel_ep_user_cnfg.ebm_fw_single_bufr_depth;

    ebm_mem_base_8 = sel_ep_user_cnfg.ebm_mem_base_8;

    ebm_total_bufrs = sel_ep_user_cnfg.ebm_fw_total_bufrs;

    // Reinitialize following variables upon enable
    ep->trb_free_slot = sel_ep_user_cnfg.ep_trb_slots;
    ep->max_no_of_ep_xfer_req = sel_ep_user_cnfg.ep_req_queue_size;


    // Initially all buffers will be available to firmware. Hence, we can submit
    // requests to USB controller.
    no_of_buf_to_be_accept_fw = sel_ep_user_cnfg.ebm_fw_total_bufrs;


    LSC_FW_EP_BUF_MGMT("no_of_buf_to_be_accept_fw: %x\r\n",
            no_of_buf_to_be_accept_fw);

   // Enable request queuing
    ep->req_queue_en = 1;

    // USB Buffer tracker. This points to next buffer which shall be
    // handed over to USB.
    ep->ebm_usb_bufr_tracker = 0;

    // IP Buffer tracker. This points to next buffer which shall be
    // handed over to IP (user).
    ep->ebm_ip_bufr_tracker = 0;

    while (no_of_buf_to_be_accept_fw) {

        uint32_t buf_offset = ebm_mem_base_8 + (ep->ebm_usb_bufr_tracker * ebm_single_bufr_depth);

        LSC_FW_EP_BUF_MGMT("buf_offset: %x\r\n", buf_offset);
        LSC_FW_EP_BUF_MGMT("ep->ebm_usb_bufr_tracker: 0x%x\r\n", ep->ebm_usb_bufr_tracker);
        LSC_FW_EP_BUF_MGMT("ep->trb_xfer_req_size: 0x%x\r\n", ep->trb_xfer_req_size);

        //printf("ep->ebm_usb_bufr_tracker: %x\r\n", ep->ebm_usb_bufr_tracker);
        ret = lsc_usb_ep_xfer_req(usb_dev, usb_ep_num, ep_dir,
                        (uint8_t*)buf_offset, ep->trb_xfer_req_size);


        if (ret) {
            // When the queue is full - This is not expected to happen.
            // If this happens this will cause OEBM IRQ to remain high.
            LSC_DISP_ERROR("BUG! Queue is full!\r\n");
            LSC_DISP_ERROR("Please ensure number of buffers available to EBM is not greater than total TRBs available to EP.\r\n");
            break;
        } else {

            // Decrement number of buffers to be accepted by firmware
            no_of_buf_to_be_accept_fw--;

            // Increment OEBM buffer index
            ep->ebm_usb_bufr_tracker++;

            // Rollover to 0 if it has reached upper limit.
            if(ep->ebm_usb_bufr_tracker == ebm_total_bufrs) {
              ep->ebm_usb_bufr_tracker = 0;
            }
        }

    }

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * @brief
 * Disables firmware managed IN tansfer request queuing.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 *
 * @return   LSC_SUCCESS else LSC_FAIL.
 *
 * @note     None.
 ****************************************************************************/
uint8_t lsc_fw_ep_buf_mgmt_disable (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir)
{

    LSC_FW_EP_BUF_MGMT("lsc_fw_ep_buf_mgmt_disable\r\n");
    LSC_FW_EP_BUF_MGMT("usb_ep_num = %d and ep_dir = %d \r\n",usb_ep_num, ep_dir);

    struct lsc_ep *ep;

    uint8_t phy_ep_num;

    phy_ep_num = lsc_physicalep(usb_ep_num, ep_dir);

    ep = &usb_dev->eps[phy_ep_num];

    // Just disable request queuing
    // This shall help to prevent further queuing request during transfer completion.
    ep->req_queue_en = 0;

    return LSC_SUCCESS;

}

/****************************************************************************

 * @brief This function is used to handle firmware manged IEBM configuration
 * when USB controller indicates transfer is completed.
 *
 * @param usb_dev Pointer to the USB device structure.
 * @param usb_ep_num Endpoint number for the USB device.
 * @param ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 * @param xferred_bytes Number of bytes transferred.
 *
 * @return   None.
 *
 * @note     None.
 ****************************************************************************/
void lsc_fw_ep_buf_mgmt_xfer_completion_cb (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir, uint32_t xferred_bytes)
{
    LSC_FW_EP_BUF_MGMT("lsc_fw_ep_buf_mgmt_xfer_completion_cb\r\n");

    uint32_t ebm_mem_base_8;
    uint32_t ebm_single_bufr_depth;
    uint32_t bufr_offset;
    uint32_t ret;
    uint32_t i;

    uint8_t ebm_total_bufrs;
    struct lsc_ep *ep;

    uint8_t phy_ep_num;

    struct user_ep_cnfg sel_ep_user_cnfg;

    uint8_t *bufr_offset_1;

    // Find physical endpoint number
    phy_ep_num = lsc_physicalep(usb_ep_num, ep_dir);

    // Get endpoint structure
    ep = &usb_dev->eps[phy_ep_num];

    // Get user configuration for selected endpoint
    if ( ep_dir == LSC_EP_DIR_OUT ) {
        sel_ep_user_cnfg = out_user_ep_cnfg[usb_ep_num];
    } else {
        sel_ep_user_cnfg = in_user_ep_cnfg[usb_ep_num];
    }

    // To improve code readability, we are using some local variables to use
    // short names.
    // Single buffer depth
    ebm_single_bufr_depth = sel_ep_user_cnfg.ebm_fw_single_bufr_depth;

    // Memory base
    ebm_mem_base_8 = sel_ep_user_cnfg.ebm_mem_base_8;

    ebm_total_bufrs = sel_ep_user_cnfg.ebm_fw_total_bufrs;

    // Let's see how many bytes have been transferred for last completed request.
    LSC_FW_EP_BUF_MGMT("usb_ep_num = %d \r\n",usb_ep_num);
    LSC_FW_EP_BUF_MGMT("dir = %d \r\n",ep_dir);
    LSC_FW_EP_BUF_MGMT("xferred_bytes = %d \r\n",xferred_bytes);
    LSC_FW_EP_BUF_MGMT("ebm_usb_bufr_tracker = %d \r\n",ep->ebm_usb_bufr_tracker);

    // Display number of bytes transferred for debugging purpose.
    //printf("%d \r\n",xferred_bytes);

    // If user has requested us to display number of bytes transferred, we will
    // display it.
    if (sel_ep_user_cnfg.disp_xfer_len) {
        printf("No of bytes transferred: %d \r\n",xferred_bytes);
    }
    // If user has requested us to display packet data, we will
    // display it.
    if (sel_ep_user_cnfg.disp_xferred_data){
        printf("Buffer %d is having following data: \r\n",ep->ebm_ip_bufr_tracker);

        bufr_offset_1 = (uint8_t *)(ebm_mem_base_8 + (ep->ebm_ip_bufr_tracker * ebm_single_bufr_depth));

        printf("Buffer base offset: 0x%x\r\n", bufr_offset);

        // Future Scope:
        // Should we use some macro instead of printf function?
        for ( i = 0; i < xferred_bytes; i++ ) {

            if ( (i % 10 ) ==  0 ){
                            printf("\r\n");
                        }
            printf("0x%x \t", *(bufr_offset_1++));

        }
        printf("\r\n");
    }

    // Increment IP buffer tracker
    ep->ebm_ip_bufr_tracker++;

    // Rollover to 0 if it has reached upper limit.
    if(ep->ebm_ip_bufr_tracker == ebm_total_bufrs) {
        ep->ebm_ip_bufr_tracker = 0;
    }

    // One request is finished. So, we will submit one request if queuing is enabled.
    if ( ep->req_queue_en ) {
        bufr_offset = ebm_mem_base_8 + (ep->ebm_usb_bufr_tracker * ebm_single_bufr_depth);

        LSC_FW_EP_BUF_MGMT("bufr_offset: %x\r\n", bufr_offset);
        LSC_FW_EP_BUF_MGMT("ep->ebm_usb_bufr_tracker: 0x%x\r\n", ep->ebm_usb_bufr_tracker);
        LSC_FW_EP_BUF_MGMT("ep->trb_xfer_req_size: 0x%x\r\n", ep->trb_xfer_req_size);

        //printf("ep->ebm_usb_bufr_tracker: %x\r\n", ep->ebm_usb_bufr_tracker);
        ret = lsc_usb_ep_xfer_req(usb_dev, usb_ep_num, ep_dir,
                        (uint8_t*)bufr_offset, ep->trb_xfer_req_size);

        if (ret) {
            // When the queue is full - This is not expected to happen.
            // If this happens this will cause OEBM IRQ to remain high.
            LSC_DISP_ERROR("BUG! Queue is full!\r\n");
            LSC_DISP_ERROR("Please ensure number of buffers available to EBM is not greater than total TRBs available to EP.\r\n");

        } else {
            // Increment OEBM buffer index
            ep->ebm_usb_bufr_tracker++;

            // Rollover to 0 if it has reached upper limit.
            if(ep->ebm_usb_bufr_tracker == ebm_total_bufrs) {
                ep->ebm_usb_bufr_tracker = 0;
            }
        }
    } else {
        LSC_FW_EP_BUF_MGMT("Queuing is disabled.So, next request is not queued.\r\n");
    }

}

/** @} */
