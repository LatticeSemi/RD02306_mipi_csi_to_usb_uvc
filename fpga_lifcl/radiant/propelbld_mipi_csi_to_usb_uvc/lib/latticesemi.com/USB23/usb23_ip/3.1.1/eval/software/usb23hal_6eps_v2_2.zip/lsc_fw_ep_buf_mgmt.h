/****************************************************************************/
/**
 *
 * @file lsc_fw_ep_buf_mgmt.h
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/

#ifndef LSC_FW_EP_BUF_MGMT_H_
#define LSC_FW_EP_BUF_MGMT_H_


#ifdef __cplusplus
extern "C" {
#endif

// -----------------------------------------------------------------------------------------

// Single buffer depth for OUT endpoint
// At present, we are using common buffer for Isochronous OUT and Interrupt OUT endpoints.
// In present configuration, maximum data which will be sent in single service interval for
// either Isochronous or Interrupt OUT endpoint is 3072 bytes. Hence, we have choosen this value.
// One should update it if endpoint related configuration in lsc_user_ep_cnfg.h is updated.
// Kindly note that this is used for endpoints which are not using FIFO based EBM (such as
// IEBM or OEBM). Endpoints having FIFO based EBM are using different memory buffers.
// Future scope: We can use separate buffers for both based on memory availability.
#define LSC_OUT_EP_SINGLE_BUFR_DEPTH 3072   /**< Single buffer depth for OUT endpoint */

// Total buffers for OUT endpoints
#define LSC_OUT_EP_TOTAL_BUFRS 4    /**< Total buffers for OUT endpoints */

// Total buffer depth
#define LSC_OUT_EP_TOTAL_BUFR_DEPTH ( LSC_OUT_EP_SINGLE_BUFR_DEPTH * LSC_OUT_EP_TOTAL_BUFRS)    /**< Total buffer depth for OUT endpoints */

// -----------------------------------------------------------------------------------------


// Single buffer depth for IN endpoint
// At present, we are using common buffer for Isochronous IN and Interrupt IN endpoints.
// In present configuration, maximum data which will be sent in single service interval for
// either Isochronous or Interrupt IN endpoint is 3072 bytes. Hence, we have choosen this value.
// One should update it if endpoint related configuration in lsc_user_ep_cnfg.h is updated.
// Kindly note that this is used for endpoints which are not using FIFO based EBM (such as
// IEBM or OEBM). Endpoints having FIFO based EBM are using different memory buffers.
// Future scope: We can use separate buffers for both based on memory availability.
#define LSC_IN_EP_SINGLE_BUFR_DEPTH 3072    /**< Single buffer depth for IN endpoint */

// Total buffers for IN endpoints
#define LSC_IN_EP_TOTAL_BUFRS 4     /**< Total buffers for IN endpoints */

// Total buffer depth
#define LSC_IN_EP_TOTAL_BUFR_DEPTH ( LSC_IN_EP_SINGLE_BUFR_DEPTH * LSC_IN_EP_TOTAL_BUFRS)       /**< otal buffer depth for IN endpoints */


#ifdef __cplusplus
}
#endif

#endif /* LSC_FW_EP_BUF_MGMT_H_ */

/** @} */
