/****************************************************************************/
/**
 *
 * @file lsc_in_ep_buf_mgmt.c
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/
#include "lsc_usb_dev.h"
#include "pic.h"

//#define DEBUG_LSC_IN_EP_BUF_MGMT

#ifdef DEBUG_LSC_IN_EP_BUF_MGMT
#define LSC_IN_EP_BUF_MGMT(msg, ...) sprintf(print_buf, msg, ##__VA_ARGS__); lsc_uart_tx(print_buf)
#else
#define LSC_IN_EP_BUF_MGMT(msg, ...)
#endif

extern const struct user_ep_cnfg  in_user_ep_cnfg[16];

struct lsc_dev_iebm_eps dev_iebm_eps[16];

/****************************************************************************/
/**
 * @brief
 * Configure/Re-Configure In endpoint buffer mangement IP Core.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 *
 * @return   LSC_SUCCESS else LSC_FAIL.
 *
 * @note     None.
 ****************************************************************************/
uint8_t lsc_iebm_init (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir)
{
    LSC_IN_EP_BUF_MGMT("lsc_iebm_init\r\n");

    uint32_t reg_val = 0, fw_buf = 0, fw_buf_depth = 0, hw_max_buf = 0,
            hw_buf_depth = 0, status;

    uint32_t ebm_reg_base_8;

    struct lsc_ep *ep;

    uint8_t phy_ep_num;


    if (ep_dir != LSC_EP_DIR_IN) {
        LSC_DISP_ERROR("BUG! IEBM shall be used only for IN endpoint. Kindly check configuration.\r\n");
        return LSC_FAIL;
    }

    dev_iebm_eps[usb_ep_num].usb_dev = usb_dev;
    dev_iebm_eps[usb_ep_num].usb_ep_no = usb_ep_num;

    // Find Physical Endpoint number
    phy_ep_num = lsc_physicalep(usb_ep_num, ep_dir);

    // Get endpoint structure
    ep = &usb_dev->eps[phy_ep_num];

    ebm_reg_base_8 = in_user_ep_cnfg[usb_ep_num].ebm_reg_base_8;

    //IP Version
    // Future scope: Add condition to check whether IP version matches
    // with expected number or not. If it doesn't, we shall return from here.
    reg_val = lsc_32_read(ebm_reg_base_8 + LSC_IEBM_IP_VER_REG);
    LSC_IN_EP_BUF_MGMT("IP_VER_REG: %x\r\n", reg_val);

    // Get Hardware configured parameter information
    reg_val = lsc_32_read(ebm_reg_base_8 + LSC_IEBM_HW_INFO_REG);

    hw_max_buf = LSC_IEBM_HW_MAX_BUF(reg_val);
    LSC_IN_EP_BUF_MGMT("hw_max_buf: %x\r\n", hw_max_buf);

    hw_buf_depth = LSC_IEBM_HW_SINGLE_BUF_MAX_DEPTH(reg_val);
    LSC_IN_EP_BUF_MGMT("hw_buf_depth: %x\r\n", hw_buf_depth);

    // Buffer span equals to Hardware buffer depth
    ep->ebm_bufr_span = hw_buf_depth;

   //Disable Interrupt
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_INT_EN_REG),
            ~LSC_IEBM_BUF_AVAIL_TO_FW_INT_EN_MASK);

    //Reset configured bit in CTRL register
    reg_val = lsc_32_read((ebm_reg_base_8 + LSC_IEBM_CTRL_REG));
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_CTRL_REG),
            (reg_val & (~LSC_IEBM_IP_CNF_MASK)));

    //Load buffer configuration register
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_BUF_CNF_REG),
            ((LSC_IEBM_FW_TOTAL_BUF << LSC_IEBM_FW_TOTAL_BUF_OFST)
                    | LSC_IEBM_FW_SINGLE_BUF_DEPTH));

    reg_val = lsc_32_read(ebm_reg_base_8 + LSC_IEBM_BUF_CNF_REG);
    LSC_IN_EP_BUF_MGMT("BUF_CNF_REG: %x\r\n", reg_val);

    fw_buf = LSC_IEBM_TOTAL_FW_BUF(reg_val);
    LSC_IN_EP_BUF_MGMT("fw_buf: %x\r\n", fw_buf);

    if (fw_buf > hw_max_buf) {
        LSC_DISP_ERROR("BUG! FW allocated more buffers than available in HW\r\n");
        return LSC_FAIL;
    } else if (fw_buf < hw_max_buf) {
        LSC_DISP_WARNING("FW buffers = %d while HW buffers = %d\r\n",fw_buf,hw_max_buf);
        LSC_DISP_WARNING("Warning. FW is not fully utilizing hardware allocted resources. This could degrade performance.\r\n");
    }

    // Let's check whether firmware allocated depth is within range or not.
    LSC_IN_EP_BUF_MGMT("ebm_fw_single_bufr_depth: %x\r\n", in_user_ep_cnfg[usb_ep_num].ebm_fw_single_bufr_depth);

    if (in_user_ep_cnfg[usb_ep_num].ebm_fw_single_bufr_depth > hw_buf_depth) {
        LSC_DISP_ERROR("FW buffer depth is more than HW buffer depth\r\n");
        LSC_DISP_ERROR("FW buffer depth = %d while HW buffer depth = %d.\r\n",in_user_ep_cnfg[usb_ep_num].ebm_fw_single_bufr_depth, hw_buf_depth);
        return LSC_FAIL;
    }

    // USB Buffer tracker. This points to next buffer which shall be
    // handed over to USB.
    ep->ebm_usb_bufr_tracker = 0;

    // IP Buffer tracker. This points to next buffer which shall be
    // handed over to IP (user).
    ep->ebm_ip_bufr_tracker = 0;


    //Set flush buffer bit in CTRL register
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_CTRL_REG),
            LSC_IEBM_FLUSH_BUF_MASK);

    //Wait until flush buffer bit is cleared
    while (lsc_32_read(ebm_reg_base_8 + LSC_IEBM_CTRL_REG)
            & LSC_IEBM_FLUSH_BUF_MASK)
        ;

    status = pic_isr_register(in_user_ep_cnfg[usb_ep_num].ebm_irq,
                              lsc_iebm_buf_int_handler,
                              &dev_iebm_eps[usb_ep_num]);
    if (status != LSC_SUCCESS)
    {
        printf("IEBM ISR Fail.\r\n");
        return LSC_FAIL;
    }

    // EBM initialization is done.
    ep->ebm_init_done = true;

    return LSC_SUCCESS;

}

/****************************************************************************/
/**
 * @brief
 * Initiates IEBM transfer requets.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 *
 * @return   LSC_SUCCESS else LSC_FAIL.
 *
 * @note     None.
 ****************************************************************************/
uint8_t lsc_iebm_enable (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir)
{
    LSC_IN_EP_BUF_MGMT("lsc_iebm_enable\r\n");

    uint32_t reg_val = 0, fw_buf = 0, fw_buf_depth = 0, hw_max_buf = 0,
            hw_buf_depth = 0;

    uint32_t ebm_reg_base_8;

    struct lsc_ep *ep;

    uint8_t phy_ep_num;

    // Find Physical Endpoint number
    phy_ep_num = lsc_physicalep(usb_ep_num, LSC_EP_DIR_IN);

    // Get endpoint structure
    ep = &usb_dev->eps[phy_ep_num];

    ebm_reg_base_8 = in_user_ep_cnfg[usb_ep_num].ebm_reg_base_8;

   //Disable Interrupt
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_INT_EN_REG),
            ~LSC_IEBM_BUF_AVAIL_TO_FW_INT_EN_MASK);

    //Reset configured bit in CTRL register
    reg_val = lsc_32_read((ebm_reg_base_8 + LSC_IEBM_CTRL_REG));
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_CTRL_REG),
            (reg_val & (~LSC_IEBM_IP_CNF_MASK)));

    // USB Buffer tracker. This points to next buffer which shall be
    // handed over to USB.
    ep->ebm_usb_bufr_tracker = 0;

    // IP Buffer tracker. This points to next buffer which shall be
    // handed over to IP (user).
    ep->ebm_ip_bufr_tracker = 0;

    // Reinitialize following variables upon enable
    ep->trb_free_slot = in_user_ep_cnfg[usb_ep_num].ep_trb_slots;
    ep->max_no_of_ep_xfer_req = in_user_ep_cnfg[usb_ep_num].ep_req_queue_size;

    //Set flush buffer bit in CTRL register
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_CTRL_REG),
            LSC_IEBM_FLUSH_BUF_MASK);

    //Wait until flush buffer bit is cleared
    while (lsc_32_read(ebm_reg_base_8 + LSC_IEBM_CTRL_REG)
            & LSC_IEBM_FLUSH_BUF_MASK)
        ;

    //Enable Interrupt
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_INT_EN_REG),
           LSC_IEBM_BUF_AVAIL_TO_FW_INT_EN_MASK);

    //Set configured bit in CTRL register
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_CTRL_REG), LSC_IEBM_IP_CNF_MASK);

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * @brief
 * Disables/Flush IEBM tansfer request queuing.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 *
 * @return   LSC_SUCCESS else LSC_FAIL.
 *
 * @note     None.
 ****************************************************************************/
uint8_t lsc_iebm_disable (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir)
{
    LSC_IN_EP_BUF_MGMT("lsc_iebm_disable\r\n");

    uint32_t reg_val = 0, fw_buf = 0, fw_buf_depth = 0, hw_max_buf = 0,
            hw_buf_depth = 0;

    uint32_t ebm_reg_base_8;

    struct lsc_ep *ep;

    uint8_t phy_ep_num;

    // Find Physical Endpoint number
    phy_ep_num = lsc_physicalep(usb_ep_num, LSC_EP_DIR_IN);

    // Get endpoint structure
    ep = &usb_dev->eps[phy_ep_num];

    ebm_reg_base_8 = in_user_ep_cnfg[usb_ep_num].ebm_reg_base_8;


   //Disable Interrupt
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_INT_EN_REG),
            ~LSC_IEBM_BUF_AVAIL_TO_FW_INT_EN_MASK);

    //Reset configured bit in CTRL register
    reg_val = lsc_32_read((ebm_reg_base_8 + LSC_IEBM_CTRL_REG));
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_CTRL_REG),
            (reg_val & (~LSC_IEBM_IP_CNF_MASK)));


    // USB Buffer tracker. This points to next buffer which shall be
    // handed over to USB.
    ep->ebm_usb_bufr_tracker = 0;

    // IP Buffer tracker. This points to next buffer which shall be
    // handed over to IP (user).
    ep->ebm_ip_bufr_tracker = 0;

    //Set flush buffer bit in CTRL register
    lsc_32_write((ebm_reg_base_8 + LSC_IEBM_CTRL_REG),
            LSC_IEBM_FLUSH_BUF_MASK);

    //Wait until flush buffer bit is cleared
    while (lsc_32_read(ebm_reg_base_8 + LSC_IEBM_CTRL_REG)
            & LSC_IEBM_FLUSH_BUF_MASK)
        ;

    return LSC_SUCCESS;
}

/****************************************************************************/
/**
 * @brief
 * LSC_IEBM Buffer Management Interrupt Handler.
 *
 * @param    context is a pointer to the lsc_usb_dev instance.
 *
 * @return   None.
 *
 * @note     None.
 *****************************************************************************/
void lsc_iebm_buf_int_handler (void *context)
{
    LSC_IN_EP_BUF_MGMT("lsc_iebm_buf_int_handler\r\n");

    struct lsc_dev_iebm_eps *dev_iebm_ep = (struct lsc_dev_iebm_eps *)context;
    struct lsc_ep *ep;
    uint8_t sel_buf_first_xfer = 0, sel_buf_last_xfer = 0;
    uint32_t reg_val = 0, sel_buf_sz = 0, buf_offset = 0, *ptr = NULL;
    uint8_t no_of_buf_to_be_proc_fw = 0, sel_buf_num = 0, ret = 0;
    uint8_t phy_ep_num = 0;
    uint32_t ebm_reg_base_8;
    uint32_t ebm_mem_base_8;

    // Future Scope:
    // At the moment, following is fixed for single Bulk endpoint.
    // We should see how we can support multiple endpoints.
    phy_ep_num = lsc_physicalep(/*BULK_IN_EP_NO*/dev_iebm_ep->usb_ep_no, LSC_EP_DIR_IN);

//    ep = &usb_dev->eps[phy_ep_num];
    ep = &dev_iebm_ep->usb_dev->eps[phy_ep_num];

    ebm_reg_base_8 = in_user_ep_cnfg[/*BULK_IN_EP_NO*/dev_iebm_ep->usb_ep_no].ebm_reg_base_8;

    ebm_mem_base_8 = in_user_ep_cnfg[/*BULK_IN_EP_NO*/dev_iebm_ep->usb_ep_no].ebm_mem_base_8;

    reg_val = lsc_32_read(
            ebm_reg_base_8 + LSC_IEBM_BUF_AVAIL_INFO_REG);
//    LSC_IN_EP_BUF_MGMT("BUF_AVAIL_INFO_REG: %x\r\n", reg_val);

    no_of_buf_to_be_proc_fw = reg_val
            & LSC_IEBM_NUM_BUF_TO_BE_PROCESS_BY_FW_MASK;

    LSC_IN_EP_BUF_MGMT("no_of_buf_to_be_proc_fw: %x\r\n",
            no_of_buf_to_be_proc_fw);

    while (no_of_buf_to_be_proc_fw) {
        reg_val = lsc_32_read(
                ebm_reg_base_8 + LSC_IEBM_SEL_BUF_INFO_FW_REG);

        sel_buf_num = reg_val & LSC_IEBM_SEL_BUF_NUM_MASK;
        LSC_IN_EP_BUF_MGMT("sel_buf_num: %x\r\n", sel_buf_num);

        sel_buf_sz = LSC_IEBM_SEL_BUF_SZ(reg_val);
        LSC_IN_EP_BUF_MGMT("sel_buf_sz: %x\r\n", sel_buf_sz);

        buf_offset = ebm_mem_base_8 + (sel_buf_num * ep->ebm_bufr_span);
        LSC_IN_EP_BUF_MGMT("buf_offset: %x\r\n", buf_offset);

        ret = lsc_usb_ep_xfer_req(dev_iebm_ep->usb_dev, dev_iebm_ep->usb_ep_no, LSC_EP_DIR_IN,
                (uint8_t*)buf_offset, sel_buf_sz);

        if (ret) {
            // When the queue is full - This is not expected to happen.
            // If this happens this will cause IEBM IRQ to remain high.
            LSC_DISP_ERROR("BUG! Queue is full. Unable to queue transer request.\r\n");
            LSC_DISP_ERROR("Please ensure number of buffers available to IEBM is not greater than total TRBs available to EP.\r\n");
            break;
        } else {
            no_of_buf_to_be_proc_fw--;

            reg_val = lsc_32_read(
                    ebm_reg_base_8 + LSC_IEBM_XCHNGCTRL_REG);

            //Write fw processed one buffer to avail buffer to IP core
            reg_val |= LSC_IEBM_FW_PROCESSED_1_BUF_MASK;
            lsc_32_write((ebm_reg_base_8 + LSC_IEBM_XCHNGCTRL_REG),
                    reg_val);

            LSC_IN_EP_BUF_MGMT("fw processed one buffer\r\n");
        }
    }

}

/****************************************************************************/
/**
 * @brief This function is used to handle user application specific tasks
 * for a given USB device.
 *
 * @param usb_dev Pointer to the USB device structure.
 * @param usb_ep_num Endpoint number for the USB device.
 * @param ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 * @param xferred_bytes Number of bytes transferred.
 *
 * @return   None.
 *
 * @note     None.
 ****************************************************************************/
void lsc_iebm_xfer_completion_cb (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir, uint32_t xferred_bytes)
{
        LSC_IN_EP_BUF_MGMT("lsc_iebm_xfer_completion_cb\r\n");

        uint32_t ebm_reg_base_8;
        uint32_t reg_val = 0;

        ebm_reg_base_8 = in_user_ep_cnfg[usb_ep_num].ebm_reg_base_8;

        LSC_IN_EP_BUF_MGMT("usb_ep_num = %d \r\n",usb_ep_num);
        LSC_IN_EP_BUF_MGMT("ep_dir = %d \r\n",ep_dir);
        LSC_IN_EP_BUF_MGMT("xferred_bytes = %d \r\n",xferred_bytes);

        // Release the buffer
        // Read the exchange control register
        reg_val = lsc_32_read(
                ebm_reg_base_8 + LSC_IEBM_XCHNGCTRL_REG);

        // Write Hand over bit to avail buffer to IP core
        reg_val |= LSC_IEBM_BUF_HO_EXT_FIFO_MSTR_MASK;

        // Write the updated value back to the exchange control register
        lsc_32_write((ebm_reg_base_8 + LSC_IEBM_XCHNGCTRL_REG),
                reg_val);

        LSC_IN_EP_BUF_MGMT("Hand over one buf to IP\r\n");

}

/** @} */
