/****************************************************************************/
/**
 *
 * @file lsc_in_ep_buf_mgmt.h
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/

#ifndef LSC_IN_EP_BUF_MGMT_H_
#define LSC_IN_EP_BUF_MGMT_H_

#include <sys_platform.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LSC_IEBM_BUF_MGMT_IP_BASE        IEBM_INST_BASE_ADDR        /**< IEBM IP Base Address */
#define LSC_IEBM_BUF_MGMT_IRQ            IEBM_INST_IRQ              /**< IEBM IP IRQ Number */
#define LSC_IEBM_BUF_MEM_BASE            0x140000                   /**< IEBM IP Buffer Memory Address */
#define HW_ALLOC_BUF_DEPTH               IEBM_INST_IEBM_HW_SINGLE_BUFR_SIZE_I   /**< Hardware allocated buffer depth */

//IP Version Register
#define LSC_IEBM_IP_VER_REG             0x0     /**< IEBM IP Version Register Offset */

#define LSC_IEBM_IP_MAJOR_VER_MASK      0xFF000000
#define LSC_IEBM_IP_MINOR_VER_MASK      0xFF0000

//Scratch Register
#define LSC_IEBM_SCRATCH_REG            0x4     /**< IEBM IP Scratch Register Offset */

//Interrupt Enable Register
#define LSC_IEBM_INT_EN_REG             0x8     /**< IEBM IP Interrupt Enable Register Offset */

#define LSC_IEBM_BUF_AVAIL_TO_FW_INT_EN_MASK   0x1

//Interrupt Source Register
#define LSC_IEBM_INT_SRC_REG            0xC     /**< IEBM IP Interrupt Source Register Offset */

//Buffer Configuration Register
#define LSC_IEBM_BUF_CNF_REG            0x10    /**< IEBM IP Buffer Configuration Register Offset */

#define LSC_IEBM_FW_TOTAL_BUF            IEBM_INST_IEBM_HW_MAX_BUFRS_I  /**< Total number of buffer supported by IEBM */
#define LSC_IEBM_FW_TOTAL_BUF_MASK          0x1E0000
#define LSC_IEBM_FW_TOTAL_BUF_OFST          17

#define LSC_IEBM_TOTAL_FW_BUF(n)            (n & LSC_IEBM_FW_TOTAL_BUF_MASK) >> LSC_IEBM_FW_TOTAL_BUF_OFST

#define LSC_IEBM_FW_SINGLE_BUF_DEPTH       16384        /**< Single buffer depth provided by IEBM */
#define LSC_IEBM_FW_SINGLE_BUF_DEPTH_MASK   0x1FFFF

//Hardware Parameter Information Register
#define LSC_IEBM_HW_INFO_REG            0x14

#define LSC_IEBM_HW_MAX_BUF_MASK        0xF0000000
#define LSC_IEBM_HW_MAX_BUF(n)          (n & LSC_IEBM_HW_MAX_BUF_MASK) >> 28

#define LSC_IEBM_HW_SINGLE_BUF_MAX_DEPTH_MASK   0x7FFFC00
#define LSC_IEBM_HW_SINGLE_BUF_MAX_DEPTH(n)     (n & LSC_IEBM_HW_SINGLE_BUF_MAX_DEPTH_MASK) >> 10

#define LSC_IEBM_HW_FIFO_DATA_WIDTH_MASK        0xFF

//Control Register
#define LSC_IEBM_CTRL_REG            0x18       /**< IEBM IPControl Register Offset */

#define LSC_IEBM_FLUSH_BUF_MASK      0x2
#define LSC_IEBM_IP_CNF_MASK         0x1

//Buffer Tracker Information Register
#define LSC_IEBM_BUF_TRACKER_INFO_REG            0x1C   /**< IEBM Buffer Tracker Information Register Offset */

#define LSC_IEBM_EXT_FIFO_MSTR_BUF_TRACKER_MASK      0xF0
#define LSC_IEBM_EXT_FIFO_MSTR_BUF_TRACKER(n)        (n & LSC_IEBM_EXT_FIFO_MSTR_BUF_TRACKER_MASK) >> 4

#define LSC_IEBM_FW_BUF_TRACKER_MASK      0xF

//Buffer Availability Information Register
#define LSC_IEBM_BUF_AVAIL_INFO_REG            0x20     /**< Buffer Availability Information Register Offset */

#define LSC_IEBM_NUM_BUF_AVAIL_EXT_FIFO_MSTR_MASK      0xF0
#define LSC_IEBM_NUM_BUF_AVAIL_EXT_FIFO_MSTR(n)        (n & LSC_IEBM_NUM_BUF_AVAIL_EXT_FIFO_MSTR_MASK) >> 4

#define LSC_IEBM_NUM_BUF_TO_BE_PROCESS_BY_FW_MASK      0xF

//Buffer Exchange Control Register
#define LSC_IEBM_XCHNGCTRL_REG            0x24      /**< Buffer Exchange Control Register Offset */

#define LSC_IEBM_BUF_HO_EXT_FIFO_MSTR_MASK      0x2
#define LSC_IEBM_BUF_HO_EXT_FIFO_MSTR(n)        (n & LSC_IEBM_BUF_HO_EXT_FIFO_MSTR_MASK) >> 1

#define LSC_IEBM_FW_PROCESSED_1_BUF_MASK        0x1

//Selectd Buffer Information Register
#define LSC_IEBM_SEL_BUF_INFO_FW_REG            0x28    /**< Selectd Buffer Information Register Offset */

#define LSC_IEBM_SEL_BUF_SZ_MASK                0x1FFFF0
#define LSC_IEBM_SEL_BUF_SZ(n)                  (n & LSC_IEBM_SEL_BUF_SZ_MASK) >> 4

#define LSC_IEBM_SEL_BUF_NUM_MASK               0xF

//Debug Register
#define LSC_IEBM_DEBUG_REG            0x2C      /**< Debug Register Offset */


//Functions
//uint8_t lsc_iebm_buf_mgmt_init();
//uint8_t lsc_iebm_buf_isr_register (uint32_t usb_irq, void (*isr) (void*), void *context);
//void lsc_iebm_buf_int_handler (void *context);

#ifdef __cplusplus
}
#endif

#endif /* LSC_IN_EP_BUF_MGMT_H_ */

/** @} */
