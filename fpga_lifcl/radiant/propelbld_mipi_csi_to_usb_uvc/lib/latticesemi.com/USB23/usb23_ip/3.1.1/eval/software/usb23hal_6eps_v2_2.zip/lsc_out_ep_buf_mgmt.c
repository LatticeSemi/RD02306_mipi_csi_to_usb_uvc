/****************************************************************************/
/**
 *
 * @file lsc_out_ep_buf_mgmt.c
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/
#include "lsc_usb_dev.h"
#include "pic.h"

//#define DEBUG_LSC_OUT_EP_BUF_MGMT

#ifdef DEBUG_LSC_OUT_EP_BUF_MGMT
#define LSC_OUT_EP_BUF_MGMT(msg, ...) sprintf(print_buf, msg, ##__VA_ARGS__); lsc_uart_tx(print_buf)
#else
#define LSC_OUT_EP_BUF_MGMT(msg, ...)
#endif

extern const struct user_ep_cnfg  out_user_ep_cnfg[16];

struct lsc_dev_oebm_eps dev_oebm_eps[16];

/****************************************************************************/
/**
 * @brief
 * Configure/Re-Configure Out endpoint buffer mangement IP Core.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 *
 * @return   LSC_SUCCESS else LSC_FAIL.
 *
 * @note     None.
 ****************************************************************************/
uint8_t lsc_oebm_init (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir)
{
    LSC_OUT_EP_BUF_MGMT("lsc_oebm_init \r\n");

    uint32_t status;

    uint32_t reg_val = 0, fw_buf = 0, hw_max_buf = 0, data_width_bit = 0;
    uint32_t oebm_hw_buf_depth;
    uint32_t ebm_reg_base_8;
    uint32_t tmp;

    struct lsc_ep *ep;

    uint8_t phy_ep_num;

    if (ep_dir != LSC_EP_DIR_OUT) {
        LSC_DISP_ERROR("BUG! OEBM shall be used only for OUT endpoint. Kindly check configuration.\r\n");
        return LSC_FAIL;
    }

    dev_oebm_eps[usb_ep_num].usb_dev = usb_dev;
    dev_oebm_eps[usb_ep_num].usb_ep_no = usb_ep_num;

    // Find Physical Endpoint number
    phy_ep_num = lsc_physicalep(usb_ep_num, LSC_EP_DIR_OUT);

    // Get endpoint structure
    ep = &usb_dev->eps[phy_ep_num];

    ebm_reg_base_8 = out_user_ep_cnfg[usb_ep_num].ebm_reg_base_8;

    // IP Version
    // Future scope: Add condition to check whether IP version matches
    // with expected number or not. If it doesn't, we shall return from here.
    reg_val = lsc_32_read(ebm_reg_base_8 + LSC_OEBM_IP_VER_REG);
    LSC_OUT_EP_BUF_MGMT("IP_VER_REG: %x\r\n", reg_val);

    // Get Hardware configured parameter information
    reg_val = lsc_32_read(ebm_reg_base_8 + LSC_OEBM_HW_INFO_REG);

    hw_max_buf = LSC_OEBM_HW_MAX_BUF(reg_val);
    LSC_OUT_EP_BUF_MGMT("hw_max_buf: %d\r\n", hw_max_buf);

    oebm_hw_buf_depth = LSC_OEBM_HW_SINGLE_BUF_MAX_DEPTH(reg_val);
    LSC_OUT_EP_BUF_MGMT("oebm_hw_buf_depth: 0x%x\r\n", oebm_hw_buf_depth);

    tmp = oebm_hw_buf_depth;

    // Find out OEBM buffer span.
    // Please refer OEBM user-guide.
    while(tmp > 0)
    {
        data_width_bit++;
        tmp >>= 1;
        LSC_OUT_EP_BUF_MGMT("data_width_bit: %x\r\n", data_width_bit);
    }

    ep->ebm_bufr_span = (1 << (data_width_bit-1));

    if ( ep->ebm_bufr_span < oebm_hw_buf_depth ) {
        ep->ebm_bufr_span = (ep->ebm_bufr_span << 1);
    }

    LSC_OUT_EP_BUF_MGMT("ep->ebm_bufr_span: 0x%x\r\n", ep->ebm_bufr_span);

    //Disable Interrupt
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_INT_EN_REG),
            ~LSC_OEBM_HO_BUF_TO_FW_INT_EN_MASK);

    //Reset configured bit in CTRL register
    reg_val = lsc_32_read((ebm_reg_base_8 + LSC_OEBM_CTRL_REG));
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_CTRL_REG),
            (reg_val & (~LSC_OEBM_IP_CNF_MASK)));

    LSC_OUT_EP_BUF_MGMT("ebm_fw_total_bufrs: %x and ep = %d\r\n", out_user_ep_cnfg[usb_ep_num].ebm_fw_total_bufrs, usb_ep_num);
    // Load buffer configuration register
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_BUF_CNF_REG),
            (((out_user_ep_cnfg[usb_ep_num].ebm_fw_total_bufrs) << LSC_OEBM_FW_TOTAL_BUF_OFST)));

    reg_val = lsc_32_read(ebm_reg_base_8 + LSC_OEBM_BUF_CNF_REG);
    LSC_OUT_EP_BUF_MGMT("BUF_CNF_REG: 0x%x\r\n", reg_val);

    fw_buf = LSC_OEBM_TOTAL_FW_BUF(reg_val);
    LSC_OUT_EP_BUF_MGMT("fw_buf: %d\r\n", fw_buf);

    if (fw_buf > hw_max_buf) {
        LSC_DISP_ERROR("BUG! FW allocated more buffers than available in HW.\r\n");
        return LSC_FAIL;
    } else if (fw_buf < hw_max_buf){
        LSC_DISP_WARNING("FW buffers = %d while HW buffers = %d\r\n",fw_buf,hw_max_buf);
        LSC_DISP_WARNING("Warning. FW is not fully utilizing hardware allocted resources. This could degrade performance.\r\n");
    }

    // Let's check whether firmware allocated depth is within range or not.
    LSC_OUT_EP_BUF_MGMT("ebm_fw_single_bufr_depth: %x\r\n", out_user_ep_cnfg[usb_ep_num].ebm_fw_single_bufr_depth);

    if (out_user_ep_cnfg[usb_ep_num].ebm_fw_single_bufr_depth > oebm_hw_buf_depth) {
        LSC_DISP_ERROR("FW buffer depth is more than HW buffer depth\r\n");
        LSC_DISP_ERROR("FW buffer depth = while HW buffer depth = %d.\r\n",out_user_ep_cnfg[usb_ep_num].ebm_fw_single_bufr_depth, oebm_hw_buf_depth);
        return LSC_FAIL;
    }

    // Also, let's check whether user has allocated enough hardware buffer or not.
    // It must be greater than or equal to minimum buffer span required for this endpoint.
    if (ep->min_bufr_span > oebm_hw_buf_depth) {
        LSC_DISP_ERROR("Hardware buffer depth is not enough for this endpoint.\r\n");
        LSC_DISP_ERROR("Minimum buffer span required: %d while hardware allocated depth = %d.\r\n",ep->min_bufr_span, oebm_hw_buf_depth);
        return LSC_FAIL;
    }

    // Let's find out size for which single TRB shall be configured.
    // For periodic endpoint, TRB will be configured for bytes which can be transferred
    // in single service interval.
    // For other endpoints, we will try to configure it to maximum number of packets which
    // can be accommodated in single buffer allocated by user.
    if (
        (ep->ep_type == LSC_ENDPOINT_XFER_ISOC) ||
        (ep->ep_type == LSC_ENDPOINT_XFER_INT)
    ) {
        ep->trb_xfer_req_size = ep->min_bufr_span;
    } else {

        LSC_OUT_EP_BUF_MGMT("ebm_fw_single_bufr_depth =%d \r\n",out_user_ep_cnfg[usb_ep_num].ebm_fw_single_bufr_depth);
        LSC_OUT_EP_BUF_MGMT("ep->min_bufr_span =%d \r\n",ep->min_bufr_span);

        // Following logic finds maximum number of packets which can be
        // requested in single TRB. Each packet will be of maximum packet size.
        tmp = ep->min_bufr_span;
        while ( out_user_ep_cnfg[usb_ep_num].ebm_fw_single_bufr_depth > tmp  ) {
            LSC_OUT_EP_BUF_MGMT("tmp =%d \r\n",tmp);
            tmp = tmp + ep->min_bufr_span;
        }
        LSC_OUT_EP_BUF_MGMT("tmp =%d \r\n",tmp);
        // At this time, tmp value will be greater than single buffer depth.
        // So, let's subtract
        if  ( out_user_ep_cnfg[usb_ep_num].ebm_fw_single_bufr_depth > tmp  ) {
        ep->trb_xfer_req_size = tmp - ep->min_bufr_span;
        } else {
        ep->trb_xfer_req_size = tmp;
        }
    }

    LSC_OUT_EP_BUF_MGMT("TRB transfer request size = %d \r\n",ep->trb_xfer_req_size);

    // USB Buffer tracker. This points to next buffer which shall be
    // handed over to USB.
    ep->ebm_usb_bufr_tracker = 0;

    // IP Buffer tracker. This points to next buffer which shall be
    // handed over to IP (user).
    ep->ebm_ip_bufr_tracker = 0;

    //Set flush buffer bit in CTRL register
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_CTRL_REG),
            LSC_OEBM_FLUSH_BUF_MASK);

    //Wait until flush buffer bit is cleared
    while (lsc_32_read(ebm_reg_base_8 + LSC_OEBM_CTRL_REG)
            & LSC_OEBM_FLUSH_BUF_MASK)
        ;

    // Register ISR
    status = pic_isr_register(out_user_ep_cnfg[usb_ep_num].ebm_irq, lsc_oebm_buf_int_handler, &dev_oebm_eps[usb_ep_num]);

    if (status != LSC_SUCCESS)
    {
        printf("OEBM ISR Fail.");
//        lsc_uart_tx(print_buf);

        return LSC_FAIL;
    }

    // EBM initialization is done.
    ep->ebm_init_done = true;

    return LSC_SUCCESS;

}

/****************************************************************************/
/**
 * @brief
 * Initiates OEBM transfer requets.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 *
 * @return   LSC_SUCCESS else LSC_FAIL.
 *
 * @note     None.
 ****************************************************************************/
uint8_t lsc_oebm_enable (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir)
{
    LSC_OUT_EP_BUF_MGMT("lsc_oebm_enable, usb_ep -%d \r\n", usb_ep_num);

    uint32_t reg_val;
    uint32_t ret;
    uint8_t no_of_buf_to_be_accept_fw;
    uint32_t ebm_reg_base_8;
    uint32_t ebm_mem_base_8;

    struct lsc_ep *ep;

    uint8_t phy_ep_num;

    phy_ep_num = lsc_physicalep(usb_ep_num, LSC_EP_DIR_OUT);

    ep = &usb_dev->eps[phy_ep_num];

    ebm_reg_base_8 = out_user_ep_cnfg[usb_ep_num].ebm_reg_base_8;

    ebm_mem_base_8 = out_user_ep_cnfg[usb_ep_num].ebm_mem_base_8;

    //Disable Interrupt
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_INT_EN_REG),
            ~LSC_OEBM_HO_BUF_TO_FW_INT_EN_MASK);

    //Reset configured bit in CTRL register
    reg_val = lsc_32_read((ebm_reg_base_8 + LSC_OEBM_CTRL_REG));
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_CTRL_REG),
            (reg_val & (~LSC_OEBM_IP_CNF_MASK)));

    // USB Buffer tracker. This points to next buffer which shall be
    // handed over to USB.
    ep->ebm_usb_bufr_tracker = 0;

    // IP Buffer tracker. This points to next buffer which shall be
    // handed over to IP (user).
    ep->ebm_ip_bufr_tracker = 0;

    // Reinitialize following variables upon enable
    ep->trb_free_slot = out_user_ep_cnfg[usb_ep_num].ep_trb_slots;
    ep->max_no_of_ep_xfer_req = out_user_ep_cnfg[usb_ep_num].ep_req_queue_size;

    //Set flush buffer bit in CTRL register
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_CTRL_REG),
            LSC_OEBM_FLUSH_BUF_MASK);

    //Wait until flush buffer bit is cleared
    while (lsc_32_read(ebm_reg_base_8 + LSC_OEBM_CTRL_REG)
            & LSC_OEBM_FLUSH_BUF_MASK)
        ;

    // Initially all buffers will be available to firmware. Hence, we can submit
    // requests to USB controller.
    no_of_buf_to_be_accept_fw = out_user_ep_cnfg[usb_ep_num].ebm_fw_total_bufrs;

    LSC_OUT_EP_BUF_MGMT("no_of_buf_to_be_accept_fw: %x\r\n",
            no_of_buf_to_be_accept_fw);

    while (no_of_buf_to_be_accept_fw) {

        uint32_t buf_offset = ebm_mem_base_8 + (ep->ebm_usb_bufr_tracker * ep->ebm_bufr_span);

        LSC_OUT_EP_BUF_MGMT("buf_offset: %x\r\n", buf_offset);
        LSC_OUT_EP_BUF_MGMT("ep->ebm_usb_bufr_tracker: 0x%x\r\n", ep->ebm_usb_bufr_tracker);

        //printf("ep->ebm_usb_bufr_tracker: %x\r\n", ep->ebm_usb_bufr_tracker);
        ret = lsc_usb_ep_xfer_req(usb_dev, BULK_OUT_EP_NO, LSC_EP_DIR_OUT,
                        (uint8_t*)buf_offset, ep->trb_xfer_req_size);


        if (ret) {
            // When the queue is full - This is not expected to happen.
            // If this happens this will cause OEBM IRQ to remain high.
            LSC_DISP_ERROR("BUG! Queue is full!\r\n");
            LSC_DISP_ERROR("Please ensure number of buffers available to OEBM is not greater than total TRBs available to EP.\r\n");
            break;
        } else {

            // Decrement number of buffers to be accepted by firmware
            no_of_buf_to_be_accept_fw--;

            // Increment OEBM buffer index
            ep->ebm_usb_bufr_tracker++;

            // Rollover to 0 if it has reached upper limit.
            if(ep->ebm_usb_bufr_tracker == LSC_OEBM_FW_TOTAL_BUF) {
              ep->ebm_usb_bufr_tracker = 0;
            }
        }

    }

    //Enable Interrupt
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_INT_EN_REG),
            LSC_OEBM_HO_BUF_TO_FW_INT_EN_MASK);

    //Set configured bit in CTRL register
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_CTRL_REG), LSC_OEBM_IP_CNF_MASK);

    return LSC_SUCCESS;

}

/****************************************************************************/
/**
 * @brief
 * Disables/Flush OEBM tansfer request queuing.
 *
 * @param    usb_dev is a pointer to the lsc_usb_dev instance.
 * @param    usb_ep_num is USB endpoint number.
 * @param    ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 *
 * @return   LSC_SUCCESS else LSC_FAIL.
 *
 * @note     None.
 ****************************************************************************/
uint8_t lsc_oebm_disable (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir)
{

    LSC_OUT_EP_BUF_MGMT("lsc_oebm_disable, usb_ep -%d \r\n", usb_ep_num);

    uint32_t status, reg_val;
    uint32_t ebm_reg_base_8;

    struct lsc_ep *ep;

    uint8_t phy_ep_num;

    phy_ep_num = lsc_physicalep(usb_ep_num, LSC_EP_DIR_OUT);

    ep = &usb_dev->eps[phy_ep_num];

    ebm_reg_base_8 = out_user_ep_cnfg[usb_ep_num].ebm_reg_base_8;

    //Disable Interrupt
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_INT_EN_REG),
            ~LSC_OEBM_HO_BUF_TO_FW_INT_EN_MASK);

    //Reset configured bit in CTRL register
    reg_val = lsc_32_read((ebm_reg_base_8 + LSC_OEBM_CTRL_REG));
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_CTRL_REG),
            (reg_val & (~LSC_OEBM_IP_CNF_MASK)));

    // USB Buffer tracker. This points to next buffer which shall be
    // handed over to USB.
    ep->ebm_usb_bufr_tracker = 0;

    // IP Buffer tracker. This points to next buffer which shall be
    // handed over to IP (user).
    ep->ebm_ip_bufr_tracker = 0;

    //Set flush buffer bit in CTRL register
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_CTRL_REG),
            LSC_OEBM_FLUSH_BUF_MASK);

    //Wait until flush buffer bit is cleared
    while (lsc_32_read(ebm_reg_base_8 + LSC_OEBM_CTRL_REG)
            & LSC_OEBM_FLUSH_BUF_MASK)
        ;

    return LSC_SUCCESS;

}

/****************************************************************************/
/**
 * @brief
 * LSC_OEBM Buffer Management Interrupt Handler.
 *
 * @param    context is a pointer to the lsc_usb_dev instance.
 *
 * @return   None.
 *
 * @note     None.
 *****************************************************************************/
void lsc_oebm_buf_int_handler (void *context)
{
    LSC_OUT_EP_BUF_MGMT("lsc_oebm_buf_int_handler \r\n");

    struct lsc_dev_oebm_eps *dev_oebm_ep = (struct lsc_dev_oebm_eps *)context;
    struct lsc_ep *ep;

    uint32_t reg_val = 0, sel_buf_sz = 0, buf_offset = 0, *ptr = NULL;
    uint8_t no_of_buf_to_be_accept_fw = 0, sel_buf_num = 0, ret = 0;
    uint8_t phy_ep_num = 0;
    uint32_t ebm_reg_base_8;
    uint32_t ebm_mem_base_8;

    // Future Scope:
    // At the moment, following is fixed for single Bulk endpoint.
    // We should see how we can support multiple endpoints.
    phy_ep_num = lsc_physicalep(/*BULK_OUT_EP_NO*/dev_oebm_ep->usb_ep_no, LSC_EP_DIR_OUT);
//    ep = &usb_dev->eps[phy_ep_num];
    ep = &dev_oebm_ep->usb_dev->eps[phy_ep_num];

    ebm_reg_base_8 = out_user_ep_cnfg[/*BULK_OUT_EP_NO*/dev_oebm_ep->usb_ep_no].ebm_reg_base_8;

    ebm_mem_base_8 = out_user_ep_cnfg[/*BULK_OUT_EP_NO*/dev_oebm_ep->usb_ep_no].ebm_mem_base_8;

    reg_val = lsc_32_read(
            ebm_reg_base_8 + LSC_OEBM_BUF_AVAIL_INFO_REG);
    LSC_OUT_EP_BUF_MGMT("BUF_AVAIL_INFO_REG: %x\r\n", reg_val);
//
    no_of_buf_to_be_accept_fw = reg_val
            & LSC_OEBM_NUM_BUF_ACCEPTED_BY_FW_MASK;
//
    LSC_OUT_EP_BUF_MGMT("no_of_buf_to_be_accept_fw: %x\r\n",
            no_of_buf_to_be_accept_fw);

    while (no_of_buf_to_be_accept_fw) {

        uint32_t buf_offset = ebm_mem_base_8 + (ep->ebm_usb_bufr_tracker * ep->ebm_bufr_span);

        LSC_OUT_EP_BUF_MGMT("ep->ebm_usb_bufr_tracker: 0x%x\r\n", ep->ebm_usb_bufr_tracker);
        LSC_OUT_EP_BUF_MGMT("ep->ebm_bufr_span : 0x%x\r\n", ep->ebm_bufr_span);
        LSC_OUT_EP_BUF_MGMT("buf_offset : 0x%x\r\n", buf_offset);

        ret = lsc_usb_ep_xfer_req(/*usb_dev*/dev_oebm_ep->usb_dev, /*BULK_OUT_EP_NO*/dev_oebm_ep->usb_ep_no, LSC_EP_DIR_OUT,
                        (uint8_t*)buf_offset, ep->trb_xfer_req_size);

        if (ret) {
            // When the queue is full - This is not expected to happen.
            // If this happens this will cause OEBM IRQ to remain high.
            LSC_DISP_ERROR("BUG! Queue is full!\r\n");
            LSC_DISP_ERROR("Please ensure number of buffers available to OEBM is not greater than total TRBs available to EP.\r\n");
            break;
        } else {

            // Decrement number of buffers to be accepted by firmware
            no_of_buf_to_be_accept_fw--;

            // Increment OEBM buffer index
            ep->ebm_usb_bufr_tracker++;

            // Rollover to 0 if it has reached upper limit.
            if(ep->ebm_usb_bufr_tracker == LSC_OEBM_FW_TOTAL_BUF) {
              ep->ebm_usb_bufr_tracker = 0;
            }

            // Read OEBM buffer exchange control register
            reg_val = lsc_32_read(
                    ebm_reg_base_8 + LSC_OEBM_XCHNGCTRL_REG);

            //Write fw accepted one buffer.
            reg_val |= LSC_OEBM_FW_ACCEPTED_1_BUF_MASK;
            lsc_32_write((ebm_reg_base_8 + LSC_OEBM_XCHNGCTRL_REG),
                    reg_val);

            LSC_OUT_EP_BUF_MGMT("fw accepted one buffer\r\n");
        }
    }

    // FIX_ME: Do we really need following?
    // if (ep->handler != NULL) {
    //    ep->handler(usb_dev, BULK_OUT_EP_NO, ep->max_ep_size);
    // }

}

/****************************************************************************/
/**
 * @brief This function is used to handle OEBM configuration when USB controller
 * indicates transfer is completed.
 *
 * @param usb_dev Pointer to the USB device structure.
 * @param usb_ep_num Endpoint number for the USB device.
 * @param ep_dir is direction of endpoint
 *               - LSC_EP_DIR_IN/LSC_EP_DIR_OUT
 * @param xferred_bytes Number of bytes transferred.
 *
 * @return   None.
 *
 * @note     None.
 ****************************************************************************/

void lsc_oebm_xfer_completion_cb (struct lsc_usb_dev *usb_dev,
       uint8_t usb_ep_num, uint8_t ep_dir, uint32_t xferred_bytes)
{
    LSC_OUT_EP_BUF_MGMT("oebm_xfer_completion_cb\r\n");

    uint32_t ebm_reg_base_8;

    // Declare endpoint and physical endpoint number variables
    struct lsc_ep *ep;
    uint8_t phy_ep_num;

    // Get the physical endpoint number
    phy_ep_num = lsc_physicalep(usb_ep_num, ep_dir);

    // Get the endpoint from the USB device
    ep = &usb_dev->eps[phy_ep_num];

    ebm_reg_base_8 = out_user_ep_cnfg[usb_ep_num].ebm_reg_base_8;

    LSC_OUT_EP_BUF_MGMT("usb_ep_num = %d \r\n",usb_ep_num);
    LSC_OUT_EP_BUF_MGMT("ep_dir = %d \r\n",ep_dir);
    LSC_OUT_EP_BUF_MGMT("xferred_bytes = %d \r\n",xferred_bytes);
    LSC_OUT_EP_BUF_MGMT("ebm_ip_bufr_tracker = %d \r\n",ep->ebm_ip_bufr_tracker);
    LSC_OUT_EP_BUF_MGMT("ebm_usb_bufr_tracker = %d \r\n",ep->ebm_usb_bufr_tracker);

    // Display number of bytes transferred for debugging purpose.
    //printf("%d \r\n",xferred_bytes);

    //Write Bulk OUT transfred bytes into size data ram register
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_SIZE_RAM_DATA_REG),
            ((xferred_bytes << LSC_OEBM_SIZE_RAM_BUF_SZ_OFST) | (ep->ebm_ip_bufr_tracker << LSC_OEBM_SIZE_RAM_BUF_NUM_OFST)));

    // printf("SIZE_RAM_DATA_REG: %x\r\n", lsc_32_read(ebm_reg_base_8 + LSC_OEBM_SIZE_RAM_DATA_REG));

    //Hand Over buffer to fifo interface
    lsc_32_write((ebm_reg_base_8 + LSC_OEBM_XCHNGCTRL_REG),
            LSC_OEBM_BUF_HO_EXT_FIFO_MSTR_MASK);

    // printf("OEBM_XCHNGCTRL_REG: %x\r\n", lsc_32_read(ebm_reg_base_8 + LSC_OEBM_XCHNGCTRL_REG));

    ep->ebm_ip_bufr_tracker++;

    // Rollover to 0 if it has reached upper limit.
    if(ep->ebm_ip_bufr_tracker == LSC_OEBM_FW_TOTAL_BUF) {
          ep->ebm_ip_bufr_tracker = 0;
      }

    LSC_OUT_EP_BUF_MGMT("Hand over one buf to IP\r\n");

}

/** @} */
