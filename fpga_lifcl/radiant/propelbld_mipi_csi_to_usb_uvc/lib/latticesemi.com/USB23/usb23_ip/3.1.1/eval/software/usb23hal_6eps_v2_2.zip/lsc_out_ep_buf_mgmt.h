/****************************************************************************/
/**
 *
 * @file lsc_out_ep_buf_mgmt.h
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/

#ifndef LSC_OUT_EP_BUF_MGMT_H_
#define LSC_OUT_EP_BUF_MGMT_H_

#include <sys_platform.h>

#ifdef __cplusplus
extern "C" {
#endif


#define LSC_OEBM_BUF_MGMT_IP_BASE        OEBM_INST_BASE_ADDR
#define LSC_OEBM_BUF_MGMT_IRQ            OEBM_INST_IRQ
#define LSC_OEBM_BUF_MEM_BASE            0x180000
#define LSC_OEBM_HW_ALLOC_BUF_DEPTH      OEBM_INST_HW_SINGLE_BUFR_SIZE_I

#define LSC_OEBM_FW_ALLOC_BUF_DEPTH      OEBM_INST_HW_SINGLE_BUFR_SIZE_I

//IP Version Register
#define LSC_OEBM_IP_VER_REG             0x0

#define LSC_OEBM_IP_MAJOR_VER_MASK      0xFF000000
#define LSC_OEBM_IP_MINOR_VER_MASK      0xFF0000

//Scratch Register
#define LSC_OEBM_SCRATCH_REG            0x4

//Interrupt Enable Register
#define LSC_OEBM_INT_EN_REG             0x8

#define LSC_OEBM_HO_BUF_TO_FW_INT_EN_MASK   0x1

//Interrupt Source Register
#define LSC_OEBM_INT_SRC_REG            0xC

//Buffer Configuration Register
#define LSC_OEBM_BUF_CNF_REG            0x10

#define LSC_OEBM_FW_TOTAL_BUF            OEBM_INST_HW_MAX_BUFRS_I
#define LSC_OEBM_FW_TOTAL_BUF_MASK          0x1f
#define LSC_OEBM_FW_TOTAL_BUF_OFST          0

#define LSC_OEBM_TOTAL_FW_BUF(n)            (n & LSC_OEBM_FW_TOTAL_BUF_MASK) >> LSC_OEBM_FW_TOTAL_BUF_OFST

//#define LSC_OEBM_FW_SINGLE_BUF_DEPTH       4096
//#define LSC_OEBM_FW_SINGLE_BUF_DEPTH_MASK   0x1FFFF

//Hardware Parameter Information Register
#define LSC_OEBM_HW_INFO_REG            0x14

#define LSC_OEBM_HW_MAX_BUF_MASK        0xF8000000
#define LSC_OEBM_HW_MAX_BUF(n)          (n & LSC_OEBM_HW_MAX_BUF_MASK) >> 27

#define LSC_OEBM_HW_SINGLE_BUF_MAX_DEPTH_MASK   0x7FFFC00
#define LSC_OEBM_HW_SINGLE_BUF_MAX_DEPTH(n)     (n & LSC_OEBM_HW_SINGLE_BUF_MAX_DEPTH_MASK) >> 10

#define LSC_OEBM_HW_FIFO_DATA_WIDTH_MASK        0xFF

//Control Register
#define LSC_OEBM_CTRL_REG            0x18

#define LSC_OEBM_FLUSH_BUF_MASK      0x2
#define LSC_OEBM_IP_CNF_MASK         0x1

////Buffer Tracker Information Register
//#define LSC_OEBM_BUF_TRACKER_INFO_REG            0x1C
//
//#define LSC_OEBM_EXT_FIFO_MSTR_BUF_TRACKER_MASK      0xF0
//#define LSC_OEBM_EXT_FIFO_MSTR_BUF_TRACKER(n)        (n & LSC_OEBM_EXT_FIFO_MSTR_BUF_TRACKER_MASK) >> 4
//
//#define LSC_OEBM_FW_BUF_TRACKER_MASK      0xF

//Buffer Availability Information Register
#define LSC_OEBM_BUF_AVAIL_INFO_REG            0x20

#define LSC_OEBM_NUM_BUF_ACCEPTED_BY_FW_MASK      0x1F
//#define LSC_OEBM_NUM_BUF_AVAIL_EXT_FIFO_MSTR(n)        (n & LSC_OEBM_NUM_BUF_AVAIL_EXT_FIFO_MSTR_MASK) >> 4

#define LSC_OEBM_FREE_BUF_TO_BE_PROCESS_BY_FW_MASK      0xF

//Buffer Exchange Control Register
#define LSC_OEBM_XCHNGCTRL_REG            0x24

#define LSC_OEBM_BUF_HO_EXT_FIFO_MSTR_MASK      0x2
#define LSC_OEBM_BUF_HO_EXT_FIFO_MSTR(n)        (n & LSC_OEBM_BUF_HO_EXT_FIFO_MSTR_MASK) >> 1

#define LSC_OEBM_FW_ACCEPTED_1_BUF_MASK        0x1

//Selectd Buffer Information Register
#define LSC_OEBM_SIZE_RAM_DATA_REG            0x28

#define LSC_OEBM_SIZE_RAM_BUF_SZ_MASK                0x1FFFF0
#define LSC_OEBM_SIZE_RAM_BUF_SZ_OFST                4
#define LSC_OEBM_SIZE_RAM_BUF_SZ(n)                  (n & LSC_OEBM_SIZE_RAM_BUF_SZ_MASK) >> 4
#define LSC_OEBM_SEL_SIZE_RAM_BUF_NUM_MASK               0xF
#define LSC_OEBM_SIZE_RAM_BUF_NUM_OFST                0

////Debug Register
//#define LSC_OEBM_DEBUG_REG            0x2C


//Functions
//uint8_t lsc_oebm_init (struct lsc_usb_dev *usb_dev,
//       uint8_t usb_ep_num);
//uint8_t lsc_oebm_enable (struct lsc_usb_dev *usb_dev,
//       uint8_t usb_ep_num);
//uint8_t lsc_oebm_disable (struct lsc_usb_dev *usb_dev,
//       uint8_t usb_ep_num);
//void lsc_oebm_buf_int_handler (void *context);
//void lsc_oebm_xfer_completion_cb (struct lsc_usb_dev *usb_dev,
//       uint8_t usb_ep_num, uint8_t dir, uint32_t xferred_bytes);

//void lsc_usb_user_application_spec (struct lsc_usb_dev *usb_dev, uint8_t usb_ep_num, uint8_t dir);

#ifdef __cplusplus
}
#endif

#endif /* LSC_OUT_EP_BUF_MGMT_H_ */

/** @} */
