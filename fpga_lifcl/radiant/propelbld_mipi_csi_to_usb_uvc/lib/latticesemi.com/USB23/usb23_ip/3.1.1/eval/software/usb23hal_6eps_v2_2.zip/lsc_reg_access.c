/****************************************************************************/
/**
 *
 * @file lsc_reg_access.c
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/

#include<sys/_stdint.h>
#include "lsc_usb_dev.h"
#include<stdio.h>
#include<uart.h>
#include <timer.h>
#include "reg_access.h"

char timestamp[50];
extern struct uart_instance uart_core_uart;

/**
 *  @fn uint8_t lsc_8_read (uint32_t reg_addr)
 *  @brief This function reads 1 byte of data from memory.
 *  @param reg_addr Address from which data to be read
 *
 *  @return Returns 8-bit data on success.
 *
 */
uint8_t lsc_8_read (uint32_t reg_addr)
{
    uint8_t reg_8b_value = 0;
    reg_8b_read(reg_addr, &reg_8b_value);

    return reg_8b_value;
}

/**
 *  @fn uint8_t lsc_8_write (uint32_t reg_addr, uint8_t value)
 *  @brief This function writes 1 byte of data to memory.
 *  @param reg_addr Address to which data to be write
 *  @param value Data to write into memory
 *
 *  @return Returns 0 on success.
 *
 */
uint8_t lsc_8_write (uint32_t reg_addr, uint8_t value)
{
    reg_8b_write(reg_addr, value);

    return 0;
}

/**
 *  @fn uint8_t lsc_16_read (uint32_t reg_addr)
 *  @brief This function reads 2 byte of data from memory.
 *  @param reg_addr Address from which data to be read
 *
 *  @return Returns 16-bit data on success.
 *
 */
uint16_t lsc_16_read (uint32_t reg_addr)
{
    unsigned short reg_16b_value = 0;
    reg_16b_read(reg_addr, &reg_16b_value);

    return reg_16b_value;
}

/**
 *  @fn uint8_t lsc_16_write (uint32_t reg_addr, unsigned short value)
 *  @brief This function writes 2 byte of data to memory.
 *  @param reg_addr Address to which data to be write
 *  @param value Data to write into memory
 *
 *  @return Returns 0 on success.
 *
 */
uint8_t lsc_16_write (uint32_t reg_addr, unsigned short value)
{
    reg_16b_write(reg_addr, value);

    return 0;
}

/**
 *  @fn uint8_t lsc_32_read (uint32_t reg_addr)
 *  @brief This function reads 4 byte of data from memory.
 *  @param reg_addr Address from which data to be read
 *
 *  @return Returns 32-bit data on success.
 *
 */
uint32_t lsc_32_read (uint32_t reg_addr)
{
    uint32_t reg_32b_value = 0;
    reg_32b_read(reg_addr, &reg_32b_value);

    return reg_32b_value;
}

/**
 *  @fn uint8_t lsc_32_write (uint32_t reg_addr, uint32_t value)
 *  @brief This function writes 4 byte of data to memory.
 *  @param reg_addr Address to which data to be write
 *  @param value Data to write into memory
 *
 *  @return Returns 0 on success.
 *
 */
uint8_t lsc_32_write (uint32_t reg_addr, uint32_t value)
{
    reg_32b_write(reg_addr, value);

    return 0;
}

void mtime_init(void)
{
    // mtime_low offset should be set to 1.
    reg_32b_write((CPU0_INST_PICTIMER_START_ADDR+TIMER_MTIME_LOW), 0x01);
    reg_32b_write((CPU0_INST_PICTIMER_START_ADDR+TIMER_MTIME_HIGH), 0x00);
}

uint64_t get_mtime(void)
{
    volatile uint32_t *mtimel = (volatile uint32_t *) ( CPU0_INST_PICTIMER_START_ADDR + TIMER_MTIME_LOW);
    volatile uint32_t *mtimeh = (volatile uint32_t *) ( CPU0_INST_PICTIMER_START_ADDR + TIMER_MTIME_HIGH);
//    printf("mtimeh: %d mtimel: %d\r\n", *mtimeh, *mtimel);
    uint32_t mtimeh_val;
    uint32_t mtimel_val;
    uint64_t ret;
    // the loop takes care of the unfortunate case in which mtimeh is increased
    // and mtimel loops around while we're reading the mtimeh value. That would
    // have us return a wrong value, but now it's fixed <3
    do
    {
        mtimeh_val = *mtimeh;
        mtimel_val = *mtimel;
    }
    while( mtimeh_val != *mtimeh );
//    printf("mtimeh: %d mtimel: %d\r\n", *mtimeh, *mtimel);
//    printf("mtimeh_val: %d mtimel_val: %d\r\n", mtimeh_val, mtimel_val);
    ret = (uint64_t) ( ( ( (uint64_t) mtimeh_val ) << 32 ) | mtimel_val );
//    printf("ret: %lld\r\n", ret);
//    printf("ret: %"PRIx64"\r\n", ret);
    return ret;
}

uint64_t GetElapsedMs(void)
{
    uint64_t elapsed;

    elapsed = get_mtime();
//    printf("elapsed: %lld\r\n", elapsed);
//    printf("elapsed: %"PRIx64"\r\n", elapsed);
    return (elapsed / SYSCLK_KHZ);
}

int lsc_uart_print (char *c)
{
#ifdef LSCC_STDIO_UART_APB
    int ret = EOF;
    while (*c != '\0') {
        ret = uart_putc(&uart_core_uart, *c++);
    }
    return ret;
#else
        return EOF;
    #endif
}

void lsc_uart_tx (char *c)
{
    uint64_t timems = GetElapsedMs();
    memset(timestamp, 0x00, 50);
    sprintf(timestamp,"%lld: ", timems);
    lsc_uart_print(timestamp);

    lsc_uart_print(c);
}

/** @} */
