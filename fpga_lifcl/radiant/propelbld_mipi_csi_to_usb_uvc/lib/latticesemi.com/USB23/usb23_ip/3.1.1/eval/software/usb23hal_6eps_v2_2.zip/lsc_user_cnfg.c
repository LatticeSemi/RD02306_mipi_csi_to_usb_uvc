/****************************************************************************/
/**
 *
 * @file lsc_user_cnfg.c
 *
 * This file faciliates user configuration.
 *
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/

/***************************** Include Files ********************************/

#include "lsc_usb_dev.h"

/************************** Constant Definitions ****************************/

// This follows Doxygen based comments.

// ---------------------------------------------------------------------
// Data buffers


// At present, we are using common buffer for Isochronous and Interrupt endpoints.
// Kindly note that this is used for endpoints which are not using FIFO based EBM (such as
// IEBM or OEBM). Endpoints having FIFO based EBM are using different memory buffers.
// Future scope: We can use separate buffers for both based on memory availability.

// Firmware for OUT endpoints (Isochronous OUT and Interrupt OUT as of now).
uint8_t fw_out_ep_bufr[LSC_OUT_EP_TOTAL_BUFR_DEPTH] __attribute__ ((aligned(4))) __attribute__((section(".myBufSection")));

// Firmware for IN endpoints (Isochronous IN and Interrupt IN as of now).
uint8_t fw_in_ep_bufr[LSC_IN_EP_TOTAL_BUFR_DEPTH] __attribute__ ((aligned(4))) __attribute__((section(".myBufSection")));

// ---------------------------------------------------------------------
// Note:
// To get better idea about various members of user_ep_cnfg structure,
// please visit comments section in its declaration. Thank you.

// ---------------------------------------------------------------------
// User configuration for unused endpoint or endpoint which
// does not require user configuration.
const struct user_ep_cnfg unused_ep_cnfg = {
          .fifo_based_ebm_avail = false,
          .ebm_reg_base_8 = 0x0,
          .ebm_mem_base_8 = 0x0,
          .ebm_irq = 0x0,

          .ebm_fw_single_bufr_depth = 0x0,
          .ebm_fw_total_bufrs = 0x0,
          .ebm_total_bufr_span = 0x0,

          .ep_req_queue_size = 1,
          .ep_trb_slots = 1,

          .pre_fetch_xfer = false,

          .disp_xfer_len = false,
          .disp_xferred_data =  false,

          .init_cb = NULL,
          .en_cb = NULL,
          .dis_cb = NULL,
          .xfer_req_cb = NULL,
          .xfer_completion_cb = NULL
          };

// ---------------------------------------------------------------------
// User configuration for OUT endpoint 1.
// At present, this is for Isochronous OUT endpoint.
// This does not use fifo based EBM.
const struct user_ep_cnfg iso_out_user_ep_cnfg = {
          .fifo_based_ebm_avail = false,
          .ebm_reg_base_8 = 0x0,
          .ebm_mem_base_8 = (uint32_t)&fw_out_ep_bufr[0],
          .ebm_irq = 0x0,

          .ebm_fw_single_bufr_depth = LSC_OUT_EP_SINGLE_BUFR_DEPTH,
          .ebm_fw_total_bufrs = LSC_OUT_EP_TOTAL_BUFRS,
          .ebm_total_bufr_span =  (sizeof(fw_out_ep_bufr)),

          .ep_req_queue_size = ISO_OUT_EP_REQ_QUEUE_SIZE,
          .ep_trb_slots = ISO_OUT_EP_TRB_SLOTS,

          .pre_fetch_xfer = false, // This must be false for Isochronous endpoint.

          .disp_xfer_len = false, // Do not enable for Isochronous endpoint.
          .disp_xferred_data =  false, // Do not enable for Isochronous endpoint.

          .init_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_init,
          .en_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_enable,
          .dis_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_disable,
          .xfer_req_cb = NULL,
          .xfer_completion_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t, uint32_t))lsc_fw_ep_buf_mgmt_xfer_completion_cb
          };

// ---------------------------------------------------------------------
// User configuration for OUT endpoint 2.
// At present, this is for Bulk OUT endpoint.
// This uses FIFO based EBM (i.e. OEBM).
const struct user_ep_cnfg bulk_out_user_ep_cnfg = {
          .fifo_based_ebm_avail = true,
          .ebm_reg_base_8 = LSC_OEBM_BUF_MGMT_IP_BASE,
          .ebm_mem_base_8 = LSC_OEBM_BUF_MEM_BASE,
          .ebm_irq = LSC_OEBM_BUF_MGMT_IRQ,

          .ebm_fw_single_bufr_depth = LSC_OEBM_FW_ALLOC_BUF_DEPTH,
          .ebm_fw_total_bufrs = LSC_OEBM_FW_TOTAL_BUF,
          .ebm_total_bufr_span =  (LSC_OEBM_FW_ALLOC_BUF_DEPTH*LSC_OEBM_FW_TOTAL_BUF ),

          .ep_req_queue_size = BULK_OUT_EP_REQ_QUEUE_SIZE,
          .ep_trb_slots = BULK_OUT_EP_TRB_SLOTS,

          .pre_fetch_xfer = true,

          .disp_xfer_len = false,
          .disp_xferred_data =  false,

          .init_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_oebm_init,
          .en_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_oebm_enable,
          .dis_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_oebm_disable,
          .xfer_req_cb = NULL,
          .xfer_completion_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t, uint32_t))lsc_oebm_xfer_completion_cb
          };

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// User configuration for OUT endpoint 3.
// At present, this is for Interrupt OUT endpoint.
// This does not use fifo based EBM.
const struct user_ep_cnfg int_out_user_ep_cnfg = {
          .fifo_based_ebm_avail = false,
          .ebm_reg_base_8 = 0x0,
          .ebm_mem_base_8 = (uint32_t)&fw_out_ep_bufr[0],
          .ebm_irq = 0x0,

          .ebm_fw_single_bufr_depth = LSC_OUT_EP_SINGLE_BUFR_DEPTH,
          .ebm_fw_total_bufrs = LSC_OUT_EP_TOTAL_BUFRS,
          .ebm_total_bufr_span =  (sizeof(fw_out_ep_bufr)),

          .ep_req_queue_size = INT_OUT_EP_REQ_QUEUE_SIZE,
          .ep_trb_slots = INT_OUT_EP_TRB_SLOTS,

          .pre_fetch_xfer = true,

          .disp_xfer_len = false, // Do not enable for Isochronous endpoint.
          .disp_xferred_data =  false, // Do not enable for Isochronous endpoint.

          .init_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_init,
          .en_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_enable,
          .dis_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_disable,
          .xfer_req_cb = NULL,
          .xfer_completion_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t, uint32_t))lsc_fw_ep_buf_mgmt_xfer_completion_cb
          };

// ------------------------------------------------------------------
// Array for OUT endpoint user configuration
const struct user_ep_cnfg  out_user_ep_cnfg[16] = {

        // Control Endpoint 0
        // Control endpoint uses different approach. Hence, we have used unused_ep_cnfg for that.
        unused_ep_cnfg,

        // Endpoint 1 - Isochronous OUT
        iso_out_user_ep_cnfg,
        //unused_ep_cnfg,

        // Endpoint 2 - Bulk OUT
        bulk_out_user_ep_cnfg,
        //unused_ep_cnfg,

        // Endpoint 3 - Interrupt OUT
        int_out_user_ep_cnfg,
        //unused_ep_cnfg,

        // Endpoint 4
        unused_ep_cnfg,
        // Endpoint 5
        unused_ep_cnfg,

        // Endpoint 6
        unused_ep_cnfg,

        // Endpoint 7
        unused_ep_cnfg,

        // Endpoint 8
        unused_ep_cnfg,

        // Endpoint 9
        unused_ep_cnfg,

        // Endpoint 10
        unused_ep_cnfg,

        // Endpoint 11
        unused_ep_cnfg,

        // Endpoint 12
        unused_ep_cnfg,

        // Endpoint 13
        unused_ep_cnfg,

        // Endpoint 14
        unused_ep_cnfg,

        // Endpoint 15
        unused_ep_cnfg
};

// ---------------------------------------------------------------------
// User configuration for IN endpoint 1.
// At present, this is for Isochronous IN endpoint.
// This does not use fifo based EBM.
const struct user_ep_cnfg iso_in_user_ep_cnfg = {
          .fifo_based_ebm_avail = false,
          .ebm_reg_base_8 = 0x0,
          .ebm_mem_base_8 = (uint32_t)&fw_in_ep_bufr[0],
          .ebm_irq = 0x0,

          .ebm_fw_single_bufr_depth = LSC_IN_EP_SINGLE_BUFR_DEPTH,
          .ebm_fw_total_bufrs = LSC_IN_EP_TOTAL_BUFRS,
          .ebm_total_bufr_span =  (sizeof(fw_in_ep_bufr)),

          .ep_req_queue_size = ISO_IN_EP_REQ_QUEUE_SIZE,
          .ep_trb_slots = ISO_IN_EP_TRB_SLOTS,

          .pre_fetch_xfer = false, // This must be false for Isochronous endpoint.

          .disp_xfer_len = false, // Do not enable for Isochronous endpoint.
          .disp_xferred_data =  false, // Do not enable for Isochronous endpoint.

          .init_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_init,
          .en_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_enable,
          .dis_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_disable,
          .xfer_req_cb = NULL,
          .xfer_completion_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t, uint32_t))lsc_fw_ep_buf_mgmt_xfer_completion_cb
          };

// ---------------------------------------------------------------------
// User configuration for IN endpoint 2.
// At present, this is for Bulk IN endpoint.
// This uses FIFO based EBM (i.e. IEBM).
const struct user_ep_cnfg bulk_in_user_ep_cnfg = {
          .fifo_based_ebm_avail = true,
          .ebm_reg_base_8 = LSC_IEBM_BUF_MGMT_IP_BASE,
          .ebm_mem_base_8 = LSC_IEBM_BUF_MEM_BASE,
          .ebm_irq = LSC_IEBM_BUF_MGMT_IRQ,

          .ebm_fw_single_bufr_depth = LSC_IEBM_FW_SINGLE_BUF_DEPTH,
          .ebm_fw_total_bufrs = LSC_IEBM_FW_TOTAL_BUF,
          .ebm_total_bufr_span =  (LSC_IEBM_FW_SINGLE_BUF_DEPTH*LSC_IEBM_FW_TOTAL_BUF ),

          .ep_req_queue_size = BULK_IN_EP_REQ_QUEUE_SIZE,
          .ep_trb_slots = BULK_IN_EP_TRB_SLOTS,

          .pre_fetch_xfer = true,

          .disp_xfer_len = false,
          .disp_xferred_data =  false,

          .init_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_iebm_init,
          .en_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_iebm_enable,
          .dis_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_iebm_disable,
          .xfer_req_cb = NULL,
          .xfer_completion_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t, uint32_t))lsc_iebm_xfer_completion_cb
          };

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// User configuration for IN endpoint 3.
// At present, this is for Interrupt IN endpoint.
// This does not use fifo based EBM.
const struct user_ep_cnfg int_in_user_ep_cnfg = {
          .fifo_based_ebm_avail = false,
          .ebm_reg_base_8 = 0x0,
          .ebm_mem_base_8 = (uint32_t)&fw_in_ep_bufr[0],
          .ebm_irq = 0x0,

          .ebm_fw_single_bufr_depth = LSC_IN_EP_SINGLE_BUFR_DEPTH,
          .ebm_fw_total_bufrs = LSC_IN_EP_TOTAL_BUFRS,
          .ebm_total_bufr_span =  (sizeof(fw_in_ep_bufr)),

          .ep_req_queue_size = INT_IN_EP_REQ_QUEUE_SIZE,
          .ep_trb_slots = INT_IN_EP_TRB_SLOTS,

          .pre_fetch_xfer = true,

          .disp_xfer_len = false, // Do not enable for Isochronous endpoint.
          .disp_xferred_data =  false, // Do not enable for Isochronous endpoint.

          .init_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_init,
          .en_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_enable,
          .dis_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t) )lsc_fw_ep_buf_mgmt_disable,
          .xfer_req_cb = NULL,
          .xfer_completion_cb = (void (*) (struct lsc_usb_dev*, uint8_t, uint8_t, uint32_t))lsc_fw_ep_buf_mgmt_xfer_completion_cb
          };

// ------------------------------------------------------------------
// Array for IN endpoint user configuration

const struct user_ep_cnfg  in_user_ep_cnfg[16] = {

        // Control Endpoint 0
        // Control endpoint uses different approach. Hence, we have used unused_ep_cnfg for that.
        unused_ep_cnfg,

        // Endpoint 1 - Isochronous IN
        iso_in_user_ep_cnfg,
        //unused_ep_cnfg,

        // Endpoint 2 - Bulk IN
        bulk_in_user_ep_cnfg,
        //unused_ep_cnfg,

        // Endpoint 3 - Interrupt IN
        int_in_user_ep_cnfg,
        //unused_ep_cnfg,

        // Endpoint 4
        unused_ep_cnfg,
        // Endpoint 5
        unused_ep_cnfg,

        // Endpoint 6
        unused_ep_cnfg,

        // Endpoint 7
        unused_ep_cnfg,

        // Endpoint 8
        unused_ep_cnfg,

        // Endpoint 9
        unused_ep_cnfg,

        // Endpoint 10
        unused_ep_cnfg,

        // Endpoint 11
        unused_ep_cnfg,


        // Endpoint 12
        unused_ep_cnfg,

        // Endpoint 13
        unused_ep_cnfg,

        // Endpoint 14
        unused_ep_cnfg,

        // Endpoint 15
        unused_ep_cnfg
};

/** @} */
// Smile Please!
