/****************************************************************************/
/**
 *
 * @file lsc_user_ep_cnfg.h
 *
 * This file faciliates user endpoint configuration. Alongwith updating this
 * user shall also update corresponding descriptors (if necessary).
 *
 * @addtogroup lscusb Overview
 * @{
 *
 *
 *
 *****************************************************************************/

#ifndef LSC_USER_EP_CNFG_H_
#define LSC_USER_EP_CNFG_H_

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files ********************************/

#include "lsc_out_ep_buf_mgmt.h"
#include "lsc_in_ep_buf_mgmt.h"

/************************** Constant Definitions ****************************/

// This follows Doxygen based comments.

// ----------------------------------------------------------------------------------
/**
 * @name Isochronous OUT endpoint User configuration
 * @{
 */

//! Isochronous OUT endpoint number (without direction flag). \n
//! Width = 4 bits
#define ISO_OUT_EP_NO 1

//! Isochronous OUT endpoint maximum packet size for Super speed mode. \n
//! Width = 11 bits
#define ISO_OUT_EP_MAX_PKT_SIZE_SS 1024

//! Isochronous OUT endpoint maximum packet size for High speed mode. \n
//! Width = 11 bits
#define ISO_OUT_EP_MAX_PKT_SIZE_HS 512

//! Isochronous OUT endpoint maximum packet size for Full speed mode. \n
//! Width = 11 bits
#define ISO_OUT_EP_MAX_PKT_SIZE_FS 64

//! Isochronous OUT endpoint additional transaction opportunities per micro-frame. \n
//! Applicable to high speed mode only.
//! Width = 2 bits
#define ISO_OUT_EP_ADD_XFER_PER_MF_HS 0

//! Isochronous OUT endpoint bInterval for Super speed mode. \n
#define ISO_OUT_EP_B_INTERVAL_SS 4

//! Isochronous OUT endpoint bInterval for High speed mode. \n
#define ISO_OUT_EP_B_INTERVAL_HS 4

//! Isochronous OUT endpoint bInterval for Full speed mode. \n
#define ISO_OUT_EP_B_INTERVAL_FS 4

//! Isochronous OUT endpoint bMaxBurst for Super speed mode. \n
#define ISO_OUT_EP_B_MAX_BURST_SS 2

//! Isochronous OUT endpoint Mult for Super speed mode. \n
//! Width = 2 bits
#define ISO_OUT_EP_B_MULT_SS 0

//! Isochronous OUT endpoint fifo based endpoint buffer manager.\n
//! In other words, it indicates whether OEBM is available for this endpoint or not. \n
//! This shall be set to false for Isochronous endpoint.
#define ISO_OUT_EP_FIFO_BASED_EBM false

//! Isochronous OUT endpoint firmware allocated single buffer depth
/*! Minimum single buffer depth for periodic endpoint should be equal to
  * number of bytes this endpoint can transfer in single service interval.\n
  * In following, we have considered it according to superspeed mode assuming
  * in superspeed mode this value will be higher or equal to high speed or
  * full speed mode. \n
  * This must not be zero.
 */
#define ISO_OUT_EP_FW_SINGLE_BUFR_DEPTH  ( ISO_OUT_EP_MAX_PKT_SIZE_SS * (ISO_OUT_EP_B_MAX_BURST_SS+1) * (ISO_OUT_EP_B_MULT_SS + 1)  )

//! Isochronous OUT endpoint firmware allocated total buffers
/*! This represents number of buffers allocated by firmware for this endpoint. \n
 *  We have choosen 4 here to have enough requests queued for data transfer. \n
 *
 *  This must not be zero.
 */
#define ISO_OUT_EP_FW_TOTAL_BUFRS LSC_OUT_EP_TOTAL_BUFRS

//! Isochronous OUT endpoint Request Queue size
/*! This represents number of requests which can be queued for this endpoint. \n
 *  This must be less than or equal to LSC_EP_REQ_QUEUE_MAX_SIZE.
 *  This shall not be more than firmware allocated total buffers.
 *  Typically, this shall be equal to firmware allocated total buffers. One
 *  may choose smaller value for debugging purpose.
 */
#define ISO_OUT_EP_REQ_QUEUE_SIZE  (ISO_OUT_EP_FW_TOTAL_BUFRS)

//! Isochronous OUT endpoint TRB Slots
/*! This represents number of TRBs (excluding Link TRB) which shall be used for this
 *  endpoint. \n
 *  This must be less than or equal to LSC_EP_MAX_TRB_SLOTS.
 *  Typically, this shall be equal to ISO_OUT_EP_REQ_QUEUE_SIZE. One
 *  may choose smaller value for debugging purpose.
 */
#define ISO_OUT_EP_TRB_SLOTS (ISO_OUT_EP_REQ_QUEUE_SIZE)

/**
 * @}
 */
// ----------------------------------------------------------------------------------


// ----------------------------------------------------------------------------------
/**
 * @name Isochronous IN endpoint User configuration
 * @{
 */

//! Isochronous IN endpoint number (without direction flag). \n
//! Width = 4 bits
#define ISO_IN_EP_NO 1

//! Isochronous IN endpoint maximum packet size for Super speed mode. \n
//! Width = 11 bits
#define ISO_IN_EP_MAX_PKT_SIZE_SS 1024

//! Isochronous IN endpoint maximum packet size for High speed mode. \n
//! Width = 11 bits
#define ISO_IN_EP_MAX_PKT_SIZE_HS 1024

//! Isochronous IN endpoint maximum packet size for Full speed mode. \n
//! Width = 11 bits
#define ISO_IN_EP_MAX_PKT_SIZE_FS 64

//! Isochronous IN endpoint additional transaction opportunities per micro-frame. \n
//! Applicable to high speed mode only.
//! Width = 2 bits
#define ISO_IN_EP_ADD_XFER_PER_MF_HS 0

//! Isochronous IN endpoint bInterval for Super speed mode. \n
#define ISO_IN_EP_B_INTERVAL_SS 4

//! Isochronous IN endpoint bInterval for High speed mode. \n
#define ISO_IN_EP_B_INTERVAL_HS 4

//! Isochronous IN endpoint bInterval for Full speed mode. \n
#define ISO_IN_EP_B_INTERVAL_FS 4

//! Isochronous IN endpoint bMaxBurst for Super speed mode. \n
#define ISO_IN_EP_B_MAX_BURST_SS 2

//! Isochronous IN endpoint Mult for Super speed mode. \n
//! Width = 2 bits
#define ISO_IN_EP_B_MULT_SS 0

//! Isochronous IN endpoint fifo based endpoint buffer manager.\n
//! In other words, it indicates whether IEBM is available for this endpoint or not. \n
//! This shall be set to false for Isochronous endpoint.
#define ISO_IN_EP_FIFO_BASED_EBM false

//! Isochronous IN endpoint firmware allocated single buffer depth
/*! Minimum single buffer depth for periodic endpoint should be equal to
  * number of bytes this endpoint can transfer in single service interval.\n
  * In following, we have considered it according to superspeed mode assuming
  * in superspeed mode this value will be higher or equal to high speed or
  * full speed mode. \n
  * This must not be zero.
 */
#define ISO_IN_EP_FW_SINGLE_BUFR_DEPTH  ( ISO_IN_EP_MAX_PKT_SIZE_SS * (ISO_IN_EP_B_MAX_BURST_SS+1) * (ISO_IN_EP_B_MULT_SS + 1)  )

//! Isochronous IN endpoint firmware allocated total buffers
/*! This represents number of buffers allocated by firmware for this endpoint. \n
 *  We have choosen 4 here to have enough requests queued for data transfer. \n
 *
 *  This must not be zero.
 */
#define ISO_IN_EP_FW_TOTAL_BUFRS LSC_IN_EP_TOTAL_BUFRS

//! Isochronous IN endpoint Request Queue size
/*! This represents number of requests which can be queued for this endpoint. \n
 *  This must be less than or equal to LSC_EP_REQ_QUEUE_MAX_SIZE.
 *  This shall not be more than firmware allocated total buffers.
 *  Typically, this shall be equal to firmware allocated total buffers. One
 *  may choose smaller value for debugging purpose.
 */
#define ISO_IN_EP_REQ_QUEUE_SIZE  (ISO_IN_EP_FW_TOTAL_BUFRS)

//! Isochronous IN endpoint TRB Slots
/*! This represents number of TRBs (excluding Link TRB) which shall be used for this
 *  endpoint. \n
 *  This must be less than or equal to LSC_EP_MAX_TRB_SLOTS.
 *  Typically, this shall be equal to ISO_IN_EP_REQ_QUEUE_SIZE. One
 *  may choose smaller value for debugging purpose.
 */
#define ISO_IN_EP_TRB_SLOTS (ISO_IN_EP_REQ_QUEUE_SIZE)

/**
 * @}
 */
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------
/**
 * @name Bulk OUT endpoint User configuration
 * @{
 */

//! Bulk OUT endpoint number (without direction flag). \n
//! Width = 4 bits
#define BULK_OUT_EP_NO 2

//! Bulk OUT endpoint maximum packet size for Super speed mode. \n
//! Width = 11 bits
#define BULK_OUT_EP_MAX_PKT_SIZE_SS 1024

//! Bulk OUT endpoint maximum packet size for High speed mode. \n
//! Width = 11 bits
#define BULK_OUT_EP_MAX_PKT_SIZE_HS 512

//! Bulk OUT endpoint maximum packet size for Full speed mode. \n
//! Width = 11 bits
#define BULK_OUT_EP_MAX_PKT_SIZE_FS 64

//! Bulk OUT endpoint bMaxBurst for Super speed mode. \n
#define BULK_OUT_EP_B_MAX_BURST_SS 15

//! Bulk OUT endpoint fifo based endpoint buffer manager.\n
//! In other words, it indicates whether OEBM is available for this endpoint or not. \n
//! Based on design, one should set this to true or false.
#define BULK_OUT_EP_FIFO_BASED_EBM true

//! Bulk OUT endpoint firmware allocated single buffer depth
/*! Minimum single buffer depth for Bulk endpoint shall be equal to
  * endpoint's maximum packet size.
  * This should be choosen by considering Super speed mode as this will be highest in
  * that among all speeds. \n
  *
  * If OEBM is available, it is preferable to set this according to buffer
  * size allocated by hardware. One may use smaller value for debugging
  * purpose.

  * This must not be zero.
 */
#define BULK_OUT_EP_FW_SINGLE_BUFR_DEPTH  (LSC_OEBM_HW_ALLOC_BUF_DEPTH)

//! Bulk OUT endpoint firmware allocated total buffers
/*! This represents number of buffers allocated by firmware for this endpoint. \n

  * If OEBM is available, it is preferable to set this according to buffers
  * allocated by hardware. One may use smaller value for debugging purpose. \n
 *
 *  This must not be zero.
 */
#define BULK_OUT_EP_FW_TOTAL_BUFRS (LSC_OEBM_FW_TOTAL_BUF)

//! Bulk OUT endpoint Request Queue size
/*! This represents number of requests which can be queued for this endpoint. \n
 *  This must be less than or equal to LSC_EP_REQ_QUEUE_MAX_SIZE.
 *  This shall not be more than firmware allocated total buffers.
 *  Typically, this shall be equal to firmware allocated total buffers. One
 *  may choose smaller value for debugging purpose.
 */
#define BULK_OUT_EP_REQ_QUEUE_SIZE  (BULK_OUT_EP_FW_TOTAL_BUFRS)

//! Bulk IN endpoint TRB Slots
/*! This represents number of TRBs (excluding Link TRB) which shall be used for this
 *  endpoint. \n
 *  This must be less than or equal to LSC_EP_MAX_TRB_SLOTS.
 *  Typically, this shall be equal to BULK_OUT_EP_REQ_QUEUE_SIZE. One
 *  may choose smaller value for debugging purpose.
 */
#define BULK_OUT_EP_TRB_SLOTS (BULK_OUT_EP_REQ_QUEUE_SIZE)

/**
 * @}
 */
// ----------------------------------------------------------------------------------


// ----------------------------------------------------------------------------------
/**
 * @name Bulk IN endpoint User configuration
 * @{
 */

//! Bulk IN endpoint number (without direction flag). \n
//! Width = 4 bits
#define BULK_IN_EP_NO 2

//! Bulk IN endpoint maximum packet size for Super speed mode. \n
//! Width = 11 bits
#define BULK_IN_EP_MAX_PKT_SIZE_SS 1024

//! Bulk IN endpoint maximum packet size for High speed mode. \n
//! Width = 11 bits
#define BULK_IN_EP_MAX_PKT_SIZE_HS 512

//! Bulk IN endpoint maximum packet size for Full speed mode. \n
//! Width = 11 bits
#define BULK_IN_EP_MAX_PKT_SIZE_FS 64

//! Bulk IN endpoint bMaxBurst for Super speed mode. \n
#define BULK_IN_EP_B_MAX_BURST_SS 15

//! Bulk IN endpoint fifo based endpoint buffer manager.\n
//! In other words, it indicates whether IEBM is available for this endpoint or not. \n
//! Based on design, one should set this to true or false.
#define BULK_IN_EP_FIFO_BASED_EBM true

//! Bulk IN endpoint firmware allocated single buffer depth
/*! Minimum single buffer depth for Bulk endpoint shall be equal to
  * endpoint's maximum packet size.
  * This should be choosen by considering Super speed mode as this will be highest in
  * that among all speeds. \n
  *
  * If IEBM is available, it is preferable to set this according to buffer
  * size allocated by hardware. One may use smaller value for debugging
  * purpose.

  * This must not be zero.
 */
#define BULK_IN_EP_FW_SINGLE_BUFR_DEPTH  (LSC_IEBM_HW_ALLOC_BUF_DEPTH)

//! Bulk IN endpoint firmware allocated total buffers
/*! This represents number of buffers allocated by firmware for this endpoint. \n

  * If IEBM is available, it is preferable to set this according to buffers
  * allocated by hardware. One may use smaller value for debugging purpose. \n
 *
 *  This must not be zero.
 */
#define BULK_IN_EP_FW_TOTAL_BUFRS (LSC_IEBM_FW_TOTAL_BUF)

//! Bulk IN endpoint Request Queue size
/*! This represents number of requests which can be queued for this endpoint. \n
 *  This must be less than or equal to LSC_EP_REQ_QUEUE_MAX_SIZE.
 *  This shall not be more than firmware allocated total buffers.
 *  Typically, this shall be equal to firmware allocated total buffers. One
 *  may choose smaller value for debugging purpose.
 */
#define BULK_IN_EP_REQ_QUEUE_SIZE  (BULK_IN_EP_FW_TOTAL_BUFRS)

//! Bulk IN endpoint TRB Slots
/*! This represents number of TRBs (excluding Link TRB) which shall be used for this
 *  endpoint. \n
 *  This must be less than or equal to LSC_EP_MAX_TRB_SLOTS.
 *  Typically, this shall be equal to BULK_IN_EP_REQ_QUEUE_SIZE. One
 *  may choose smaller value for debugging purpose.
 */
#define BULK_IN_EP_TRB_SLOTS (BULK_IN_EP_REQ_QUEUE_SIZE)

/**
 * @}
 */
// ----------------------------------------------------------------------------------


// ----------------------------------------------------------------------------------
/**
 * @name Interrupt OUT endpoint User configuration
 * @{
 */

//! Interrupt OUT endpoint number (without direction flag). \n
//! Width = 4 bits
#define INT_OUT_EP_NO 3

//! Interrupt OUT endpoint maximum packet size for Super speed mode. \n
//! Width = 11 bits
#define INT_OUT_EP_MAX_PKT_SIZE_SS 1024

//! Interrupt OUT endpoint maximum packet size for High speed mode. \n
//! Width = 11 bits
#define INT_OUT_EP_MAX_PKT_SIZE_HS 1024

//! Interrupt OUT endpoint maximum packet size for Full speed mode. \n
//! Width = 11 bits
#define INT_OUT_EP_MAX_PKT_SIZE_FS 64

//! Interrupt OUT endpoint additional transaction opportunities per micro-frame. \n
//! Applicable to high speed mode only.
//! Width = 2 bits
#define INT_OUT_EP_ADD_XFER_PER_MF_HS 0

//! Interrupt OUT endpoint bInterval for Super speed mode. \n
#define INT_OUT_EP_B_INTERVAL_SS 1

//! Interrupt OUT endpoint bInterval for High speed mode. \n
#define INT_OUT_EP_B_INTERVAL_HS 1

//! Interrupt OUT endpoint bInterval for Full speed mode. \n
#define INT_OUT_EP_B_INTERVAL_FS 1

//! Interrupt OUT endpoint bMaxBurst for Super speed mode. \n
#define INT_OUT_EP_B_MAX_BURST_SS 2

//! Interrupt OUT endpoint fifo based endpoint buffer manager.\n
//! In other words, it indicates whether OEBM is available for this endpoint or not. \n
//! This shall be set to false for Isochronous endpoint.
#define INT_OUT_EP_FIFO_BASED_EBM false

//! Interrupt OUT endpoint firmware allocated single buffer depth
/*! Minimum single buffer depth for periodic endpoint should be equal to
  * number of bytes this endpoint can transfer in single service interval.\n
  * In following, we have considered it according to superspeed mode assuming
  * in superspeed mode this value will be higher or equal to high speed or
  * full speed mode. \n
  * This must not be zero.
 */
#define INT_OUT_EP_FW_SINGLE_BUFR_DEPTH  ( INT_OUT_EP_MAX_PKT_SIZE_SS * ( INT_OUT_EP_B_MAX_BURST_SS+1)  )


//! Interrupt OUT endpoint firmware allocated total buffers
/*! This represents number of buffers allocated by firmware for this endpoint. \n
 *  We have choosen 4 here to have enough requests queued for data transfer. \n
 *
 *  This must not be zero.
 */
#define INT_OUT_EP_FW_TOTAL_BUFRS LSC_OUT_EP_TOTAL_BUFRS

//! Interrupt OUT endpoint Request Queue size
/*! This represents number of requests which can be queued for this endpoint. \n
 *  This must be less than or equal to LSC_EP_REQ_QUEUE_MAX_SIZE.
 *  This shall not be more than firmware allocated total buffers.
 *  Typically, this shall be equal to firmware allocated total buffers. One
 *  may choose smaller value for debugging purpose.
 */
#define INT_OUT_EP_REQ_QUEUE_SIZE  (INT_OUT_EP_FW_TOTAL_BUFRS)

//! Interrupt OUT endpoint TRB Slots
/*! This represents number of TRBs (excluding Link TRB) which shall be used for this
 *  endpoint. \n
 *  This must be less than or equal to LSC_EP_MAX_TRB_SLOTS.
 *  Typically, this shall be equal to INT_OUT_EP_REQ_QUEUE_SIZE. One
 *  may choose smaller value for debugging purpose.
 */
#define INT_OUT_EP_TRB_SLOTS (INT_OUT_EP_REQ_QUEUE_SIZE)

/**
 * @}
 */
// ----------------------------------------------------------------------------------


// ----------------------------------------------------------------------------------
/**
 * @name Interrupt IN endpoint User configuration
 * @{
 */

//! Interrupt IN endpoint number (without direction flag). \n
//! Width = 4 bits
#define INT_IN_EP_NO 3

//! Interrupt IN endpoint maximum packet size for Super speed mode. \n
//! Width = 11 bits
#define INT_IN_EP_MAX_PKT_SIZE_SS 1024

//! InterruptIN endpoint maximum packet size for High speed mode. \n
//! Width = 11 bits
#define INT_IN_EP_MAX_PKT_SIZE_HS 1024

//! Interrupt IN endpoint maximum packet size for Full speed mode. \n
//! Width = 11 bits
#define INT_IN_EP_MAX_PKT_SIZE_FS 64

//! Interrupt IN endpoint additional transaction opportunities per micro-frame. \n
//! Applicable to high speed mode only.
//! Width = 2 bits
#define INT_IN_EP_ADD_XFER_PER_MF_HS 0

//! Interrupt IN endpoint bInterval for Super speed mode. \n
#define INT_IN_EP_B_INTERVAL_SS 1

//! Interrupt IN endpoint bInterval for High speed mode. \n
#define INT_IN_EP_B_INTERVAL_HS 1

//! Interrupt IN endpoint bInterval for Full speed mode. \n
#define INT_IN_EP_B_INTERVAL_FS 1

//! Interrupt IN endpoint bMaxBurst for Super speed mode. \n
#define INT_IN_EP_B_MAX_BURST_SS 2

//! Interrupt IN endpoint fifo based endpoint buffer manager.\n
//! In other words, it indicates whether IEBM is available for this endpoint or not. \n
#define INT_IN_EP_FIFO_BASED_EBM false

//! Interrupt IN endpoint firmware allocated single buffer depth
/*! Minimum single buffer depth for periodic endpoint should be equal to
  * number of bytes this endpoint can transfer in single service interval.\n
  * In following, we have considered it according to superspeed mode assuming
  * in superspeed mode this value will be higher or equal to high speed or
  * full speed mode. \n
  * This must not be zero.
 */
#define INT_IN_EP_FW_SINGLE_BUFR_DEPTH  ( INT_IN_EP_MAX_PKT_SIZE_SS * (INT_IN_EP_B_MAX_BURST_SS+1) )

//! Interrupt IN endpoint firmware allocated total buffers
/*! This represents number of buffers allocated by firmware for this endpoint. \n
 *  We have choosen 4 here to have enough requests queued for data transfer. \n
 *
 *  This must not be zero.
 */
#define INT_IN_EP_FW_TOTAL_BUFRS LSC_IN_EP_TOTAL_BUFRS

//! Interrupt IN endpoint Request Queue size
/*! This represents number of requests which can be queued for this endpoint. \n
 *  This must be less than or equal to LSC_EP_REQ_QUEUE_MAX_SIZE.
 *  This shall not be more than firmware allocated total buffers.
 *  Typically, this shall be equal to firmware allocated total buffers. One
 *  may choose smaller value for debugging purpose.
 */
#define INT_IN_EP_REQ_QUEUE_SIZE  (INT_IN_EP_FW_TOTAL_BUFRS)

//! Interrupt IN endpoint TRB Slots
/*! This represents number of TRBs (excluding Link TRB) which shall be used for this
 *  endpoint. \n
 *  This must be less than or equal to LSC_EP_MAX_TRB_SLOTS.
 *  Typically, this shall be equal to INT_IN_EP_REQ_QUEUE_SIZE. One
 *  may choose smaller value for debugging purpose.
 */
#define INT_IN_EP_TRB_SLOTS (INT_IN_EP_REQ_QUEUE_SIZE)

/**
 * @}
 */
// ----------------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

#endif /* LSC_USER_EP_CNFG_H_ */

/** @} */
