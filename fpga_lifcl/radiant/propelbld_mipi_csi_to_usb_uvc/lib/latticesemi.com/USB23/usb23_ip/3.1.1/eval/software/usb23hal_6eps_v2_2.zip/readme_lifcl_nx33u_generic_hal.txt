/** @page HAL Release History

This file describes changes made to the LIFCL NX33U HAL in every new release.

      Sr. No      Release Version                                                                         Changes

        1           v1.0                                                                 -   Base Release
                    (SHA-1: fd1e3365381e84f3595d94a81ca9e84e40ebdf44)

        2           v2.0                                                                 -   Added support for Isochronous and Interrupt endpoints.
                    (SHA-1: cda456aaa023e522ae9b3ba48a2f3fae5c3150b6)

        3           v2.1                                                                 -   Added user endpoint configuration file to make it a bit
                    (SHA-1: 68bf488b1812d25cc60dc8755c639a540e0521f3)                        easier for user to update some endpoint related parameters.
                                                                                         -   Updated some flow for Interrupt and Isochronous transfer
                                                                                             processing.
                                                                                         -   Increased bInterval for Isochronous transfers.

        3           v2.2                                                                 -   Updated code to use dedicated memory for items which is
                    (SHA-1: 4a37c6c418a0ca4413b7a96dbfe7feecfad4e269)                        intended to be accessed by USB23 controller.
                                                                                         -   Renamed some functions to more meaningful name.
                                                                                         -   Enabled Event Buffer Overflow event interrupt.
                                                                                         -   Updated ISR functions for IEBM and OEBM to make them generic
                                                                                             to be used for different endpoints.
                                                                                         -   Added support for GPIO to initiate Remote Wakeup for USB2.0.
                                                                                         -   Used separate macros for USB2.0 LPM and USB3.0 U1/U2
                                                                                             functionality.
                                                                                         -   Updated code to use separate Alternate settings of interface
                                                                                             0 for different type of transfers.
                                                                                         -   Enabled 1KB burst for AXI Master interface. (LSC_GSBUSCFG0
                                                                                             register).
                                                                                         -   Added timer based logic to decide when to cancel submitted
                                                                                             Isochronous OUT transfers. And removed corresponding SOF event based logic.

        3           v2.3                                                                 -   Added logic to faciliate firmware to reset USB2.0 PHY via
                    (SHA-1: 02c9e4378626abe0aefe92d54b8f5c4c8daaff84)                        corresponding GPIO.
                                                                                         -   Resolved USB3 enumeration issue with Apple Macbook Pro L1
                                                                                             laptop.
                                                                                         -   Corrected register update logic for DCTL and GCTL registers
                                                                                             in lsc_usb_hw_init() and lsc_usb_phy_reset() functions.
                                                                                         -   Corrected value getting passed to ‘PWRDNSCALE’ field in GCTL
                                                                                             (Global control) register.
                                                                                         -   Made some improvements to make it easier to add vendor/class
                                                                                             specific requests in future.

*/